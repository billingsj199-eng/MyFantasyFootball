/* MFF Underdog Draft Helper — background service worker (MV3)
 *
 * v0.9.30: improved diagnostics (logs response body on failure) and
 * tries multiple auth combinations:
 *   1. Bearer token + credentials:'include' (cookies should flow)
 *   2. If 401, try with explicit cookies from chrome.cookies API
 */

// v0.10.1: dual-domain — UD is migrating from underdogfantasy.com to
// underdogsports.com. Pick the right Origin/Referer/cookie domain based on
// the API host we're hitting so this works on either side of the migration.
function _udFamilyForUrl(url) {
  try {
    const h = new URL(url).hostname;
    if (/underdogsports\.com$/.test(h)) return 'underdogsports.com';
  } catch (_) {}
  return 'underdogfantasy.com';
}

async function getCookieHeader(url) {
  try {
    // v0.10.1: try the host that matches the URL first, then fall back to
    // the other UD domain (cookies may be set on either during the migration).
    const primary = _udFamilyForUrl(url);
    const secondary = primary === 'underdogfantasy.com' ? 'underdogsports.com' : 'underdogfantasy.com';
    const seen = new Set();
    const merged = [];
    for (const dom of [primary, secondary]) {
      const cookies = await chrome.cookies.getAll({ domain: dom });
      if (!cookies) continue;
      for (const c of cookies) {
        if (seen.has(c.name)) continue;
        seen.add(c.name);
        merged.push(c.name + '=' + c.value);
      }
    }
    return merged.length ? merged.join('; ') : null;
  } catch (e) {
    console.warn('[MFF/bg] could not read cookies:', e);
    return null;
  }
}

async function doFetch(url, token, useExplicitCookies) {
  const family = _udFamilyForUrl(url);
  const appOrigin = 'https://app.' + family;
  const headers = {
    'Accept': 'application/json',
    'Authorization': token,
    'Origin': appOrigin
  };
  if (useExplicitCookies) {
    const cookieHeader = await getCookieHeader(url);
    if (cookieHeader) headers['Cookie'] = cookieHeader;
  }
  const resp = await fetch(url, {
    method: 'GET',
    headers,
    credentials: 'include',
    referrer: appOrigin + '/'
  });
  const text = await resp.text();
  let data = null;
  try { data = JSON.parse(text); } catch (_) {}
  return { ok: resp.ok, status: resp.status, data, body: text.slice(0, 600) };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'mff-bg-fetch') return false;

  (async () => {
    try {
      // First attempt: standard credentials:'include'
      let res = await doFetch(msg.url, msg.token, false);
      if (res.status === 401) {
        // Retry with explicit cookies (in case credentials:'include'
        // wasn't pulling them in service worker context)
        console.log('[MFF/bg] 401 on first attempt, retrying with explicit cookies for', msg.url);
        res = await doFetch(msg.url, msg.token, true);
        res.retried = true;
      }
      sendResponse(res);
    } catch (err) {
      console.warn('[MFF/bg] fetch error:', err);
      sendResponse({ ok: false, error: err.message || String(err) });
    }
  })();
  return true;
});

console.log('[MFF/bg] background worker ready (v0.10.0)');
