/* MFF Underdog Draft Helper — Recommendation Engine
 *
 * Pure logic, no DOM. Same module is used by:
 *   - sidebar.js (live drafts)
 *   - mock.html (offline tests)
 *
 * Inputs:
 *   players[]      — slim player records {n, s, t, rank, udA, age, bye}
 *   draftedSet     — Set of player names already off the board
 *   myRoster[]     — players I've drafted so far (subset of players)
 *   pickNum        — overall pick number coming up next (1-based)
 *   slot           — my draft slot (1..teamSize)
 *   teamSize       — # teams (Underdog Best Ball Mania = 12)
 *
 * Output: recommend(...) returns top N {player, score, why[]}
 *
 * Format: Underdog Best Ball Mania
 *   18 rounds, 1QB / 2RB / 3WR / 1TE / 1FLEX / 12BN
 *   No starting lineup decision once drafted — purely roster-construction-driven.
 *   Best ball auto-starts the highest-scoring lineup each week, so DEPTH AT
 *   FLEX positions (RB/WR/TE) is more valuable than 1-and-done QB/TE.
 */

(function (global) {
  "use strict";

  // ---------- Constants ----------
  // v0.9.72: realigned to match sidebar.js recommendedRoster defaults
  // (2/7/8/1 = 18, anchored at TE: 1). Earlier the engine carried TE: 2 /
  // RB: 6 / WR: 7 = 17 which contradicted the new optimal-roster widget.
  const FORMAT = {
    rounds: 18,
    teamSize: 12,
    // Standard BBM 12-team (1QB / 2RB / 3WR / 1TE / 1FLEX, 18 rounds)
    slots: { QB: 2, RB: 7, WR: 8, TE: 1, K: 0, DST: 0 }, // sums to 18
    minPos: { QB: 1, RB: 4, WR: 5, TE: 1 }, // hard floor counts
    maxPos: { QB: 3, RB: 9, WR: 10, TE: 3 }, // soft ceiling
  };

  // v0.9.67: SF target distribution differs (1QB / 2RB / 2WR / 1TE / 1FLEX / 1SF)
  // — fewer required WRs, more QBs. SF wants 3 QBs (1 starter + 1 SF + 1 backup),
  // dial back WR target since 2 starters means less depth need.
  const FORMAT_SF = {
    rounds: 18,
    teamSize: 12,
    slots: { QB: 3, RB: 7, WR: 7, TE: 1, K: 0, DST: 0 }, // sums to 18
    minPos: { QB: 2, RB: 4, WR: 4, TE: 1 },
    maxPos: { QB: 4, RB: 9, WR: 9, TE: 3 },
  };

  function fmt(isSuperflex) {
    return isSuperflex ? FORMAT_SF : FORMAT;
  }

  // v0.9.67: VOR / UP getters that pick the format-specific variant
  // baked into players.json. Standard uses `vor`/`up` (QB12/WR42 cutoffs),
  // superflex uses `vorSf`/`upSf` (QB24/WR30 cutoffs — late QBs jump
  // ~+45 VOR, late WRs drop ~-18 VOR).
  function playerVor(p, isSuperflex) {
    if (!p) return null;
    if (isSuperflex && p.vorSf != null) return p.vorSf;
    return p.vor != null ? p.vor : null;
  }
  function playerUp(p, isSuperflex) {
    if (!p) return null;
    if (isSuperflex && p.upSf != null) return p.upSf;
    return p.up != null ? p.up : null;
  }

  // v0.9.67: VOR tier-break detection. If this player's VOR is meaningfully
  // higher than the next 3 same-position players (sorted by rank/ADP order
  // they'd be drafted), flag as a tier cliff — "take now or accept the
  // drop." Surfaces in player card as a TIER tag so the user sees scarcity
  // signals beyond pure rank.
  function detectVorTier(player, available, isSuperflex) {
    const v = playerVor(player, isSuperflex);
    if (v == null) return null;
    const samePos = available
      .filter(p => p.s === player.s && playerVor(p, isSuperflex) != null)
      .sort((a, b) => (a.rank || 9999) - (b.rank || 9999));
    const idx = samePos.indexOf(player);
    if (idx < 0) return null;
    const next3 = samePos.slice(idx + 1, idx + 4);
    if (next3.length < 3) return null;
    const avgNext = next3.reduce((s, p) => s + (playerVor(p, isSuperflex) || 0), 0) / next3.length;
    const drop = v - avgNext;
    if (drop >= 30) return { type: "cliff", drop: Math.round(drop) };
    if (drop >= 18) return { type: "soft-cliff", drop: Math.round(drop) };
    return null;
  }

  // v0.9.67: roster VOR per position — sum of banked VOR at each pos.
  // Surfaces "you're loaded at WR (+450) but thin at RB (+80)" in the
  // sidebar so users can rebalance late.
  function rosterVorByPos(roster, isSuperflex) {
    const out = { QB: 0, RB: 0, WR: 0, TE: 0 };
    for (const p of roster) {
      const v = playerVor(p, isSuperflex);
      if (out[p.s] != null && v != null) out[p.s] += v;
    }
    return out;
  }

  // v0.9.67: best available VOR per position. Used to pick which
  // position-of-need to address first — "next RB is +80 VOR, next WR
  // is +30, take RB."
  function bestVorAvailable(players, draftedSet, isSuperflex) {
    const out = { QB: -9999, RB: -9999, WR: -9999, TE: -9999 };
    for (const p of players) {
      if (draftedSet.has(p.n)) continue;
      const v = playerVor(p, isSuperflex);
      if (v == null || out[p.s] == null) continue;
      if (v > out[p.s]) out[p.s] = v;
    }
    return out;
  }

  // v0.9.68: Position-level analysis — combines VOR (current + next-pick
  // projection), roster balance, and slot need into a single "urgency"
  // score per position. Surfaces to the user the position to draft next
  // based on where the value is, not just rank-ordering.
  //
  // Method:
  //   1. Sort all available by rank — assume opponents draft by rank
  //      (typical Underdog ADP behavior). Project the top N to be drafted
  //      before user's next pick, where N = picksUntilNext.
  //   2. For each position, compute bestNow vs bestNext (= best VOR
  //      among players NOT in the projected-drafted set), giving a
  //      dropoff number. Big dropoff = scarcity = take now.
  //   3. Combine bestNow + dropoff bonus + slots-open-bonus − over-bank
  //      penalty into urgency score. Position with highest urgency
  //      gets recommended.
  //
  // This naturally captures the user's heuristic: "if QB+WR are stacked
  // and RB has a big dropoff, recommend RB. If TE is empty but the next
  // good TE is close in value, you can wait." High banked VOR at one
  // position pushes the recommendation toward other positions.
  function analyzePositions(myRoster, players, draftedSet, pickNum, slot, teamSize, isSuperflex) {
    const counts = rosterCounts(myRoster);
    const banked = rosterVorByPos(myRoster, isSuperflex);
    const f = fmt(isSuperflex);
    const target = f.slots;
    const ts = teamSize || 12;
    const sl = slot || Math.ceil(ts / 2);
    const picksUntil = Math.max(0, picksUntilNext(pickNum, sl, ts));

    // Forward-simulate by rank — opponents are assumed to draft the
    // best-ranked available (matches typical Underdog ADP behavior).
    const avail = players
      .filter(p => !draftedSet.has(p.n))
      .sort((a, b) => (a.rank || 9999) - (b.rank || 9999));
    const projDrafted = new Set(avail.slice(0, picksUntil).map(p => p.n));

    const out = {};
    for (const pos of ["QB", "RB", "WR", "TE"]) {
      const samePos = avail.filter(p => p.s === pos);
      // Best VOR among ALL available at this pos
      let bestNow = -9999, bestNowName = null;
      for (const p of samePos) {
        const v = playerVor(p, isSuperflex);
        if (v != null && v > bestNow) { bestNow = v; bestNowName = p.n; }
      }
      // Best VOR among players NOT projected to be drafted before next pick
      let bestNext = -9999;
      for (const p of samePos) {
        if (projDrafted.has(p.n)) continue;
        const v = playerVor(p, isSuperflex);
        if (v != null && v > bestNext) bestNext = v;
      }
      const dropoff = bestNow - bestNext;
      const have = counts[pos] || 0;
      const tgt = target[pos] || 0;
      const slotsOpen = Math.max(0, tgt - have);

      // Urgency components:
      //   bestNow:      40% — raw value at the pick
      //   dropoff:      35% — scarcity bonus (only positive contributes)
      //   need:         25% — structural need (slots open) minus over-bank penalty
      const dropoffBonus = Math.max(0, dropoff);
      const needScore = (slotsOpen * 25) - (banked[pos] || 0) * 0.05;
      const urgency = 0.4 * (bestNow + 50)         // shift so range starts ~0
                    + 0.35 * dropoffBonus
                    + 0.25 * needScore;

      out[pos] = {
        bestNow: bestNow > -9999 ? bestNow : null,
        bestNowName,
        bestNext: bestNext > -9999 ? bestNext : null,
        dropoff: bestNow > -9999 && bestNext > -9999 ? Math.round(dropoff) : null,
        banked: Math.round(banked[pos] || 0),
        have,
        target: tgt,
        slotsOpen,
        urgency: Math.round(urgency * 10) / 10
      };
    }
    return { positions: out, picksUntil };
  }

  // v0.9.68: Roster volatility profile. Derive each drafted player's
  // weekly σ% from cPpg/pPg (cPpg = pPg + σ_per_week, so σ_pct ≈
  // (cPpg - pPg) / pPg). Average σ% across the roster classifies the
  // user's draft tendency as upside-heavy (lots of rookies / boom-bust)
  // vs safe-heavy (locked-in vets). Use to nudge the next pick:
  //   avg σ% ≥ 0.65 → "lean safer next" (roster has too many dart throws)
  //   avg σ% ≤ 0.45 → "lean upside next" (roster is all floor, no ceiling)
  //   middle        → balanced (no nudge)
  // Round-aware: only flags imbalance after 4+ picks, since 1-3 picks
  // doesn't establish a tendency.
  function analyzeRosterVolatility(roster) {
    const sigmas = [];
    for (const p of roster || []) {
      if (p.cPpg != null && p.pPg != null && p.pPg > 0.5) {
        const sigmaPct = (p.cPpg - p.pPg) / p.pPg;
        if (!isNaN(sigmaPct) && sigmaPct >= 0 && sigmaPct < 2) {
          sigmas.push({ name: p.n, pct: sigmaPct });
        }
      }
    }
    if (sigmas.length < 4) return { avgPct: null, lean: null, n: sigmas.length };
    const avg = sigmas.reduce((s, x) => s + x.pct, 0) / sigmas.length;
    let lean = "balanced";
    if (avg >= 0.65) lean = "safer";  // too risky — recommend safe pick
    else if (avg <= 0.45) lean = "upside";  // too vanilla — recommend swing
    // Count of "high-σ" players (volatile / boom-bust)
    const highSigCount = sigmas.filter(x => x.pct >= 0.7).length;
    return {
      avgPct: Math.round(avg * 100) / 100,
      lean,
      n: sigmas.length,
      highSigCount,
      highSigShare: Math.round(highSigCount / sigmas.length * 100) / 100
    };
  }

  // v0.9.68: Translate the per-position analysis into a single recommended
  // position with a human-readable rationale. Caller surfaces this above
  // the player recs as a position-level suggestion.
  function suggestPosition(analysis, roster) {
    if (!analysis || !analysis.positions) return null;
    const candidates = Object.entries(analysis.positions)
      .filter(([_, a]) => a.slotsOpen > 0 && a.bestNow != null);
    if (candidates.length === 0) return null;
    candidates.sort((a, b) => b[1].urgency - a[1].urgency);
    const [pos, info] = candidates[0];
    const reasons = [];
    if (info.dropoff != null && info.dropoff >= 30) {
      reasons.push("big VOR cliff (-" + info.dropoff + " to next pick)");
    } else if (info.dropoff != null && info.dropoff >= 15) {
      reasons.push("moderate dropoff (-" + info.dropoff + ")");
    } else if (info.dropoff != null && info.dropoff < 8) {
      reasons.push("can also wait — only -" + info.dropoff + " to next pick");
    }
    if (info.slotsOpen >= 3) reasons.push(info.slotsOpen + " slots open");
    else if (info.slotsOpen >= 1 && info.have === 0) reasons.push("no " + pos + " yet");
    if (info.bestNow != null && info.bestNow >= 100) {
      reasons.push("elite VOR (+" + Math.round(info.bestNow) + ") available");
    }
    return { pos, info, reasons, all: analysis.positions };
  }

  // Round-by-round position guidance — DAMPENED so rank stays the primary signal.
  // Range narrowed to ±5% (was ±30%) — a top-ranked QB at pick 5 should still beat
  // a worse-ranked RB just because it's "RB round."
  const ROUND_PRIOR = {
    1: { RB: 1.03, WR: 1.02, QB: 0.95, TE: 0.97 },
    2: { RB: 1.03, WR: 1.02, QB: 0.96, TE: 0.97 },
    3: { RB: 1.02, WR: 1.03, QB: 0.97, TE: 0.99 },
    4: { RB: 1.00, WR: 1.03, QB: 0.99, TE: 1.01 },
    5: { RB: 1.00, WR: 1.02, QB: 1.00, TE: 1.02 },
    6: { RB: 1.00, WR: 1.02, QB: 1.02, TE: 1.02 },
    7: { RB: 1.00, WR: 1.00, QB: 1.03, TE: 1.02 },
    8: { RB: 1.00, WR: 1.00, QB: 1.03, TE: 1.02 },
  };

  // ---------- Helpers ----------
  function pickToRound(pickNum, teamSize) {
    return Math.ceil(pickNum / teamSize);
  }

  // For snake drafts, picks come in a pattern — compute the round-pick-in-round
  // and how many picks until your next selection.
  function picksUntilNext(currentPick, mySlot, teamSize) {
    // currentPick is the pick about to happen overall. Return # picks AFTER
    // the user's current pick until they pick again, helpful for "should I
    // pivot or hope X falls."
    const round = pickToRound(currentPick, teamSize);
    const isOdd = round % 2 === 1;
    const slotPick = isOdd ? mySlot : (teamSize - mySlot + 1);
    const myPickInRound = (round - 1) * teamSize + slotPick;
    // Find next pick in next round
    const nextRound = round + 1;
    const nextIsOdd = nextRound % 2 === 1;
    const nextSlotPick = nextIsOdd ? mySlot : (teamSize - mySlot + 1);
    const myNextPick = (nextRound - 1) * teamSize + nextSlotPick;
    return myNextPick - myPickInRound - 1;
  }

  function rosterCounts(roster) {
    const c = { QB: 0, RB: 0, WR: 0, TE: 0 };
    for (const p of roster) c[p.s] = (c[p.s] || 0) + 1;
    return c;
  }

  function byeBreakdown(roster) {
    const bye = {};
    for (const p of roster) {
      if (p.bye == null) continue;
      bye[p.bye] = (bye[p.bye] || 0) + 1;
    }
    return bye;
  }

  // Position-need score: SUBTLE adjustment, rank dominates.
  // Returns a multiplier (1.0 = neutral, range tightened to keep rank as primary).
  function positionNeedMult(pos, counts, round) {
    const f = FORMAT.slots;
    const min = FORMAT.minPos;
    const max = FORMAT.maxPos;
    const have = counts[pos] || 0;
    const target = f[pos] || 0;

    // Hard ceiling: never go above max position count
    if (have >= max[pos]) return 0.20;

    // Soft mild boost only when truly missing a position late in the draft.
    // Range capped at 1.10 so rank stays primary.
    if (have === 0 && round >= 8 && (pos === "QB" || pos === "TE")) return 1.10;
    if (have === 0 && round >= 6 && (pos === "RB" || pos === "WR")) return 1.10;
    if (have < min[pos] && round >= 10) return 1.05;

    // At or above target but below max — slight penalty (don't overload at one position)
    if (have >= target) return 0.92;

    return 1.0;
  }

  // ADP-vs-rank value: when Underdog ranks a player much higher than Jack,
  // taking them is "expensive." When Jack ranks much higher than UD,
  // it's a steal worth flagging.
  function adpValue(player, pickNum) {
    if (player.udA == null) return { tag: null, multiplier: 1.0 };
    const ud = player.udA;
    const myRank = player.rank;
    const diff = ud - myRank; // +ve = UD has them later than Jack (Jack high on them)
    if (diff >= 24) return { tag: "STEAL", multiplier: 1.20 };
    if (diff >= 12) return { tag: "Value", multiplier: 1.10 };
    if (diff <= -18) return { tag: "Reach", multiplier: 0.85 };
    if (diff <= -10) return { tag: "Stretch", multiplier: 0.95 };
    return { tag: null, multiplier: 1.0 };
  }

  // Bye-week clustering penalty: if I already have N at a position
  // and this player shares their bye with M of those, the lineup gets
  // hurt that week. Best ball still scores everyone, but stacking too many
  // byes wastes draft capital.
  function byeMult(player, roster) {
    if (player.bye == null) return 1.0;
    const sameBye = roster.filter(p => p.bye === player.bye).length;
    const samePosBye = roster.filter(p => p.bye === player.bye && p.s === player.s).length;
    if (samePosBye >= 2) return 0.85;       // 3 of same pos sharing bye = bad
    if (sameBye >= 4) return 0.92;          // crowded bye week
    return 1.0;
  }

  // Stack bonus: QB on same team as my WR/TE (or vice versa) for week 16/17 correlation.
  // Currently checks any-week, but once schedule is loaded we'll bias toward W16/17 games.
  function stackBonus(player, roster) {
    if (!player.t) return 1.0;
    if (player.s === "QB") {
      const targets = roster.filter(p => p.t === player.t && (p.s === "WR" || p.s === "TE"));
      if (targets.length >= 2) return 1.10;
      if (targets.length === 1) return 1.05;
    } else if (player.s === "WR" || player.s === "TE") {
      const qb = roster.find(p => p.t === player.t && p.s === "QB");
      if (qb) return 1.05;
    }
    return 1.0;
  }

  // ---------- Core scoring ----------
  // When isSuperflex is true:
  //   - "ud"        → use player.sfa (Underdog Superflex ADP) instead of udA
  //   - "jacks"/etc → use player.sfRank (derived from sfa) instead of player.rank
  //                   (with fallback to standard rank if sfRank/sfa missing)
  // The fallback matters because some players (devy, deep bench) don't have
  // an Underdog superflex ADP — we still want them ranked, just at the bottom
  // of the superflex board.
  function rankFromSource(player, src, isSuperflex) {
    if (isSuperflex) {
      if (src === "ud") return player.sfa != null ? Math.round(player.sfa) : (player.udA != null ? Math.round(player.udA) + 200 : 9999);
      // Jack's / FP / Consensus all use sfRank when available; otherwise fall
      // back to standard rank with a heavy penalty so non-SF-ranked players
      // sink to the bottom rather than disappearing.
      const sfFallback = (player.rank || 9999) + 200;
      if (src === "fp") return player.sfRank || (player.fpR ? player.fpR + 100 : sfFallback);
      if (src === "sleeper") return player.sfRank || (player.slR ? player.slR + 100 : sfFallback);
      if (src === "consensus") {
        const arr = [];
        if (player.sfRank) arr.push(player.sfRank);
        if (player.sfa != null) arr.push(Math.round(player.sfa));
        if (arr.length) return arr.reduce((a, b) => a + b, 0) / arr.length;
        return sfFallback;
      }
      return player.sfRank || sfFallback; // default = jack's superflex
    }
    if (src === "ud") return player.udA != null ? Math.round(player.udA) : 9999;
    if (src === "fp") return player.fpR || 9999;
    if (src === "sleeper") return player.slR || 9999;
    if (src === "consensus") {
      const arr = [];
      if (player.rank) arr.push(player.rank);
      if (player.fpR) arr.push(player.fpR);
      if (player.slR) arr.push(player.slR);
      if (player.udA != null) arr.push(Math.round(player.udA));
      return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 9999;
    }
    return player.rank || 9999;
  }

  function detectNeed(pos, counts, round, isSuperflex, teamSize) {
    if (round < 6) return null;
    const have = counts[pos] || 0;
    const sf = !!isSuperflex;
    const ts = teamSize || 12;
    const lateRound = ts < 12 ? Math.max(6, 8 - Math.round((12 - ts) / 4)) : 8;
    if (round >= lateRound && pos === "QB") {
      const qbTarget = sf ? 2 : 1;
      if (have < qbTarget) return "qb";
    }
    if (round >= lateRound && pos === "TE" && have === 0) return "te";
    if (pos === "RB" && have < 2) return "rb";
    if (pos === "WR" && have < 3) return "wr";
    return null;
  }

  function scorePlayer(player, ctx) {
    const { round, counts, roster, pickNum, rankSrc = "jacks", isSuperflex = false, teamSize = FORMAT.teamSize, available = null } = ctx;
    const r = rankFromSource(player, rankSrc, isSuperflex);
    const base = 100 * Math.exp(-Math.pow(r / 80, 1.0));
    const adp = adpValue(player, pickNum);
    const bye = byeMult(player, roster);
    const stack = stackBonus(player, roster);
    const score = base;
    const needFlag = detectNeed(player.s, counts, round, isSuperflex, teamSize);
    const tierInfo = available ? detectVorTier(player, available, isSuperflex) : null;
    const why = [];
    if (adp.tag) why.push(adp.tag);
    if (tierInfo) why.push(tierInfo.type === "cliff" ? "TIER!" : "TIER");
    return {
      score: Math.round(score * 10) / 10,
      base: Math.round(base * 10) / 10,
      r,
      flags: { stack: stack > 1.0, need: needFlag, bye: bye < 1.0, tier: tierInfo },
      why
    };
  }

  function recommend(args) {
    const {
      players, draftedSet, myRoster,
      pickNum = 1, slot = 6, teamSize = FORMAT.teamSize, topN = 6,
      rankSrc = "jacks", isSuperflex = false
    } = args;
    const round = pickToRound(pickNum, teamSize);
    const counts = rosterCounts(myRoster);
    const available = players.filter(p => !draftedSet.has(p.n));
    const ctx = { round, counts, roster: myRoster, pickNum, rankSrc, isSuperflex, teamSize, available };
    const candidates = [];
    for (const p of available) {
      const s = scorePlayer(p, ctx);
      candidates.push({ player: p, ...s });
    }
    candidates.sort((a, b) => (a.r || 9999) - (b.r || 9999));
    return candidates.slice(0, topN);
  }

  global.MFFEngine_detectNeed = detectNeed;

  function rosterReport(myRoster, pickNum, teamSize, isSuperflex, players, draftedSet) {
    if (teamSize == null) teamSize = FORMAT.teamSize;
    const counts = rosterCounts(myRoster);
    const byeMap = byeBreakdown(myRoster);
    const round = pickToRound(pickNum, teamSize);
    const totalPicks = myRoster.length;
    const f = fmt(isSuperflex);
    const remaining = f.rounds - totalPicks;
    const vorByPos = rosterVorByPos(myRoster, isSuperflex);
    const bestAvail = (players && draftedSet)
      ? bestVorAvailable(players, draftedSet, isSuperflex)
      : null;
    return {
      counts, byes: byeMap, round, pickNum, totalPicks, remaining,
      vorByPos, bestAvail,
      format: { rounds: f.rounds, slots: f.slots, isSuperflex: !!isSuperflex },
      flags: rosterFlags(counts, totalPicks, remaining, isSuperflex)
    };
  }

  function rosterFlags(counts, totalPicks, remaining, isSuperflex) {
    const flags = [];
    const sf = !!isSuperflex;
    if (totalPicks >= 6) {
      if ((counts.RB || 0) === 0) flags.push({ level: "warn", msg: "0 RBs through 6 rounds" });
      if ((counts.WR || 0) === 0) flags.push({ level: "warn", msg: "0 WRs through 6 rounds" });
    }
    if (totalPicks >= 10) {
      if ((counts.QB || 0) === 0) flags.push({ level: "warn", msg: "Still no QB by R10" });
      if ((counts.TE || 0) === 0) flags.push({ level: "warn", msg: "Still no TE by R10" });
    }
    if (totalPicks >= 14) {
      const qbTarget = sf ? 2 : 1;
      if ((counts.QB || 0) < qbTarget) flags.push({ level: "warn", msg: sf ? "Need a 2nd QB by R14" : "Still no QB late" });
      if ((counts.TE || 0) < 1) flags.push({ level: "warn", msg: "0 TE through R14" });
    }
    return flags;
  }

  // ============================================================
  // BBM (Best Ball Mania) historical advance-rate analysis
  // Computed from 2.5M Underdog BBM rosters (BBM II–VI, 2021–2025)
  // Powered by data/bbm_data.js → window.BBM_DATA
  // ============================================================

  // Hard caps based on actual BBM data analysis (advance rate by count):
  //   QB:  3 max (4 QBs = 0.91x baseline — never historically optimal)
  //   RB:  7 max (8+ RBs = 0.74x baseline — RB depth dies hard)
  //   WR: 10 max (11+ WRs = 0.64x baseline — too thin elsewhere)
  //   TE:  3 max (4+ TEs averaged 0.97x; 5+ = 0.72x; not worth the rare upside)
  const BBM_MAX_POS = { QB: 3, RB: 7, WR: 10, TE: 3 };
  // v0.9.94: practical minimums. Single-QB / single-TE builds appear in
  // the data but are bye-week / injury suicide in best ball — never
  // recommend them even if a tiny sample shows a fluky high advance rate.
  const BBM_MIN_POS = { QB: 2, RB: 3, WR: 4, TE: 2 };

  function _bbmReachableBuilds(currentCounts, picksMade, byBuild, minN) {
    minN = minN || 1000;
    const remaining = 18 - (picksMade || 0);
    const out = [];
    for (const build in byBuild) {
      const parts = build.split('/');
      if (parts.length !== 4) continue;
      const q = +parts[0], r = +parts[1], w = +parts[2], t = +parts[3];
      if (q + r + w + t !== 18) continue;
      const cQ = currentCounts.QB || 0, cR = currentCounts.RB || 0;
      const cW = currentCounts.WR || 0, cT = currentCounts.TE || 0;
      if (q < cQ || r < cR || w < cW || t < cT) continue;
      // v0.9.94: enforce min/max caps — never recommend < 2 QB or < 2 TE.
      if (q < BBM_MIN_POS.QB || r < BBM_MIN_POS.RB || w < BBM_MIN_POS.WR || t < BBM_MIN_POS.TE) continue;
      if (q > BBM_MAX_POS.QB || r > BBM_MAX_POS.RB || w > BBM_MAX_POS.WR || t > BBM_MAX_POS.TE) continue;
      const need = (q - cQ) + (r - cR) + (w - cW) + (t - cT);
      if (need !== remaining) continue;
      const stats = byBuild[build];
      if (stats.n < minN) continue;
      out.push({ build: build, q: q, r: r, w: w, t: t,
                 n: stats.n, q_rate: stats.q_rate,
                 s_rate: stats.s_rate, f_rate: stats.f_rate });
    }
    return out;
  }

  // Optimal final build given (currentCounts, slot, picksMade).
  // Returns {QB, RB, WR, TE, q_rate, n, build} or null.
  function bbmOptimalBuild(currentCounts, slot, picksMade, opts) {
    if (typeof window === 'undefined' || !window.BBM_DATA) return null;
    opts = opts || {};
    const data = window.BBM_DATA;
    // v0.9.93: level-aware. opts.level ∈ 'q' (top-2 / made_quarters), 's'
    // (made_semis), 'f' (made_finals). Default 'q' preserves prior behavior.
    const _lvl = (opts.level === 's' || opts.level === 'f') ? opts.level : 'q';
    const _F = _lvl + '_rate';      // unweighted field name e.g. 'q_rate'
    const _FW = _lvl + '_rate_w';   // recency-weighted field name
    const _LBASE = { q: 'made_quarters', s: 'made_semis', f: 'made_finals' }[_lvl];
    let byBuild = data.by_build;
    if (opts.year && data.by_build_year && data.by_build_year[opts.year]) {
      byBuild = data.by_build_year[opts.year];
    }
    // v0.10.0: sample-size floors scale with the rarity of the level.
    // Finals baseline is ~0.08% (200x rarer than QF's 16.7%), so n=1000
    // means only ~0.8 expected advancers — pure noise. We require enough
    // sample so the cohort has >=30 expected advancers in every level.
    //   QF baseline ~16.7% → 1000 teams ≈ 167 advancers ✓
    //   SF baseline ~1.32% → 5000 teams ≈ 66 advancers ✓
    //   Fin baseline ~0.08% → 30000 teams ≈ 25 advancers ✓
    // Without this fix, exotic small-sample builds (e.g. 3/3/9/3, n=2700)
    // win the Finals lottery on noise.
    const _LEVEL_MIN_N = { q: 1000, s: 5000, f: 30000 };
    const _LEVEL_FALLBACK_N = { q: 500, s: 2000, f: 10000 };
    const minN = _LEVEL_MIN_N[_lvl] || 1000;
    const fallbackN = _LEVEL_FALLBACK_N[_lvl] || 500;
    let reach = _bbmReachableBuilds(currentCounts, picksMade || 0, byBuild, minN);
    if (!reach.length) reach = _bbmReachableBuilds(currentCounts, picksMade || 0, byBuild, fallbackN);
    if (!reach.length) return null;

    // Pick the best build SHAPE using overall (slot-agnostic) advance rate.
    // Slot mostly affects which players you get, not which roster shape wins —
    // year-to-year top builds at any slot are very similar. Slot baseline rate
    // is exposed separately for the UI so users can see both signals.
    // PREFIX-CONDITIONAL: when caller passes opts.prefix (the position-letter
    // string of picks 1..K like "RRQ"), use the historical advance rate of
    // teams that had this exact pick prefix AND ended at each candidate
    // build. This is the order-aware signal — "RRQ" predicts a different
    // optimal completion than "WWQ" even when both are 1Q/2R/0W/0T.
    const prefix = (opts.prefix || '').toUpperCase().replace(/[^QRWT]/g, '').slice(0, 6);
    // Prefer recency-weighted prefix data (2024-2025 = 2-2.5x weight) when available
    const useWeighted = (opts.weighted !== false);
    const pDataW = (prefix && data.by_prefix_build_w) ? data.by_prefix_build_w[prefix] : null;
    const pData = (prefix && data.by_prefix_build) ? data.by_prefix_build[prefix] : null;
    const usePrefixW = useWeighted && !!(pDataW && Object.keys(pDataW).length >= 3);
    const usePrefix = !!(pData && Object.keys(pData).length >= 3);
    // Recency-weighted by_build (slot-agnostic) — fallback if prefix weighted unavailable
    const bbW = (useWeighted && data.by_build_w) ? data.by_build_w : null;

    // STATISTICAL SHRINKAGE: regularize rates toward baseline based on sample size.
    // adjusted = (n*observed + K*baseline) / (n + K). K=2000 means small-sample
    // builds (e.g. n=138) get pulled hard toward 16.7% baseline; high-n builds
    // (e.g. n=300k) barely move. Prevents recommending exotic 5-TE builds based
    // on noise from a tiny sample of weirdos.
    const baseline = (data.meta && data.meta.level_baselines && data.meta.level_baselines[_LBASE]) || ({q:0.1667, s:0.013, f:0.000809}[_lvl]);
    // v0.10.0: shrinkage K also scales with level rarity. At Finals stage,
    // single-cohort variance is huge — even n=10k builds can swing the
    // observed f_rate by 30%+. Stronger prior pulls these back to baseline
    // so the recommendation is structurally sound, not lottery-driven.
    const _LEVEL_SHRINK_PREFIX = { q: 5000, s: 15000, f: 50000 };
    const _LEVEL_SHRINK_GLOBAL = { q:  500, s:  3000, f: 15000 };
    const SHRINK_K_PREFIX = _LEVEL_SHRINK_PREFIX[_lvl] || 5000;
    const SHRINK_K_GLOBAL = _LEVEL_SHRINK_GLOBAL[_lvl] || 500;
    function shrink(observedRate, n, K) {
      if (n == null || !isFinite(n) || n <= 0) return baseline;
      return (n * observedRate + K * baseline) / (n + K);
    }
    // Hard minimum sample so we don't even consider absolute noise
    const MIN_PREFIX_N = 300;

    // Two-pass approach:
    //   PASS 1: find global-best reachable build (high-sample, proven)
    //   PASS 2: check if prefix-best has a meaningful edge over global-best
    //           (>= 1.5pp after shrinkage). If so, use it. Otherwise stick
    //           with global-best — avoids exotic small-sample builds winning
    //           on noisy prefix-conditional data.
    let globalBest = null;
    for (let i = 0; i < reach.length; i++) {
      const b = reach[i];
      const wRate = (bbW && bbW[b.build] && bbW[b.build][_FW] != null) ? bbW[b.build][_FW] : b[_F];
      const wN = (bbW && bbW[b.build]) ? bbW[b.build].n : b.n;
      const shrunk = shrink(wRate, wN, SHRINK_K_GLOBAL);
      if (!globalBest || shrunk > globalBest.rate) {
        globalBest = { rate: shrunk, n: wN, build: b.build, q: b.q, r: b.r, w: b.w, t: b.t, src: bbW && bbW[b.build] ? 'global-w' : 'global' };
      }
    }

    let prefixBest = null;
    if (usePrefixW || usePrefix) {
      for (let i = 0; i < reach.length; i++) {
        const b = reach[i];
        let pStat = null, isW = false;
        if (usePrefixW && pDataW[b.build]) { pStat = pDataW[b.build]; isW = true; }
        else if (usePrefix && pData[b.build]) { pStat = pData[b.build]; }
        if (!pStat || pStat.n < MIN_PREFIX_N) continue;
        const rawRate = isW ? pStat[_FW] : pStat[_F];
        if (rawRate == null) continue;
        const shrunk = shrink(rawRate, pStat.n, SHRINK_K_PREFIX);
        if (!prefixBest || shrunk > prefixBest.rate) {
          prefixBest = { rate: shrunk, n: pStat.n, build: b.build, q: b.q, r: b.r, w: b.w, t: b.t, src: (isW ? 'prefix-w:' : 'prefix:') + prefix };
        }
      }
    }

    // Use prefix recommendation only if it beats global by >= 1.5pp meaningful threshold.
    const PREFIX_EDGE_REQUIRED = 0.015;
    let bestRate, bestN, bestBuild, bestSrc, bestQ, bestR, bestW, bestT;
    if (prefixBest && globalBest && prefixBest.rate >= globalBest.rate + PREFIX_EDGE_REQUIRED) {
      bestRate = prefixBest.rate; bestN = prefixBest.n; bestBuild = prefixBest.build;
      bestSrc = prefixBest.src;
      bestQ = prefixBest.q; bestR = prefixBest.r; bestW = prefixBest.w; bestT = prefixBest.t;
    } else if (globalBest) {
      bestRate = globalBest.rate; bestN = globalBest.n; bestBuild = globalBest.build;
      bestSrc = globalBest.src;
      bestQ = globalBest.q; bestR = globalBest.r; bestW = globalBest.w; bestT = globalBest.t;
    } else {
      return null;
    }
    // Lookup slot-specific rate for THIS build (informational, not used for selection)
    let slotRate = null, slotN = null, slotBaseline = null;
    if (slot && data.by_construct_slot) {
      const sk = bestBuild + '@' + slot;
      const ss = data.by_construct_slot[sk];
      if (ss && ss.n >= 200 && ss[_F] != null) { slotRate = ss[_F]; slotN = ss.n; }
    }
    if (slot && data.by_slot && data.by_slot[String(slot)] && data.by_slot[String(slot)][_F] != null) {
      slotBaseline = data.by_slot[String(slot)][_F];
    }
    return { QB: bestQ, RB: bestR, WR: bestW, TE: bestT,
             q_rate: bestRate, rate: bestRate, level: _lvl,
             n: bestN, build: bestBuild,
             slot_rate: slotRate, slot_n: slotN, slot_baseline: slotBaseline,
             source: bestSrc, prefix: prefix || null };
  }

  // For the upcoming pick, compute expected advance rate IF you take each
  // position next. Uses the BEST achievable build from the new state
  // (assumes optimal subsequent play). For early picks (1-6), also factors
  // in position-timing data (when did first QB/TE come) for realism.
  // Returns {QB, RB, WR, TE, recommended} where each value is a probability
  // or null if that position isn't valid/sampled.
  function bbmNextPickRates(currentCounts, slot, picksMade, opts) {
    if (typeof window === 'undefined' || !window.BBM_DATA) return null;
    opts = opts || {};
    const data = window.BBM_DATA;
    // v0.9.93: level-aware. Same level handling as bbmOptimalBuild.
    const _lvl = (opts.level === 's' || opts.level === 'f') ? opts.level : 'q';
    const _F = _lvl + '_rate';
    const _FW = _lvl + '_rate_w';
    // v0.10.0: per-level minimum sample so rare-event levels (Finals 0.08%
    // baseline) don't accept noisy small-sample cohorts.
    const _NXT_MIN = { q: 1000, s: 5000, f: 30000 }[_lvl] || 1000;
    const _NXT_MIN_TP = { q: 500, s: 3000, f: 20000 }[_lvl] || 500;
    let byBuild = data.by_build;
    if (opts.year && data.by_build_year && data.by_build_year[opts.year]) {
      byBuild = data.by_build_year[opts.year];
    }
    const out = { QB: null, RB: null, WR: null, TE: null };
    const detail = {};
    const buildOut = {};  // best build per position choice
    const positions = ['QB','RB','WR','TE'];
    const nextTeamPick = (picksMade || 0) + 1;

    for (let pi = 0; pi < positions.length; pi++) {
      const pos = positions[pi];
      const newCounts = {
        QB: (currentCounts.QB||0) + (pos==='QB'?1:0),
        RB: (currentCounts.RB||0) + (pos==='RB'?1:0),
        WR: (currentCounts.WR||0) + (pos==='WR'?1:0),
        TE: (currentCounts.TE||0) + (pos==='TE'?1:0)
      };
      if (newCounts[pos] > BBM_MAX_POS[pos]) continue;
      // Best build achievable from new state, incl. the hypothetical pick.
      // Pass null slot but include prefix so order-conditional data wins.
      const newPrefix = ((opts.prefix||'') + pos).slice(0, 6);
      const best = bbmOptimalBuild(newCounts, null, nextTeamPick, Object.assign({}, opts, { prefix: newPrefix }));
      if (!best) continue;
      // v0.9.92: PRIMARY rate is now the actual historical advance rate of
      // teams that started with this exact position prefix (e.g. "RRRR"
      // after taking a 4th RB on top of an RRR start). Previously the
      // primary was best.q_rate — the rate IF you played optimally
      // afterward — which inflated bad early picks (QB R1 displayed at
      // ~11.7% when teams that took QB R1 historically advanced ~6%).
      // Now we use the prefix-conditional realRate that captures the
      // RRR→RB-vs-RRR→WR distinction the user actually cares about.
      // The optimal hypothetical rate is preserved as detail.optimalRate
      // for secondary display.
      const optimalRate = best.q_rate;
      const newPrefixForRate = ((opts.prefix || '') + pos).slice(0, 6);
      let realRate = null, realN = null, realSrc = null;
      // 1) prefix-conditional aggregate across all final builds reachable
      //    from this prefix. Captures RRRR (4th RB) vs WWWR (1st RB) etc.
      const prefData = (data.by_prefix_build_w && data.by_prefix_build_w[newPrefixForRate]) ||
                       (data.by_prefix_build && data.by_prefix_build[newPrefixForRate]) || null;
      if (prefData) {
        let totN = 0, weighted = 0;
        for (const bk in prefData) {
          const ps = bk.split('/').map(Number);
          if (ps.length !== 4) continue;
          // Only count builds reachable from new counts (pos counts ≥ newCounts).
          if (ps[0] < newCounts.QB || ps[1] < newCounts.RB ||
              ps[2] < newCounts.WR || ps[3] < newCounts.TE) continue;
          // v0.9.94: enforce MIN_POS so bye-week-suicide single-QB / single-TE
          // builds never contribute to the recommended next-pick rate.
          if (ps[0] < BBM_MIN_POS.QB || ps[1] < BBM_MIN_POS.RB ||
              ps[2] < BBM_MIN_POS.WR || ps[3] < BBM_MIN_POS.TE) continue;
          if (ps[0] > BBM_MAX_POS.QB || ps[1] > BBM_MAX_POS.RB ||
              ps[2] > BBM_MAX_POS.WR || ps[3] > BBM_MAX_POS.TE) continue;
          const stat = prefData[bk];
          if (!stat || !stat.n) continue;
          const r = stat[_FW] != null ? stat[_FW] : stat[_F];
          if (r == null) continue;
          totN += stat.n;
          weighted += stat.n * r;
        }
        // v0.10.0: per-level minimum so rare-event levels filter out small samples
        if (totN >= _NXT_MIN) {
          realRate = weighted / totN;
          realN = totN;
          realSrc = 'prefix:' + newPrefixForRate;
        }
      }
      // 2) Fallback: by-team-pick (QB / TE only) or by-round (all positions).
      const willBeFirst = ((currentCounts[pos]||0) === 0);
      if (realRate == null && willBeFirst) {
        const tpKey = String(nextTeamPick);
        let tpData = null;
        if (pos === 'QB' && data.by_first_qb_tp) tpData = data.by_first_qb_tp[tpKey];
        else if (pos === 'TE' && data.by_first_te_tp) tpData = data.by_first_te_tp[tpKey];
        if (tpData && tpData.n >= _NXT_MIN_TP && tpData[_F] != null) {
          realRate = tpData[_F]; realN = tpData.n; realSrc = 'first_' + pos.toLowerCase() + '_tp';
        } else {
          const rdKey = String(Math.ceil(nextTeamPick / 12));
          const rdMap = data['by_first_' + pos.toLowerCase() + '_round'];
          if (rdMap && rdMap[rdKey] && rdMap[rdKey].n >= _NXT_MIN_TP && rdMap[rdKey][_F] != null) {
            realRate = rdMap[rdKey][_F]; realN = rdMap[rdKey].n; realSrc = 'first_' + pos.toLowerCase() + '_round';
          }
        }
      }
      // Display the historical reality if we have it; otherwise fall back
      // to the optimistic best-build rate so the cell isn't blank.
      out[pos] = realRate != null ? realRate : optimalRate;
      buildOut[pos] = best.QB + '/' + best.RB + '/' + best.WR + '/' + best.TE;
      detail[pos] = {
        n: best.n,
        build: buildOut[pos],
        optimalRate: optimalRate,
        realRate: realRate,
        realN: realN,
        realSrc: realSrc
      };
    }
    let rec = null, recRate = -1;
    for (let pi = 0; pi < positions.length; pi++) {
      const pos = positions[pi];
      if (out[pos] != null && out[pos] > recRate) { rec = pos; recRate = out[pos]; }
    }
    return { QB: out.QB, RB: out.RB, WR: out.WR, TE: out.TE,
             recommended: rec, detail: detail, builds: buildOut };
  }

  function bbmStartingBuild(slot, opts) {
    return bbmOptimalBuild({QB:0,RB:0,WR:0,TE:0}, slot, 0, opts);
  }

  // ============================================================
  // BBM positional value-cliff alerts
  // ============================================================
  // Cliffs computed from 2023+2024 BBM data (avg season fantasy points by
  // ADP round). Each cliff = "drafting in round X gets you Y more points
  // than waiting one more round". Big cliffs = scarcity windows.
  // ============================================================

  // BBM_MILESTONES — only TRUE cliffs (drop >= 45 pts in single-round transition).
  // Each entry: "by team pick `byPick`, you should have `min` of `pos`."
  // This is what the data actually supports — no speculation, no staircase noise.
  //
  // Methodology: combined 2023+2024 BBM season points by ADP round, only
  // single-round transitions with drop >= 45 pts qualify as cliffs.
  // Source: bbm_analysis/players/ extracts of Round 1 pick_points.
  const BBM_MILESTONES = [
    // WR — alpha receiver tier; biggest single-round cliff in fantasy (-67 pts)
    { pos: 'WR', min: 1, byPick: 2,  cliffDrop: 67,
      label: 'WR1 by pick 2',
      rationale: 'Alpha WR1 averages 165 pts; WR2 averages 97. Biggest pos cliff in the data.' },
    // QB — elite top-3 tier (-65 pts after R3)
    { pos: 'QB', min: 1, byPick: 3,  cliffDrop: 65,
      label: 'QB1 by pick 3 — OR plan to wait until pick 10',
      rationale: 'Top-3 QBs (Allen/Lamar/Mahomes) avg 233 pts; R4-R8 QBs avg 95-170 with high variance. Either pay up or punt.' },
    // RB — tier 2 collapse (-50 pts at R7-R8 zone)
    { pos: 'RB', min: 2, byPick: 7,  cliffDrop: 50,
      label: '2 RBs by pick 7',
      rationale: 'RB scoring drops from ~110 pts (R5-R7) to ~70 pts after R8. Get your starter pair before this transition.' },
    // QB — late-bloomer window (-67 pts after R10)
    { pos: 'QB', min: 1, byPick: 10, cliffDrop: 67,
      label: 'QB1 by pick 10 (if not from elite tier)',
      rationale: 'R9-R10 had the Lamar/Burrow late-bloomers (~160+ pts). After R10, QB output drops to 60-95 pt range.' },
    // WR — late depth cliff (-48 pts at R13)
    { pos: 'WR', min: 4, byPick: 12, cliffDrop: 48,
      label: '4 WRs by pick 12',
      rationale: 'WRs drafted in R13+ avg under 30 pts. Lock down your usable WR depth before R13.' },
  ];

  // Backward-compat: keep old structure but stripped to true cliffs only
  const BBM_CLIFFS = {
    QB: [
      { round: 4,  drop: 65, kind: 'cliff', label: 'Elite QB tier ends' },
      { round: 11, drop: 67, kind: 'cliff', label: 'Late QB window closing' },
    ],
    RB: [
      { round: 8,  drop: 50, kind: 'cliff', label: 'RB tier-2 cliff' },
    ],
    WR: [
      { round: 2,  drop: 67, kind: 'cliff', label: 'WR1 separation cliff' },
      { round: 13, drop: 48, kind: 'cliff', label: 'Late WR cliff' },
    ],
    TE: [],
  };

  // Hard floors — minimum count needed by end of draft.
  const BBM_FLOOR = { QB: 2, RB: 4, WR: 5, TE: 1 };

  // Compute milestone status for the user's current draft state.
  // Returns array of { pos, min, byPick, status, picksLeft, label, rationale }
  // where status is one of:
  //   'done'    — already have >= min at this position before deadline
  //   'on-track' — don't have it yet but still have picks left before deadline
  //   'at-risk' — next pick IS the deadline pick and we don't have it
  //   'missed'  — past the deadline and don't have it (cliff already happened)
  //   'pending' — deadline not reached yet, we already have min
  function bbmMilestones(currentCounts, picksMade) {
    const out = [];
    const nextPick = (picksMade || 0) + 1;
    for (let i = 0; i < BBM_MILESTONES.length; i++) {
      const m = BBM_MILESTONES[i];
      const have = currentCounts[m.pos] || 0;
      const picksLeft = m.byPick - nextPick + 1; // how many picks until and including byPick
      let status;
      if (have >= m.min) status = 'done';
      else if (picksLeft <= 0) status = 'missed';
      else if (picksLeft === 1) status = 'at-risk';
      else status = 'on-track';
      out.push({
        pos: m.pos, min: m.min, byPick: m.byPick, have: have, status: status,
        picksLeft: picksLeft, cliffDrop: m.cliffDrop,
        label: m.label, rationale: m.rationale
      });
    }
    return out;
  }

  // Legacy alert function for backward compatibility — not used by new UI
  function bbmValueAlerts(currentCounts, picksMade) {
    const alerts = [];
    const nextTeamPick = (picksMade || 0) + 1;
    const remaining = 18 - (picksMade || 0);
    if (nextTeamPick > 18) return alerts;

    for (const pos of ['QB','RB','WR','TE']) {
      const have = currentCounts[pos] || 0;
      const floor = BBM_FLOOR[pos];
      const need = Math.max(0, floor - have);
      const cliffs = BBM_CLIFFS[pos] || [];

      for (const cliff of cliffs) {
        // Cliff round = ROUND in which value drops (drafting in cliff.round-1 is +drop pts)
        // Active if: nextTeamPick is at or just before the cliff round AND we have unmet need
        const distance = cliff.round - nextTeamPick; // 0 = at cliff, 1 = next-pick-after = pre-cliff
        if (distance < 0) continue;       // already past
        if (distance > 2) continue;       // too far away

        // Skip if position is filled past its floor by a comfortable margin
        if (have >= floor + 1 && cliff.drop < 50) continue;
        // Hard skip if absolute max
        if ((pos === 'QB' && have >= 4) || (pos === 'TE' && have >= 4)) continue;

        const kind = cliff.kind || 'cliff';
        let level = 'info';
        // Only 'cliff' kind events generate urgent alerts; 'step' is info, 'soft' is soft
        if (kind === 'cliff') {
          if (distance === 0 && need > 0) level = 'urgent';
          else if (distance === 0) level = 'soft';
          else if (distance === 1 && need > 0) level = 'urgent';
          else if (distance === 1) level = 'soft';
          else level = 'info';
        } else if (kind === 'soft') {
          if (distance <= 1 && need > 0) level = 'soft';
          else level = 'info';
        } else { // 'step'
          if (distance === 0 && need > 0) level = 'soft';
          else level = 'info';
        }

        const cur = pos + ':' + have;
        const msg = '[' + pos + '] ' + cliff.label +
                    (distance === 0 ? ' (NOW — pick ' + nextTeamPick + ')'
                                    : ' (in ' + distance + ' pick' + (distance>1?'s':'') + ')') +
                    ' • ~' + cliff.drop + ' pts dropped if you wait';
        alerts.push({ level: level, position: pos, message: msg, drop: cliff.drop, distance: distance, have: have });
      }
    }
    // Sort by urgency, then by drop magnitude
    const order = { urgent: 0, soft: 1, info: 2 };
    alerts.sort(function(a,b) {
      if (order[a.level] !== order[b.level]) return order[a.level] - order[b.level];
      return b.drop - a.drop;
    });
    return alerts;
  }

  // ============================================================
  // BBM Stacking Analysis
  // ============================================================
  // Given a roster (array of player objects with .s position and .t NFL team),
  // computes stack category and historical advance rate from BBM 2024 data.
  // Stacking categories (per BBM_DATA.stacks):
  //   no_stack    — no QB has same-team WR/TE
  //   onesie      — 1 QB has +1 same-team pass catcher
  //   full2       — 1 QB has +2 same-team pass catchers
  //   full3plus   — 1 QB has +3 or more same-team pass catchers
  // Multi-QB stacking (n_stacked_qbs) is also tracked.
  // ============================================================
  function bbmStackStats(myRoster) {
    if (!myRoster || !myRoster.length) return null;
    if (typeof window === 'undefined' || !window.BBM_DATA || !window.BBM_DATA.stacks) return null;
    const data = window.BBM_DATA.stacks;

    // Identify QBs and their NFL teams; count same-team pass catchers
    const qbs = myRoster.filter(function(p) { return p && p.s === 'QB' && p.t; });
    const passCatchers = myRoster.filter(function(p) { return p && (p.s === 'WR' || p.s === 'TE') && p.t; });

    const stacks = qbs.map(function(qb) {
      const sameTeam = passCatchers.filter(function(pc) { return pc.t === qb.t; });
      return {
        qb: qb.n,
        team: qb.t,
        size: sameTeam.length,
        catchers: sameTeam.map(function(p) { return { n: p.n, s: p.s }; })
      };
    });

    let maxStack = 0;
    let nStackedQbs = 0;
    for (let i = 0; i < stacks.length; i++) {
      if (stacks[i].size > maxStack) maxStack = stacks[i].size;
      if (stacks[i].size >= 1) nStackedQbs += 1;
    }

    let category;
    if (qbs.length === 0) category = 'no_qb_yet';
    else if (maxStack === 0) category = 'no_stack';
    else if (maxStack === 1) category = 'onesie';
    else if (maxStack === 2) category = 'full2';
    else category = 'full3plus';

    const catData = data.by_category[category];
    const stackedData = data.by_n_stacked_qbs[String(nStackedQbs)];
    const baseline = data.baseline;

    return {
      category: category,
      max_stack: maxStack,
      n_stacked_qbs: nStackedQbs,
      qb_count: qbs.length,
      stacks: stacks,
      // Historical advance rate at this stack profile
      cat_rate: catData ? catData.q_rate : null,
      cat_n: catData ? catData.n : 0,
      cat_lift: catData && baseline ? catData.q_rate / baseline : null,
      stacked_rate: stackedData ? stackedData.q_rate : null,
      stacked_lift: stackedData && baseline ? stackedData.q_rate / baseline : null,
      baseline: baseline
    };
  }

  // Suggest the best stack opportunity from currently-available picks.
  // Given: my roster + best-available player list. Returns recommended pick to
  // build/extend a stack with the highest historical advance lift.
  function bbmStackOpportunities(myRoster, available) {
    if (!myRoster || !available) return null;
    return null;
  }
  global.MFFEngine = {
    FORMAT: FORMAT, FORMAT_SF: FORMAT_SF, fmt: fmt,
    recommend: recommend, rosterReport: rosterReport, rosterCounts: rosterCounts, byeBreakdown: byeBreakdown,
    pickToRound: pickToRound, picksUntilNext: picksUntilNext, scorePlayer: scorePlayer,
    playerVor: playerVor, playerUp: playerUp, detectVorTier: detectVorTier,
    rosterVorByPos: rosterVorByPos, bestVorAvailable: bestVorAvailable,
    analyzePositions: analyzePositions, suggestPosition: suggestPosition,
    analyzeRosterVolatility: analyzeRosterVolatility,
    bbmOptimalBuild: bbmOptimalBuild,
    bbmNextPickRates: bbmNextPickRates,
    bbmStartingBuild: bbmStartingBuild,
    bbmMilestones: bbmMilestones,
    bbmValueAlerts: bbmValueAlerts,
    bbmStackStats: bbmStackStats,
    bbmStackOpportunities: bbmStackOpportunities
  };
})(typeof window !== "undefined" ? window : globalThis);
