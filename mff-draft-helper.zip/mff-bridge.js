/* MFF mff-bridge — minimal restored after corruption (v0.9.94+). */
(function () {
  "use strict";
  if (window.__mffBridgeLoaded) return;
  window.__mffBridgeLoaded = true;

  function safeSet(key, val) {
    try {
      if (!chrome || !chrome.runtime || !chrome.runtime.id) return;
      chrome.storage.local.set({ [key]: val }, function(){});
    } catch(_){}
  }
  function buildPortfolio(teams) {
    const counts = {}, pairs = {};
    const numTeams = teams.length;
    for (const team of teams) {
      const sorted = [...new Set(team)].sort();
      for (let i = 0; i < sorted.length; i++) {
        counts[sorted[i]] = (counts[sorted[i]] || 0) + 1;
        for (let j = i + 1; j < sorted.length; j++) {
          const k = sorted[i] + "|" + sorted[j];
          pairs[k] = (pairs[k] || 0) + 1;
        }
      }
    }
    const percent = {};
    for (const name in counts) percent[name] = (counts[name] / numTeams) * 100;
    return { teams, counts, pairs, percent, numTeams };
  }
  document.addEventListener("mff-portfolio-update", function (e) {
    try {
      const teams = e.detail && e.detail.teams;
      if (!Array.isArray(teams) || !teams.length) return;
      const p = buildPortfolio(teams);
      p.syncedAt = (e.detail && e.detail.syncedAt) || Date.now();
      safeSet("mff_portfolio", p);
    } catch(_){}
  });
  document.addEventListener("mff-rankings-update", function (e) {
    try {
      const rankings = e.detail && e.detail.rankings;
      if (!Array.isArray(rankings) || !rankings.length) return;
      safeSet("mff_rankings", { rankings: rankings, syncedAt: (e.detail && e.detail.syncedAt) || Date.now() });
    } catch(_){}
  });
  document.addEventListener("mff-user-update", function (e) {
    try {
      const user = e.detail && e.detail.user;
      const payload = user ? Object.assign({}, user, { syncedAt: (e.detail && e.detail.syncedAt) || Date.now() }) : null;
      safeSet("mff_user", payload);
    } catch(_){}
  });
  document.addEventListener("mff-existing-draft-ids", function (e) {
    try {
      const ids = e.detail && e.detail.ids;
      if (!Array.isArray(ids)) return;
      safeSet("mff_existing_draft_ids", ids);
      safeSet("mff_existing_draft_ids_at", (e.detail && e.detail.syncedAt) || Date.now());
    } catch(_){}
  });
  document.addEventListener("mff-set-player-adps", function (e) {
    try {
      const detail = e.detail || {};
      if (!detail.adps) return;
      safeSet("mff_player_adps_snapshot", detail);
    } catch(_){}
  });
  document.addEventListener("mff-clear-extension-cache", function () {
    try {
      if (!chrome || !chrome.runtime || !chrome.runtime.id) return;
      chrome.storage.local.remove(["mff_portfolio_sync","mff_existing_draft_ids","mff_existing_draft_ids_at","mff_portfolio"], function(){});
    } catch(_){}
  });

  // Push synced portfolio back to MFF site (mff_portfolio_sync → page event)
  function pushSitePortfolio(p) {
    if (!p) return;
    try {
      document.dispatchEvent(new CustomEvent("mff-portfolio-from-extension", {
        detail: { portfolio: p, syncedAt: p.syncedAt || Date.now() }
      }));
    } catch(_){}
  }
  function pushAdpSnapshot(s) {
    if (!s || !s.adps) return;
    try {
      document.dispatchEvent(new CustomEvent("mff-set-player-adps", { detail: s }));
    } catch(_){}
  }
  try {
    chrome.storage.local.get(["mff_portfolio_sync","mff_player_adps_snapshot"], function (res) {
      if (res && res.mff_portfolio_sync) pushSitePortfolio(res.mff_portfolio_sync);
      if (res && res.mff_player_adps_snapshot) pushAdpSnapshot(res.mff_player_adps_snapshot);
    });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local") return;
      if (changes.mff_portfolio_sync && changes.mff_portfolio_sync.newValue) pushSitePortfolio(changes.mff_portfolio_sync.newValue);
      if (changes.mff_player_adps_snapshot && changes.mff_player_adps_snapshot.newValue) pushAdpSnapshot(changes.mff_player_adps_snapshot.newValue);
    });
  } catch(_){}
})();
