/* MFF ESPN League Import — espn.js (content script on fantasy.espn.com)
 *
 * Runs on any fantasy.espn.com/football/* page. When the URL carries a
 * leagueId, shows a small floating "Export to MFF" button. Clicking it
 * fetches the league from ESPN's own v3 API *from inside the user's
 * logged-in session* (credentials: include → espn_s2 + SWID ride along
 * automatically, private leagues included — no cookie pasting), normalizes
 * it (normalize.js), and stores it in chrome.storage.local. The
 * mff-bridge.js content script on myfantasyfootball.co picks it up from
 * there and hands it to the site.
 */
(function () {
  "use strict";
  if (window.__mffEspnLoaded) return;
  window.__mffEspnLoaded = true;

  var API = "https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/";
  // mDraftDetail + mMatchup ride along (credentialed, so private leagues
  // included) — normalize.js turns them into the payload's `draft` block
  // (My Teams draft board) and `schedule` (My Teams matchup view).
  var VIEWS = "?view=mTeam&view=mRoster&view=mSettings&view=mDraftDetail&view=mMatchup";

  function leagueIdFromUrl() {
    try {
      var m = new URLSearchParams(location.search).get("leagueId");
      return m && /^\d+$/.test(m) ? m : null;
    } catch (_) { return null; }
  }

  function seasonFromUrl() {
    try {
      var s = new URLSearchParams(location.search).get("seasonId");
      if (s && /^\d{4}$/.test(s)) return s;
    } catch (_) {}
    // Fantasy seasons run Aug-Jan; before August the upcoming season is the
    // current calendar year, in Jan-Feb the just-finished one is year - 1.
    var now = new Date();
    return String(now.getMonth() < 2 ? now.getFullYear() - 1 : now.getFullYear());
  }

  // SWID is a plain (non-HttpOnly) cookie on .espn.com — readable from the
  // content script. It equals the member id in the league payload, which is
  // how we auto-flag which team is the user's.
  function readSwid() {
    try {
      var m = document.cookie.match(/(?:^|;\s*)SWID=("?)([^;"]+)\1/);
      return m ? decodeURIComponent(m[2]) : null;
    } catch (_) { return null; }
  }

  // Completed trades ride along from the league activity feed (message type
  // 244 = traded player); normalize.js turns raw.activityTopics into the
  // payload's `trades` block (site trade log for private leagues). A feed
  // failure never blocks the export.
  // ESPN rejects a bare `topics` root (400) — the filter roots are players /
  // transactions / communication / schedule; topics come back under
  // communication.topics (fixed 0.20.33, 2026-09-09).
  var ACTIVITY_FILTER = JSON.stringify({ communication: { topics: { filterType: { value: ["ACTIVITY_TRANSACTIONS"] }, limit: 250, limitPerMessageSet: { value: 25 }, offset: 0, sortMessageDate: { sortPriority: 1, sortAsc: false }, sortFor: { sortPriority: 2, sortAsc: false }, filterIncludeMessageTypeIds: { value: [244] } } } });
  function fetchActivity(leagueId, season) {
    return fetch(API + season + "/segments/0/leagues/" + leagueId + "?view=kona_league_communication", {
      credentials: "include",
      headers: { Accept: "application/json", "X-Fantasy-Filter": ACTIVITY_FILTER }
    }).then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) { var o = Array.isArray(j) ? j[0] : j; return (o && ((o.communication && o.communication.topics) || o.topics)) || []; })
      .catch(function () { return []; });
  }

  function fetchLeague(leagueId, season) {
    return fetch(API + season + "/segments/0/leagues/" + leagueId + VIEWS, {
      credentials: "include",
      headers: { Accept: "application/json" }
    }).then(function (r) {
      if (!r.ok) throw new Error("ESPN API " + r.status + (r.status === 401 ? " (not logged in?)" : ""));
      return r.json();
    }).then(function (raw) {
      var lg = Array.isArray(raw) ? raw[0] : raw;
      return fetchActivity(leagueId, season).then(function (topics) { if (lg) lg.activityTopics = topics; return raw; });
    });
  }

  function saveLeague(payload) {
    return new Promise(function (res, rej) {
      try {
        if (!chrome || !chrome.runtime || !chrome.runtime.id) return rej(new Error("extension context gone"));
        payload.syncedAt = Date.now();
        chrome.storage.local.get(["mff_espn_leagues"], function (cur) {
          var all = (cur && cur.mff_espn_leagues) || {};
          all[payload.leagueId] = payload;
          chrome.storage.local.set({ mff_espn_leagues: all }, function () {
            var err = chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
            if (err) { console.warn('[MFF/storage] write FAILED for mff_espn_leagues:', err); rej(new Error('storage write failed: ' + err)); return; }
            res();
          });
        });
      } catch (e) { rej(e); }
    });
  }

  // ── Floating export button ──────────────────────────────────────────
  var btn = null;
  function setBtn(text, disabled) { if (btn) { btn.textContent = text; btn.disabled = !!disabled; } }

  function onExport() {
    var leagueId = leagueIdFromUrl();
    if (!leagueId) return;
    setBtn("Exporting…", true);
    fetchLeague(leagueId, seasonFromUrl())
      .then(function (raw) {
        var norm = window.MFF_ESPN.normalizeEspnLeague(raw, readSwid());
        if (!norm) throw new Error("unexpected league payload");
        return saveLeague(norm).then(function () { return norm; });
      })
      .then(function (norm) {
        setBtn("✓ Saved " + norm.teamCount + " teams — open myfantasyfootball.co", false);
        setTimeout(function () { setBtn("Export league to MFF", false); }, 6000);
      })
      .catch(function (e) {
        console.warn("[MFF/espn] export failed:", e);
        setBtn("✗ " + e.message, false);
        setTimeout(function () { setBtn("Export league to MFF", false); }, 6000);
      });
  }

  function mount() {
    if (btn || !leagueIdFromUrl()) return;
    btn = document.createElement("button");
    btn.id = "mffEspnExportBtn";
    btn.textContent = "Export league to MFF";
    // Bottom-LEFT, stacked above the draft-probe pill (bottom:14px, left:14px)
    // — ESPN's Fantasy Chat panel owns the bottom-right corner and was
    // covering the button (Jack 2026-08-31).
    btn.style.cssText = [
      "position:fixed", "bottom:56px", "left:14px", "z-index:99999",
      "padding:10px 16px", "border-radius:8px", "border:1px solid #fbbf24",
      "background:#111827", "color:#fbbf24", "font:600 13px/1.2 system-ui,sans-serif",
      "cursor:pointer", "box-shadow:0 4px 14px rgba(0,0,0,.4)"
    ].join(";");
    btn.addEventListener("click", onExport);
    document.body.appendChild(btn);
  }

  // ── Auto-export ─────────────────────────────────────────────────────
  // v0.20.23: landing on a league page silently re-exports leagues that
  // have been exported at least once before — checking your team on ESPN
  // is enough to keep MFF fresh (the site auto-commits newer payloads to
  // your saved leagues on load; Jack 2026-09-02). First-time exports stay
  // on the button so browsing other people's leagues doesn't clutter the
  // synced list. Throttled per league (storage syncedAt + an in-page map,
  // 10 min — matches the site's probe guard); failures (logged out, API
  // hiccup) stay silent — the button remains the manual fallback.
  var AUTO_SYNC_MIN_MS = 10 * 60 * 1000;
  var autoTriedAt = {};
  function maybeAutoExport() {
    var leagueId = leagueIdFromUrl();
    if (!leagueId) return;
    if (autoTriedAt[leagueId] && Date.now() - autoTriedAt[leagueId] < AUTO_SYNC_MIN_MS) return;
    autoTriedAt[leagueId] = Date.now();
    try {
      if (!chrome || !chrome.runtime || !chrome.runtime.id) return;
      chrome.storage.local.get(["mff_espn_leagues"], function (cur) {
        var all = (cur && cur.mff_espn_leagues) || {};
        var prev = all[leagueId];
        if (!prev) return; // never exported — the button owns the first time
        if (prev.syncedAt && Date.now() - prev.syncedAt < AUTO_SYNC_MIN_MS) return;
        fetchLeague(leagueId, seasonFromUrl())
          .then(function (raw) {
            var norm = window.MFF_ESPN.normalizeEspnLeague(raw, readSwid());
            if (!norm) throw new Error("unexpected league payload");
            return saveLeague(norm).then(function () { return norm; });
          })
          .then(function (norm) {
            console.log("[MFF/espn] auto-synced league", leagueId);
            setBtn("✓ Auto-synced " + norm.teamCount + " teams", false);
            setTimeout(function () { setBtn("Export league to MFF", false); }, 6000);
          })
          .catch(function (e) { console.warn("[MFF/espn] auto-sync skipped:", e.message); });
      });
    } catch (_) {}
  }

  // ESPN is a SPA — the leagueId can appear after client-side navigation.
  mount();
  maybeAutoExport();
  var lastHref = location.href;
  setInterval(function () {
    if (location.href !== lastHref) {
      lastHref = location.href;
      if (!leagueIdFromUrl() && btn) { btn.remove(); btn = null; }
      mount();
      maybeAutoExport();
    }
  }, 1000);
})();
