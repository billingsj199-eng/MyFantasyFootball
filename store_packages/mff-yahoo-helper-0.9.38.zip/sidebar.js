// MFF Yahoo Helper — season-mode sidebar for football.fantasysports.yahoo.com.
// Port of the Sleeper/ESPN helpers' SEASON personality onto Yahoo, whose web
// app exposes no cookie-auth JSON API (the official API is OAuth-only) — so
// the roster comes from scraping the team page's own DOM (`.ysf-player-name`
// rows, stable Yahoo markup for years), the same play the Underdog helper
// runs. probe.js records whatever internal endpoints Yahoo's pages DO call,
// which is the upgrade path to an API-driven v2.
//
// What needs the DOM vs what doesn't:
//   - roster + current starters + slots: scraped from YOUR team page
//     (persisted per league, so other pages keep working)
//   - free agents: captured from the league's Players page as you browse it
//     (rows with an owning-team link are skipped as taken)
//   - everything else (Jack's live boards, KTC, Clay projections, Vegas
//     lines + weekly props, Sleeper injuries/actuals/trending): same open
//     endpoints as the other helpers.
(() => {
  'use strict';
  if (window.__mffYahoo) return;

  const URL_WATCH_MS = 1500;
  const SCRAPE_MS = 2500;
  const SEASON_POLL_MS = 60000;
  const INJ_TTL_MS = 12 * 3600 * 1000;
  const PRIOR_GAMES = 6;
  const CLOSE_PPG = 1.5;
  const MOCK = window.__MFF_YAHOO_MOCK || null;

  // ---------- MFF premium gate (mirrors the Underdog helper's) ----------
  // mff-page-user.js (MAIN world on the MFF site) + mff-bridge.js write the
  // signed-in user + premium flag to chrome.storage 'mff_user' whenever an
  // MFF tab is open. No fresh premium user (24h TTL) = lock screen instead of
  // the panel and the on-page decorators stay off. Harness MOCK bypasses
  // unless window.__MFF_GATE_TEST forces the gate on for testing.
  const GATE_TTL_MS = 24 * 60 * 60 * 1000;
  let _gateUser = null;
  function gateAllowed() {
    if (MOCK && !window.__MFF_GATE_TEST) return true;
    const u = _gateUser;
    return !!(u && u.premium && u.syncedAt && (Date.now() - u.syncedAt) < GATE_TTL_MS);
  }
  function gateLockHTML() {
    const u = _gateUser;
    const signed = !!(u && u.email);
    // Premium user whose site stamp lapsed (24h TTL) — a re-sync problem,
    // not a missing subscription; say so instead of 'Premium required'.
    const stale = !!(u && u.premium && !(u.syncedAt && (Date.now() - u.syncedAt) < GATE_TTL_MS));
    return '<div style="padding:26px 16px;text-align:center;font-size:12px;line-height:1.5;color:#e5e7eb">' +
      '<div style="font-size:26px">\ud83d\udd12</div>' +
      '<div style="font-weight:800;font-size:13px;margin:6px 0">MFF YAHOO HELPER — Premium</div>' +
      '<div style="color:#9aa0ab;margin-bottom:10px">' + (stale
        ? 'Signed in as ' + String(u.email).replace(/[&<>"]/g, '') + ' — Premium is active, but the helper has not synced with the site in over 24 hours. Open myfantasyfootball.co in this Chrome while signed in and it unlocks on its own.'
        : signed
        ? 'Signed in as ' + String(u.email).replace(/[&<>"]/g, '') + ' — a Premium account is required.'
        : 'Sign in at myfantasyfootball.co in this same Chrome profile with a Premium account to unlock.') + '</div>' +
      '<a href="https://www.myfantasyfootball.co" target="_blank" rel="noopener noreferrer" style="display:inline-block;background:#7d2eff;color:#fff;border-radius:6px;padding:7px 14px;font-weight:700;text-decoration:none;font-size:12px">' +
      (stale ? 'Re-sync with MyFantasyFootball' : signed ? 'Get Premium' : 'Open MyFantasyFootball') + '</a>' +
      '<div style="color:#6b7280;font-size:10px;margin-top:10px">Unlocks automatically — open the site signed in, in this Chrome profile, and revisit (or keep a tab open) at least once a day.</div></div>';
  }
  function gateInit(onChange) {
    try {
      chrome.storage.local.get(['mff_user'], (res) => {
        _gateUser = (res && res.mff_user) || null;
        onChange();
      });
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area !== 'local' || !ch.mff_user) return;
        _gateUser = ch.mff_user.newValue || null;
        onChange();
      });
      setInterval(onChange, 60 * 1000); // TTL can lapse without a storage event
    } catch (_) { onChange(); }
  }
  window.__mffGate = { allowed: gateAllowed, set: (u) => { _gateUser = u; } };

  const state = {
    players: [],
    byName: Object.create(null),      // "norm|POS" -> player
    byNameLoose: Object.create(null), // "norm" -> player (best rank wins)
    tiers: {},   // Jack's tier boundaries per rank field: {rank/jSf/jDy/jDsf: [{a,l,n}]}
    exportedAt: '',
    leagueId: null,
    teamName: '',
    seasonSlots: null,   // starter slot labels from the scraped team page
    roster: [],          // [{name,pos,team,slotLbl,starting,inj,p,key}]
    rosterTs: 0,
    faSeen: {},          // key -> 1, captured from the Players page
    myKeys: new Set(),
    mode: 're_1qb',
    modeManual: false,
    modeDetected: null,
    scoringLabel: '½PPR',
    scoringPrefs: { rec: 0.5, passTd: 4 },
    scoringManual: false, // user touched the SETTINGS chips — API stops overriding
    apiSlots: null,       // starter slots from the league settings API (authoritative)
    apiScoring: false,    // scoring was read from the league settings API
    leagueScoring: null,
    seasonWeek: 1,
    wkConsensus: null,       // site weekly_projections.json payload (Sleeper/ESPN/FP)
    wkConsensusIdx: null,    // lazy norm-name index into wkConsensus.players
    byesActive: false,
    nflState: null,
    slMeta: {},          // sid -> {n,pos,tm,inj} from Sleeper /players/nfl
    schedule: {},        // TEAM -> wk -> {opp,home,total,implied}
    fpa: null,           // site fpa_2026.json: fantasy pts allowed per defense-week → opp matchup grade
    wkPropsAll: null,
    seasonStats: null,
    liveGames: {},       // TEAM(site abbr) -> {st:'pre'|'in'|'post', f, tag, opp, home, pts, oppPts, kick} (ESPN public scoreboard)
    livePts: {},         // entry key -> Yahoo "Fan Pts" scraped off the page (league-scored, live)
    liveFeedF: null,         // TEAM -> game fraction at the last observed change of ANY live total (feed-frozen guard)
    liveSeen: {},        // key -> {pts, f0}: live total + game fraction at its last change (player-exited rule)
    liveMeta: {},        // entry key -> {tm, pos} of every scraped live row (teammate-QB rule)
    liveAt: 0,           // last scoreboard parse (ms)
    liveNextAt: 0,       // earliest next scoreboard fetch (ms)
    trendAdds: {},
    seasonTab: 'lineup',
    seasonPosFilter: 'ALL',
    seasonTeamSrc: 'ktc',
    expandedKey: null,
    seasonStatus: 'Loading players…',
    probeCount: 0,
    pollTimer: null,
    scrapeTimer: null,
  };

  // ---------- name matching (mirrors export_sleeper_extension_data.py) ----------
  function norm(n) {
    let s = (n || '').toLowerCase().trim();
    for (const suf of [' jr.', ' jr', ' sr.', ' sr', ' iii', ' ii', ' iv', ' v']) {
      if (s.endsWith(suf)) s = s.slice(0, -suf.length).trim();
    }
    s = s.replace(/['’`]/g, '').replace(/[.,]/g, '').replace(/-/g, ' ');
    return s.replace(/\s+/g, ' ').trim();
  }
  function keyOf(p) { return norm(p.n) + '|' + p.s; }

  // Yahoo spells some players differently than the site board (Yahoo says
  // "Kenny Gainwell", the board says "Kenneth Gainwell") — with no alias step
  // the scraped roster row can't match, so the player shows no ranks/pills.
  // Mirrors ALIASES in export_sleeper_extension_data.py, applied in BOTH
  // directions so either spelling resolves.
  const ALIAS_PAIRS = [
    ['kenneth gainwell', 'kenny gainwell'],
    ['kenneth walker', 'ken walker'],
    ['cameron ward', 'cam ward'],
    ['chigoziem okonkwo', 'chig okonkwo'],
    ['marquise brown', 'hollywood brown'],
    ['joshua palmer', 'josh palmer'],
    ['dj moore', 'd j moore'],
  ];
  const ALIASES = Object.create(null);
  for (const [a, b] of ALIAS_PAIRS) {
    (ALIASES[a] || (ALIASES[a] = [])).push(b);
    (ALIASES[b] || (ALIASES[b] = [])).push(a);
  }
  // ---------- Sim Lab projection lookups (state.simProj) ----------
  // seasonPpg / weeks rows are [half, ppr, std(, boom, bust)] keyed by CLAY
  // names (DST rows keyed DST_<abbr>). Index by norm() with the ALIASES fold.
  function simProjIdx() {
    if (!state.simProj) return null;
    if (!state.simProjIdx) {
      const fold = (m) => {
        for (const a of Object.keys(ALIASES)) {
          if (m[a] === undefined) {
            for (const alt of ALIASES[a]) { if (m[alt] !== undefined) { m[a] = m[alt]; break; } }
          }
        }
        return m;
      };
      const ix = { season: Object.create(null), weeks: Object.create(null) };
      const sp = state.simProj.seasonPpg || {};
      for (const k of Object.keys(sp)) ix.season[norm(k)] = sp[k];
      fold(ix.season);
      const wks = state.simProj.weeks || {};
      for (const w of Object.keys(wks)) {
        const m = Object.create(null);
        for (const k of Object.keys(wks[w])) m[norm(k)] = wks[w][k];
        ix.weeks[w] = fold(m);
      }
      state.simProjIdx = ix;
    }
    return state.simProjIdx;
  }
  function simKeyFor(p) {
    if (p.s === 'DST') return 'dst_' + String(p.sTm || p.t || '').toLowerCase();
    return norm(p.n);
  }
  // This week's raw sim row [half, ppr, std, boom, bust] — [3]/[4] are the
  // site's exported weekly odds (% of 1,000 draws ≥1.5× / ≤0.5× his median).
  function simWeekRowFor(p) {
    const ix = simProjIdx();
    if (!ix) return null;
    const m = ix.weeks[state.seasonWeek] ||
      (state.simProj.currentWeek != null ? ix.weeks[state.simProj.currentWeek] : null);
    return (m && m[simKeyFor(p)]) || null;
  }
  // League-scoring delta vs the sim's PPR frame, per game (additive — exact
  // for rec value / pass-TD value; sim stat mix = Clay's).
  function simLeagueDeltaPg(p) {
    if (p.cPts == null || !p.cGm || !state.scoringVals) return 0;
    const sv = state.scoringVals;
    return ((sv.recPts - 1) * (p.cRec || 0) + (sv.passTd - 4) * (p.cPtd || 0)) / p.cGm;
  }

  // Name → site player. The loose fallback stays position-guarded: Yahoo's
  // scraped rows always carry a position, so a same-name different-position
  // hit is wrong rather than better-than-nothing.
  function findPlayer(name, pos) {
    const tryName = (nm) => {
      const exact = state.byName[nm + '|' + pos];
      if (exact) return exact;
      const loose = state.byNameLoose[nm];
      return loose && (!pos || loose.s === pos) ? loose : null;
    };
    const nm = norm(name);
    const p = tryName(nm);
    if (p) return p;
    for (const alt of ALIASES[nm] || []) {
      const q = tryName(alt);
      if (q) return q;
    }
    return null;
  }

  // ---------- storage (falls back to memory in the mock harness) ----------
  const mem = {};
  const store = {
    get(keys) {
      return new Promise((res) => {
        try { chrome.storage.local.get(keys, res); } catch (e) { res(mem); }
      });
    },
    set(obj) {
      Object.assign(mem, obj);
      try {
        chrome.storage.local.set(obj, function () {
          try {
            var err = chrome.runtime && chrome.runtime.lastError ? chrome.runtime.lastError.message : null;
            if (err) console.warn('[MFF/storage] write FAILED for', Object.keys(obj).join(',') + ':', err);
          } catch (_) {}
        });
      } catch (e) {}
    },
  };

  // Direct fetch first, background-worker relay if Yahoo's page CSP blocks it.
  // v0.9.4: reloading/updating the extension at chrome://extensions orphans
  // content scripts already injected into open tabs — chrome.runtime evaporates
  // and sendMessage throws. Detect the dead context and surface a plain-English
  // fix instead of the raw TypeError.
  const DEAD_CTX_MSG = 'Extension was updated — refresh this tab';
  function extAlive() {
    try { return !!(chrome && chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }
  function fetchJson(url) {
    return fetch(url).then((r) => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).catch((e) => new Promise((resolve, reject) => {
      if (!extAlive()) return reject(new Error(DEAD_CTX_MSG));
      try {
        chrome.runtime.sendMessage({ type: 'mffFetch', url }, (resp) => {
          if (chrome.runtime.lastError) return reject(e);
          if (!resp || !resp.ok) return reject(new Error(resp ? resp.error : String(e)));
          resolve(resp.data);
        });
      } catch (_) { reject(extAlive() ? e : new Error(DEAD_CTX_MSG)); }
    }));
  }

  // ---------- live Jack's boards (Firestore REST sends CORS *) ----------
  const FIRESTORE_URL =
    'https://firestore.googleapis.com/v1/projects/jackb933-website/databases/(default)' +
    '/documents/rankings/jacks-official?key=AIzaSyD9D_Rhb5hEpz2cBWqQr7hcFCDoluwq6uY';
  // v0.9.12: jacks-official is premium-only read since 2026-08-13, so the
  // tokenless fetch above 403s — without a site-bridge push, boards silently
  // stayed baked. jacks-public mirrors the top 36 of every board (written on
  // the same site save) and is publicly readable: it is the fallback for
  // every install, free or premium.
  const FIRESTORE_PUBLIC_URL =
    'https://firestore.googleapis.com/v1/projects/jackb933-website/databases/(default)' +
    '/documents/rankings/jacks-public?key=AIzaSyD9D_Rhb5hEpz2cBWqQr7hcFCDoluwq6uY';
  // ---- live IR (OUT FOR SEASON) sync ----
  // Both rankings docs (official + public) carry a top-level `ir` field:
  // {"Player Name": seasonYear}. Recompute p.ir on every apply so a flag Jack
  // sets mid-day reaches the helper without waiting for the next players.json
  // export (baked flags go stale the same way baked ranks do).
  function applyIrList(names) {
    const out = new Set(names.map((n) => norm(n)));
    for (const p of state.players) {
      if (out.has(norm(p.n))) p.ir = 1;
      else if (p.ir) delete p.ir;
    }
  }
  function applyIrField(raw) {
    try {
      const map = JSON.parse(raw || '');
      if (!map || typeof map !== 'object') return;
      const d = new Date(); // IR season rolls over March 1, same as the site
      const season = d.getMonth() >= 2 ? d.getFullYear() : d.getFullYear() - 1;
      applyIrList(Object.keys(map).filter((n) => map[n] === season));
    } catch (_) { /* field absent/corrupt — baked flags stay in effect */ }
  }
  // FULL-board apply for one mode key: live names take ranks 1..N, and a
  // player ABSENT from the live order was removed from that board since the
  // last export — his stale baked rank now belongs to someone else, so clear
  // it. A redraft removal additionally sets p.rm: the daily export drops the
  // player from players.json entirely, and the live path must match (the FA
  // pool filters rm). Guarded on order size so a truncated doc can't
  // mass-remove the pool.
  function applyFullOrder(key, order, byNorm) {
    let applied = 0;
    order.forEach((name, i) => {
      const list = byNorm[norm(name)];
      if (list) for (const p of list) { p[key] = i + 1; applied++; }
    });
    if (order.length >= 50) {
      const inBoard = new Set(order.map((n) => norm(n)));
      for (const p of state.players) {
        if (inBoard.has(norm(p.n))) {
          if (key === 'rank' && p.rm) delete p.rm;
        } else {
          if (typeof p[key] === 'number') delete p[key];
          if (key === 'rank') p.rm = 1;
        }
      }
    }
    return applied;
  }
  // Partial (top-36) apply: live names take ranks 1..N; everyone deeper is
  // renumbered from N+1 in their existing relative order, so a player who
  // fell out of the live top-36 can't share a rank with his replacement.
  function applyPartialOrder(key, order, byNorm) {
    const inTop = new Set();
    for (const name of order) {
      const list = byNorm[norm(name)];
      if (list) for (const p of list) inTop.add(p);
    }
    const rest = state.players
      .filter((p) => !inTop.has(p) && typeof p[key] === 'number')
      .sort((a, b) => a[key] - b[key]);
    let applied = 0;
    order.forEach((name, i) => {
      const list = byNorm[norm(name)];
      if (list) for (const p of list) { p[key] = i + 1; applied++; }
    });
    let r = order.length;
    for (const p of rest) { p[key] = ++r; }
    return applied;
  }
  async function refreshJackBoards() {
    if (MOCK) return;
    // PREMIUM (v0.8.2): the full-board pull is premium-only. Read the
    // synced user straight from storage: the gate's async boot read may not
    // have landed in _gateUser yet the first time this runs.
    let premium = false;
    try {
      const gu = await store.get(['mff_user']);
      const u = (gu && gu.mff_user) || _gateUser;
      premium = !!(u && u.premium && u.syncedAt && (Date.now() - u.syncedAt) < GATE_TTL_MS);
    } catch (e) {}
    let doc = null, full = false;
    if (premium) {
      try { doc = await fetchJson(FIRESTORE_URL); full = true; } catch (e) {}
    }
    if (!doc) {
      try { doc = await fetchJson(FIRESTORE_PUBLIC_URL); } catch (e) { return; }
      full = false;
    }
    try {
      const payload = JSON.parse(doc.fields.data.stringValue);
      const jacks = payload.jacks || {};
      // Live IR flags ride the same doc (official AND public carry `ir`).
      applyIrField(doc.fields.ir && doc.fields.ir.stringValue);
      const keyByMode = { superflex: 'jSf', dynasty: 'jDy', dynastysf: 'jDsf', redraft: 'rank' };
      const byNorm = {};
      for (const p of state.players) (byNorm[norm(p.n)] = byNorm[norm(p.n)] || []).push(p);
      let applied = 0;
      for (const [mode, key] of Object.entries(keyByMode)) {
        const order = (jacks[mode] || {})._order || [];
        if (full) {
          applied += applyFullOrder(key, order, byNorm);
        } else {
          applied += applyPartialOrder(key, order, byNorm);
        }
        // Jack's ALL-board tier boundaries ride the same doc — keep them in
        // lockstep with the live re-rank above (baked tiers would drift).
        const pt = ((jacks[mode] || {})._posTiers || {}).ALL;
        if (Array.isArray(pt)) {
          const fresh = pt
            .filter(t => t && t.afterRank >= 1 && t.label)
            .map(t => ({ a: t.afterRank, l: String(t.label), n: String(t.name || '') }));
          if (full) {
            state.tiers[key] = fresh.sort((x, y) => x.a - y.a);
          } else {
            // Public doc cuts tiers at 36 — keep any deeper boundaries a
            // full/bridge apply already installed.
            const cutoff = order.length;
            const deep = (state.tiers[key] || []).filter(t => t.a > cutoff);
            state.tiers[key] = fresh.filter(t => t.a <= cutoff).concat(deep)
              .sort((x, y) => x.a - y.a);
          }
        }
      }
      if (applied) {
        const upd = doc.fields.updatedAt ? doc.fields.updatedAt.stringValue.slice(0, 10) : '';
        state.seasonStatus = state.players.length + ' players · ' +
          (full ? 'boards live' : 'top-36 live') + (upd ? ' ' + upd : '');
        render();
      }
    } catch (e) { /* baked boards from players.json stay in effect */ }
  }

  // v0.2.5: long-lived tabs never re-fetched boards — re-pull when the tab is
  // refocused after 5+ minutes hidden ("saved on the site, came back here").
  let _boardsFetchedAt = Date.now();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState !== 'visible') return;
    if (Date.now() - _boardsFetchedAt < 5 * 60 * 1000) return;
    _boardsFetchedAt = Date.now();
    refreshJackBoards();
  });
  // Premium sync can land AFTER boot (user opens the site in another tab) —
  // pull the live boards the moment the gate user turns premium instead of
  // leaving the sliced bundle in effect until the next refocus.
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area !== 'local' || !ch.mff_user) return;
      const nu = ch.mff_user.newValue, was = ch.mff_user.oldValue;
      if (nu && nu.premium && !(was && was.premium)) { _boardsFetchedAt = Date.now(); refreshJackBoards(); }
    });
  } catch (_) {}

  // Bridge-shipped full boards (board-gating Phase B): a premium site session
  // writes versionBoards.jacks into chrome.storage 'mff_jacks_boards' via
  // mff-page-user/mff-bridge. Once Phase C rules-gates the official doc, the
  // direct Firestore read above 403s and THIS is the premium path to the full
  // board. The live fetch still wins when it works — it runs after this on
  // boot and re-runs on refocus/premium-unlock.
  async function applyBridgeJackBoards(v) {
    try {
      if (!v || !v.boards) return;
      if (!(v.syncedAt && (Date.now() - v.syncedAt) < 7 * 24 * 60 * 60 * 1000)) return; // stale ship
      const gu = await store.get(['mff_user']);
      const u = (gu && gu.mff_user) || _gateUser;
      if (!(u && u.premium && u.syncedAt && (Date.now() - u.syncedAt) < GATE_TTL_MS)) return;
      const byNorm = {};
      for (const p of state.players) (byNorm[norm(p.n)] = byNorm[norm(p.n)] || []).push(p);
      let applied = 0;
      for (const key of ['rank', 'jSf', 'jDy', 'jDsf']) {
        const order = v.boards[key];
        if (!Array.isArray(order) || !order.length) continue;
        applied += applyFullOrder(key, order, byNorm);
        const tl = v.tiers && v.tiers[key];
        if (Array.isArray(tl) && tl.length) state.tiers[key] = tl;
      }
      // Site sessions also ship the current-season IR names (see mff-page-user)
      if (Array.isArray(v.ir)) applyIrList(v.ir);
      if (applied) {
        state.seasonStatus = state.players.length + ' players · boards synced from site';
        render();
      }
    } catch (_) {}
  }
  try {
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch.mff_jacks_boards) applyBridgeJackBoards(ch.mff_jacks_boards.newValue);
    });
  } catch (_) {}

  // ---------- live Vegas overlay + schedule (GitHub Pages sends CORS *) ----------
  function applyLiveVegas(gameTotals) {
    const SOS = window.MFF_PLAYOFF_SOS;
    if (!SOS || !gameTotals) return 0;
    let updated = 0;
    Object.keys(SOS).forEach((team) => {
      const posMap = SOS[team] || {};
      Object.keys(posMap).forEach((pos) => {
        Object.keys(posMap[pos] || {}).forEach((wk) => {
          const rec = posMap[pos][wk];
          if (!rec || !rec.opp) return;
          const key = rec.home ? ('W' + wk + '_' + rec.opp + '_' + team)
                               : ('W' + wk + '_' + team + '_' + rec.opp);
          const g = gameTotals[key];
          if (!g) return;
          if (typeof g.total === 'number') rec.gameTotal = g.total;
          if (typeof g.spread === 'number') {
            rec.teamSpread = rec.home ? g.spread : -g.spread;
            if (typeof g.total === 'number') rec.impliedTotal = (g.total - rec.teamSpread) / 2;
          }
          updated++;
        });
      });
    });
    return updated;
  }
  function buildSchedule(gameTotals) {
    if (!gameTotals) return;
    const sched = {};
    for (const key of Object.keys(gameTotals)) {
      const m = key.match(/^W(\d+)_([A-Z]{2,4})_([A-Z]{2,4})$/);
      if (!m) continue;
      const wk = parseInt(m[1], 10);
      const g = gameTotals[key] || {};
      const total = typeof g.total === 'number' ? g.total : null;
      const hSpread = typeof g.spread === 'number' ? g.spread : null;
      const put = (tm, opp, isHome) => {
        const spread = hSpread == null ? null : (isHome ? hSpread : -hSpread);
        (sched[tm] = sched[tm] || {})[wk] = {
          opp, home: isHome, total,
          implied: (total != null && spread != null)
            ? Math.round(((total - spread) / 2) * 10) / 10 : null,
        };
      };
      put(m[2], m[3], false);
      put(m[3], m[2], true);
    }
    state.schedule = sched;
  }

  // ---------- players.json ----------
  async function loadPlayers() {
    let data;
    if (MOCK && MOCK.players) {
      data = MOCK.players;
    } else {
      const url = chrome.runtime.getURL('data/players.json');
      data = await (await fetch(url)).json();
    }
    state.players = data.players || [];
    state.tiers = data.tiers || {}; // Jack's tier boundaries per rank field
    state.exportedAt = data.exported_at || '';
    for (const p of state.players) {
      const k = keyOf(p);
      if (!state.byName[k]) state.byName[k] = p;
      const loose = norm(p.n);
      if (!state.byNameLoose[loose]) state.byNameLoose[loose] = p;
    }
    applyScoringPrefs();
    state.seasonStatus = state.players.length + ' players · data ' + state.exportedAt;
  }

  // ---------- modes / sources ----------
  const MODES = {
    re_1qb: { label: 'Redraft 1QB' },
    re_sf:  { label: 'Redraft SF' },
    dyn_1qb:{ label: 'Dynasty 1QB' },
    dyn_sf: { label: 'Dynasty SF' },
  };
  const MODE_KEYS = {
    dyn_sf:  { ktc: 'ktcSf',  jack: 'jDsf', fp: 'fpDsf', sl: 'slDsf', adp: 'sa',  vor: 'vorSf', up: 'upSf' },
    dyn_1qb: { ktc: 'ktc1qb', jack: 'jDy',  fp: 'fpDy',  sl: 'slDy',  adp: 'da',  vor: 'vor',   up: 'up'   },
    re_sf:   { ktc: 'ktcSf',  jack: 'jSf',  fp: 'fpSf',  sl: 'slSf',  adp: 'sfa', vor: 'vorSf', up: 'upSf' },
    re_1qb:  { ktc: 'ktc1qb', jack: 'rank', fp: 'fpR',   sl: 'slR',   adp: 'a',   vor: 'vor',   up: 'up'   },
  };
  function modeKeys() { return MODE_KEYS[state.mode] || MODE_KEYS.re_1qb; }
  // Redraft leagues have no use for dynasty tooling — KTC values (a dynasty
  // trade market) disappear everywhere unless the dynasty mode is on.
  function isDynMode() { return state.mode.indexOf('dyn') === 0; }
  // ---------- Jack's board tiers ----------
  // state.tiers[field] = sorted [{a, l, n}] boundaries on that board (from
  // players.json, live-refreshed by refreshJackBoards). A tier applies from
  // rank `a` until the next boundary — same as the site's _tierLabelForRank.
  // Color cycle is the site's .myrank-num tier-X palette (styles/main.css).
  const JACK_TIER_LABELS = ['S','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','T','U','V','W','X','Y','Z'];
  const JACK_TIER_COLORS = ['#eab308','#ef4444','#3b82f6','#22c55e','#a855f7','#f97316','#9ca3af','#ec4899','#06b6d4','#84cc16','#f43f5e','#6366f1','#fbbf24','#14b8a6','#d946ef','#ea580c','#38bdf8','#a3e635','#fb7185'];
  function jackTierColor(label) {
    const i = JACK_TIER_LABELS.indexOf(label);
    return JACK_TIER_COLORS[(i >= 0 ? i : 0) % JACK_TIER_COLORS.length];
  }
  function jackTierList() { return state.tiers[modeKeys().jack] || null; }
  function jackTierFor(rank) {
    const list = jackTierList();
    if (!list || !list.length || rank == null) return null;
    let cur = null;
    for (const t of list) { if (t.a <= rank) cur = t; else break; }
    return cur;
  }
  const SOURCES = {
    ktc:  { label: 'KTC',          get: (p) => p[modeKeys().ktc],  desc: true },
    jack: { label: "Jack's Rank",  get: (p) => p[modeKeys().jack], desc: false },
    fp:   { label: 'FantasyPros',  get: (p) => p[modeKeys().fp],   desc: false },
    sl:   { label: 'Sleeper Rank', get: (p) => p[modeKeys().sl],   desc: false },
  };
  // ---------- MY RANKS rank source (user's own site boards) ----------
  // mff-page-user.js ships versionBoards.mine via the bridge into
  // chrome.storage 'mff_my_rankings'. Selecting "My Ranks" makes the ENTIRE
  // rec engine (board order, tiers, quality fill, depletion schedule) run on
  // the user's custom rankings — same behavior the Underdog helper has.
  let _myRanks = null;
  let _myRanksMaps = {};
  function _myMapFor(modeKey) {
    if (!_myRanks || !_myRanks[modeKey]) return null;
    if (!_myRanksMaps[modeKey]) {
      const m = new Map();
      _myRanks[modeKey].forEach((r, i) => {
        const k = norm(r.n) + '|' + r.s;
        if (!m.has(k)) m.set(k, i + 1);
      });
      _myRanksMaps[modeKey] = m;
    }
    return _myRanksMaps[modeKey];
  }
  function myRanksAvailable() {
    const mk = (state.mode).indexOf('dyn') === 0
      ? (state.mode) : (state.mode);
    return !!(_myRanks && _myRanks[mk] && _myRanks[mk].length);
  }
  SOURCES.mine = {
    label: 'My Ranks',
    get: (p) => { const m = _myMapFor(state.mode); return m ? (m.get(keyOf(p)) || null) : null; },
    desc: false,
  };
  function _applyMyRanks(v) {
    _myRanks = (v && v.boards) || null;
    _myRanksMaps = {};
    try { render(); } catch (_) {}
  }
  try {
    chrome.storage.local.get(['mff_my_rankings'], (res) => _applyMyRanks(res && res.mff_my_rankings));
    chrome.storage.onChanged.addListener((ch, area) => {
      if (area === 'local' && ch.mff_my_rankings) _applyMyRanks(ch.mff_my_rankings.newValue);
    });
  } catch (_) {}

  function applyMode(mode, manual) {
    if (!MODES[mode]) return;
    state.mode = mode;
    if (manual) state.modeManual = true;
  }

  // ---------- league scoring ----------
  // Yahoo's league scoring page isn't scraped (v0.1) — SETTINGS carries the
  // two values that move projections (rec + pass TD; Yahoo defaults ½PPR /
  // 4pt). The K/DST models fall back to their built-in defaults, which ARE
  // Yahoo's default kicker/DST values.
  function applyScoringPrefs() {
    const recPts = state.scoringPrefs.rec != null ? state.scoringPrefs.rec : 0.5;
    const passTd = state.scoringPrefs.passTd != null ? state.scoringPrefs.passTd : 4;
    state.leagueScoring = { rec: recPts, pass_td: passTd };
    state.scoringLabel =
      (recPts === 1 ? 'PPR' : recPts === 0.5 ? '½PPR' : recPts === 0 ? 'STD' : recPts + '/rec') +
      (passTd !== 4 ? ' · ' + passTd + 'pt paTD' : '');
    state.scoringVals = { recPts, passTd };
    for (const p of state.players) {
      if (p.cPts == null || !p.cGm) continue;
      const adj = p.cPts + (recPts - 1) * (p.cRec || 0) + (passTd - 4) * (p.cPtd || 0);
      p.szn = Math.round(adj * 10) / 10;
      p.pPg = Math.round((adj / p.cGm) * 10) / 10;
      // SIM-FIRST: Sim Lab rest-of-season PPG (PPR frame) + this league's
      // additive scoring delta replaces the flat Clay season/gm number.
      const _six = simProjIdx();
      if (_six && p.s !== 'K' && p.s !== 'DST') {
        const sp = _six.season[simKeyFor(p)];
        if (sp && typeof sp[1] === 'number') {
          p.pPg = Math.round((sp[1] + simLeagueDeltaPg(p)) * 10) / 10;
          p.szn = Math.round(p.pPg * p.cGm * 10) / 10;
        }
      }
    }
  }

  // League settings API — the same cookie-auth pub-api call the draft panel
  // uses. Gives the EXACT starting slots and per-stat scoring modifiers, which
  // makes it authoritative over both the DOM slot scrape (which could pick up
  // stray slot-labeled rows elsewhere on the page and invent phantom lineup
  // slots — the "2 QB / 3 DEF optimal lineup" bug) and the manual scoring
  // chips (kept as an override: touching them sets scoringManual).
  async function fetchLeagueSettings(leagueId) {
    if (MOCK && !MOCK.settings) return;
    try {
      const j = MOCK ? MOCK.settings : await (await fetch(
        'https://pub-api.fantasysports.yahoo.com/fantasy/v3/settings/nfl/' + leagueId + '?format=rawjson',
        { credentials: 'include' })).json();
      const svc = (j && (j.service || j)) || {};
      const rp = (svc.settings && svc.settings.roster_positions) || [];
      const slots = [];
      for (const r of rp) {
        const lbl = SLOT_MAP[String(r.position || '').toUpperCase().replace(/\s+/g, '')];
        if (!lbl || lbl === 'BN' || lbl === 'IR') continue;
        const n = parseInt(r.count, 10) || 0;
        for (let i = 0; i < n; i++) slots.push(lbl);
      }
      if (slots.length) {
        state.apiSlots = slots;
        state.seasonSlots = slots;
        const sf = slots.indexOf('SUPER_FLEX') !== -1 || slots.filter((s) => s === 'QB').length >= 2;
        state.modeDetected = 're_' + (sf ? 'sf' : '1qb');
        if (!state.modeManual) applyMode(state.modeDetected, false);
      }
      const cats = (svc.settings && svc.settings.stat_categories) || [];
      // Yahoo lists only scored categories: categories present but no Receptions
      // (11) = standard, 0 per catch (it stayed on the ½PPR default until 2026-10-05).
      let rec = cats.length ? 0 : null, passTd = null;
      for (const c of cats) {
        if (c.stat_id === 11) rec = parseFloat(c.stat_modifier) || 0;
        if (c.stat_id === 5) passTd = parseFloat(c.stat_modifier) || 4;
      }
      if (rec != null && !state.scoringManual) {
        state.scoringPrefs = { rec, passTd: passTd != null ? passTd : 4 };
        state.apiScoring = true;
        applyScoringPrefs();
      }
      // Playoff shape for the SIMS tab: team count is explicit; Yahoo doesn't
      // expose playoff_start_week here, so derive it — each playoff round is
      // one week ending at end_week.
      const pt = parseInt(svc.settings && svc.settings.num_playoff_teams, 10);
      if (pt >= 2) state.playoffTeams = pt;
      const endWk = parseInt(svc.end_week, 10);
      if (endWk) {
        const rounds = Math.ceil(Math.log2(state.playoffTeams || 4));
        state.playoffStart = endWk - rounds + 1;
      }
      saveLeagueState();
      render();
      console.log('[MFF/yahoo] league settings read:', slots.length, 'starting slots ·',
        state.scoringLabel, '·', state.modeDetected);
    } catch (e) {
      console.warn('[MFF/yahoo] settings API unavailable, staying on scrape/manual:', e);
    }
  }

  // ---------- Yahoo DOM adapter ----------
  // Team page rows: a table row whose first cell is the lineup slot (QB, WR,
  // W/R/T, BN, IR…) containing a `.ysf-player-name` div — `a` = player name,
  // `span` = "Buf - RB" (+ status tokens). DEF rows name the franchise and
  // carry "- DEF" in the meta. Players outside your league page layout are
  // ignored. Yahoo team abbrevs map onto the site's (WAS → WSH).
  const SLOT_MAP = {
    'QB': 'QB', 'RB': 'RB', 'WR': 'WR', 'TE': 'TE', 'K': 'K',
    'DEF': 'DEF', 'D': 'DEF', 'D/ST': 'DEF', 'DST': 'DEF',
    'W/R': 'WRRB_FLEX', 'W/T': 'REC_FLEX', 'W/R/T': 'FLEX', 'FLEX': 'FLEX',
    'Q/W/R/T': 'SUPER_FLEX', 'OP': 'SUPER_FLEX', 'SF': 'SUPER_FLEX',
    'BN': 'BN', 'IR': 'IR', 'IL': 'IR', 'IR+': 'IR', 'IL+': 'IR',
  };
  const SLOT_ELIG = {
    QB: ['QB'], RB: ['RB'], WR: ['WR'], TE: ['TE'], K: ['K'], DEF: ['DST'],
    FLEX: ['RB', 'WR', 'TE'], SUPER_FLEX: ['QB', 'RB', 'WR', 'TE'],
    WRRB_FLEX: ['WR', 'RB'], REC_FLEX: ['WR', 'TE'],
  };
  function fixAbbr(a) {
    a = String(a || '').toUpperCase();
    return a === 'WAS' ? 'WSH' : a === 'JAC' ? 'JAX' : a;
  }
  function detectLeagueId() {
    if (MOCK && MOCK.leagueId) return MOCK.leagueId;
    const m = location.pathname.match(/\/f1\/(\d+)/);
    return m ? m[1] : null;
  }
  function onPlayersPage() {
    if (MOCK) return !!MOCK.playersPage;
    return /\/f1\/\d+\/players/.test(location.pathname);
  }
  function onMatchupPage() {
    if (MOCK) return !!MOCK.matchupPage;
    return /\/f1\/\d+\/matchup/.test(location.pathname);
  }
  // Team pages are /f1/<league>/<teamId>. Matchup pages ALSO render slot-
  // labeled rosters (both teams'), so scraping is gated to team URLs only.
  function onTeamPage() {
    if (MOCK) return !MOCK.playersPage;
    return /\/f1\/\d+\/\d+(?:$|[?\/])/.test(location.pathname);
  }
  function matchScraped(name, pos, team) {
    if (pos === 'DST') {
      return state.players.find((x) => x.s === 'DST' && x.sTm === team) || null;
    }
    return findPlayer(name, pos);
  }
  function parsePlayerCell(cell) {
    const box = cell.querySelector('.ysf-player-name');
    if (!box) return null;
    const a = box.querySelector('a');
    if (!a) return null;
    const name = a.textContent.trim();
    if (!name) return null;
    // The "Tm - POS" meta is NOT always the first span: D/ST rows on the
    // Players page lead with the "player Notes" status span, so a first-span
    // read came back "No new player Notes", the position never parsed, and
    // no D/ST was ever captured as a free agent. Scan every span in the box
    // (then the whole row) for the pattern instead.
    let mm = null;
    const spanScope = [...box.querySelectorAll('span')];
    const rowEl = cell.closest ? (cell.closest('tr') || cell) : cell;
    for (const sp of spanScope.concat([...rowEl.querySelectorAll('span')])) {
      mm = (sp.textContent || '').trim().match(/([A-Za-z]{2,3})\s*-\s*(QB|WR|RB|TE|K|DEF|D)\b/i);
      if (mm) break;
    }
    const team = mm ? fixAbbr(mm[1]) : '';
    let pos = mm ? mm[2].toUpperCase() : '';
    if (pos === 'DEF' || pos === 'D') pos = 'DST';
    // status: Yahoo renders it as a dedicated status/injury span when present
    let inj = null;
    const stEl = box.querySelector('.ysf-player-status, .F-injury, abbr');
    const st = stEl ? stEl.textContent.trim().toUpperCase() : '';
    if (/^(O|IR|IR-R|PUP|PUP-P|NA|NFI|SUSP|SSPD)/.test(st)) inj = 'OUT';
    else if (st === 'D') inj = 'D';
    else if (st === 'Q') inj = 'Q';
    const p = matchScraped(name, pos, team);
    const key = p ? keyOf(p) : norm(name) + '|' + (pos || '?');
    // LIVE (v0.9.23): Yahoo prints league-scored "Fan Pts" beside every row
    // (matchup page: bold cell next to the Proj cell; team page: td.pts).
    // "–" = not started → null. Numbers land in state.livePts by entry key.
    const pts = livePtsFromCell(cell);
    if (pts != null) { if (state.livePts[key] !== pts) liveFeedMark(); state.livePts[key] = pts; state.liveMeta[key] = { tm: p ? (p.sTm || team) : team, pos: p ? p.s : (pos || '?') }; }
    return {
      name, pos: p ? p.s : (pos || '?'), team: p ? (p.sTm || team) : team, inj,
      p: p || null, key, pts,
    };
  }
  function parsePtsText(t) {
    const s = String(t || '').trim().replace(/,/g, '');
    if (!s || /^[–—-]$/.test(s)) return null;
    return /^-?\d+(?:\.\d+)?$/.test(s) ? Math.round(parseFloat(s) * 100) / 100 : null;
  }
  function livePtsFromCell(cell) {
    const td = cell && cell.closest ? (cell.closest('td') || cell) : cell;
    const row = td && td.closest ? td.closest('tr') : null;
    if (!row) return null;
    const direct = row.querySelector(':scope > td.pts');         // team / players page
    if (direct) return parsePtsText(direct.textContent);
    const cells = [...row.children];
    const idx = cells.indexOf(td);
    if (idx < 0 || cells.length < 4) return null;
    // Matchup page: [.. player | Proj | Fan Pts | slot | Fan Pts | Proj | player ..]
    // — walk from this player's cell toward the slot column; the first bold
    // (Fw-b) numeric/dash cell is his Fan Pts.
    const dir = idx < (cells.length - 1) / 2 ? 1 : -1;
    for (let j = idx + dir, k = 0; j >= 0 && j < cells.length && k < 3; j += dir, k++) {
      const c = cells[j];
      if (c.querySelector('.ysf-player-name')) break;
      if (/\bFw-b\b/.test(c.className || '')) return parsePtsText(c.textContent);
    }
    return null;
  }
  // Scrape the CURRENT page's roster table. Returns null when the page has no
  // slot-labeled roster rows (league home, players page, matchups…).
  function scrapeTeamPage() {
    if (MOCK && MOCK.noScrape) return null;
    if (!onTeamPage()) return null;
    // Scope to the roster stat tables when the classic layout provides them
    // (#statTable0 offense / 1 kickers / 2 defense) — a page-wide <tr> sweep
    // can catch slot-labeled rows from other modules and invent lineup slots.
    const scoped = document.querySelectorAll('table[id^="statTable"] tr');
    const rows = scoped.length ? scoped : document.querySelectorAll('tr');
    const entries = [];
    const slots = [];
    for (const row of rows) {
      const cells = row.querySelectorAll('td');
      if (cells.length < 2) continue;
      const slotTok = cells[0].textContent.trim().toUpperCase().replace(/\s+/g, '');
      const slotLbl = SLOT_MAP[slotTok];
      if (!slotLbl) continue;
      const info = parsePlayerCell(row);
      // Unscoped sweep: the team page's position glossary + injury key are
      // slot-labeled rows too ("QB Only quarterbacks", "D Doubtful") - count a
      // slot only when the row carries a player (2026-10-05).
      if (slotLbl !== 'BN' && slotLbl !== 'IR' && (scoped.length || info)) slots.push(slotLbl);
      if (!info) continue; // empty roster slot — still counts toward lineup slots (scoped tables)
      entries.push(Object.assign(info, { slotLbl, starting: slotLbl !== 'BN' && slotLbl !== 'IR' }));
    }
    if (!slots.length || !entries.length) return null;
    // team name: Yahoo puts it in the page's team header link/title
    let teamName = '';
    const th = document.querySelector('#team-card-info a, .Navtarget, h1');
    if (th) teamName = th.textContent.trim().slice(0, 40);
    return { entries, slots, teamName };
  }
  // Players-page capture: any player row WITHOUT an owning-team link on the
  // row is treated as available. Accumulates as the user pages/filters.
  function scrapePlayersPage() {
    if (!onPlayersPage()) return 0;
    const lid = state.leagueId;
    let added = 0;
    const rows = document.querySelectorAll('tr');
    for (const row of rows) {
      const info = parsePlayerCell(row);
      if (!info || !info.p) continue;
      if (state.myKeys.has(info.key)) continue;
      const ownerLink = [...row.querySelectorAll('a')].some((a) => {
        const m = a.getAttribute('href') && a.getAttribute('href').match(/\/f1\/(\d+)\/(\d+)(?:$|[/?])/);
        return m && m[1] === lid;
      });
      if (ownerLink) { delete state.faSeen[info.key]; continue; } // taken
      if (!state.faSeen[info.key]) { state.faSeen[info.key] = 1; added++; }
      if (info.inj) state.scrapedInj[info.key] = info.inj;
    }
    if (added) saveLeagueState();
    return added;
  }
  state.scrapedInj = Object.create(null);
  function applyScrapedRoster(scr) {
    state.roster = scr.entries;
    // The settings API owns the slot list when it answered; scraped slots are
    // the fallback for logged-out / API-failure sessions only.
    state.seasonSlots = state.apiSlots || scr.slots;
    state.rosterTs = Date.now();
    if (scr.teamName) state.teamName = scr.teamName;
    state.myKeys = new Set(scr.entries.map((e) => e.key));
    scr.entries.forEach((e) => { if (e.inj) state.scrapedInj[e.key] = e.inj; });
    if (!state.apiSlots) {
      const sf = scr.slots.indexOf('SUPER_FLEX') !== -1 || scr.slots.filter((s) => s === 'QB').length >= 2;
      state.modeDetected = 're_' + (sf ? 'sf' : '1qb'); // dynasty isn't scrapable — user overrides
      if (!state.modeManual) applyMode(state.modeDetected, false);
    }
    saveLeagueState();
  }
  function saveLeagueState() {
    if (!state.leagueId) return;
    store.set({
      ['yahooLeague_' + state.leagueId]: {
        ts: state.rosterTs,
        teamName: state.teamName,
        slots: state.seasonSlots,
        entries: state.roster.map((e) => ({
          name: e.name, pos: e.pos, team: e.team, slotLbl: e.slotLbl,
          starting: e.starting, inj: e.inj || null,
        })),
        faSeen: state.faSeen,
        mode: state.mode,
        modeManual: state.modeManual,
        scoringPrefs: state.scoringPrefs,
        scoringManual: state.scoringManual,
        tab: state.seasonTab,
        posFilter: state.seasonPosFilter,
        teamSrc: state.seasonTeamSrc,
      },
    });
  }
  function restoreLeagueState(saved) {
    if (!saved) return;
    if (Array.isArray(saved.entries) && saved.entries.length) {
      state.roster = saved.entries.map((e) => {
        const p = matchScraped(e.name, e.pos === 'DST' ? 'DST' : e.pos, e.team);
        return {
          name: e.name, pos: p ? p.s : e.pos, team: e.team, slotLbl: e.slotLbl,
          starting: !!e.starting, inj: e.inj || null,
          p: p || null, key: p ? keyOf(p) : norm(e.name) + '|' + e.pos,
        };
      });
      state.myKeys = new Set(state.roster.map((e) => e.key));
      state.roster.forEach((e) => { if (e.inj) state.scrapedInj[e.key] = e.inj; });
      state.rosterTs = saved.ts || 0;
    }
    if (Array.isArray(saved.slots) && saved.slots.length) state.seasonSlots = saved.slots;
    if (saved.teamName) state.teamName = saved.teamName;
    if (saved.faSeen) state.faSeen = saved.faSeen;
    // Only a HAND-PICKED format is restored; an auto-detected one is re-detected
    // each visit (a stale or mis-scraped SF read used to stick - 2026-10-05).
    if (saved.mode && MODES[saved.mode] && saved.modeManual) { state.mode = saved.mode; state.modeManual = true; }
    if (saved.scoringPrefs) { state.scoringPrefs = saved.scoringPrefs; state.scoringManual = !!saved.scoringManual; applyScoringPrefs(); }
    if (saved.tab) state.seasonTab = saved.tab;
    if (saved.posFilter) state.seasonPosFilter = saved.posFilter;
    if (saved.teamSrc && SOURCES[saved.teamSrc]) state.seasonTeamSrc = saved.teamSrc;
  }

  // ---------- open-data feeds (Sleeper public API) ----------
  async function ensureNflState() {
    if (state.nflState) return;
    if (MOCK && MOCK.nflState) {
      state.nflState = MOCK.nflState;
    } else {
      try { state.nflState = (await fetchJson('https://api.sleeper.app/v1/state/nfl')) || {}; }
      catch (e) { state.nflState = {}; }
    }
    const nfl = state.nflState;
    const wk = nfl && nfl.season_type === 'regular' ? nfl.week : null;
    state.seasonWeek = wk && wk >= 1 ? wk : 1;
    state.byesActive = !!(nfl && nfl.season_type === 'regular');
  }
  async function fetchInjuries() {
    if (MOCK) { state.slMeta = MOCK.slMeta || {}; return; }
    try {
      const saved = await store.get(['yahooHelper.slMeta2']);
      const cached = saved['yahooHelper.slMeta2'];
      if (cached && cached.ts && Date.now() - cached.ts < INJ_TTL_MS) {
        state.slMeta = cached.map || {};
        render();
        return;
      }
    } catch (e) {}
    try {
      const all = await fetchJson('https://api.sleeper.app/v1/players/nfl');
      const map = {};
      const OUT_STATUS = /^(Injured Reserve|Physically Unable|Non Football|Suspended|Reserve)/i;
      const KEEP = { QB: 1, RB: 1, WR: 1, TE: 1, K: 1, DST: 1 };
      for (const sid of Object.keys(all || {})) {
        const pl = all[sid];
        if (!pl) continue;
        const pos = pl.position === 'DEF' ? 'DST' : pl.position;
        if (!KEEP[pos]) continue;
        let inj = null;
        const is = pl.injury_status || '';
        if (/^(Out|IR|PUP|COV|Sus|NA|DNR)/i.test(is) || OUT_STATUS.test(pl.status || '')) inj = 'OUT';
        else if (/^Doubtful/i.test(is)) inj = 'D';
        else if (/^Questionable/i.test(is)) inj = 'Q';
        const entry = { n: ((pl.first_name || '') + ' ' + (pl.last_name || '')).trim(), pos, tm: pl.team || '' };
        if (inj) entry.inj = inj;
        // Detail fields for the injury popover (2026-08-27): raw status, body
        // part, start date, note — same Sleeper dump, so no extra request.
        if (pl.injury_status) entry.is = pl.injury_status;
        if (pl.status && pl.status !== 'Active') entry.st = pl.status;
        if (pl.injury_body_part) entry.ib = pl.injury_body_part;
        if (pl.injury_start_date) entry.idt = pl.injury_start_date;
        if (pl.injury_notes) entry.inx = String(pl.injury_notes).slice(0, 200);
        map[sid] = entry;
      }
      state.slMeta = map;
      store.set({ 'yahooHelper.slMeta2': { ts: Date.now(), map } });
      render();
    } catch (e) { /* flags just stay off */ }
  }
  async function fetchSeasonStats() {
    if (MOCK) return;
    if (!state.byesActive || state.seasonWeek <= 1) return;
    const upTo = state.seasonWeek - 1;
    const season = (state.nflState && state.nflState.season) || '2026';
    try {
      const saved = await store.get(['yahooHelper.seasonStats']);
      const c = saved['yahooHelper.seasonStats'];
      if (c && c.season === season && c.upToWk === upTo && Date.now() - c.ts < 6 * 3600 * 1000) {
        state.seasonStats = c;
        render();
        return;
      }
    } catch (e) {}
    try {
      const byId = {};
      for (let wk = 1; wk <= upTo; wk++) {
        const stats = await fetchJson('https://api.sleeper.app/v1/stats/nfl/regular/' + season + '/' + wk);
        if (!stats) continue;
        for (const sid of Object.keys(stats)) {
          const s = stats[sid];
          if (!s || !s.gp) continue;
          const rec = byId[sid] || (byId[sid] = { ppr: 0, half: 0, std: 0, gp: 0 });
          rec.ppr += s.pts_ppr || 0;
          rec.half += s.pts_half_ppr || 0;
          rec.std += s.pts_std || 0;
          rec.gp += 1;
        }
      }
      state.seasonStats = { ts: Date.now(), season, upToWk: upTo, byId };
      store.set({ 'yahooHelper.seasonStats': state.seasonStats });
      render();
    } catch (e) { /* preseason projections just stand */ }
  }
  function actualPpgFor(p) {
    const st = state.seasonStats;
    const rec = st && p.sid && st.byId[p.sid];
    if (!rec || !rec.gp) return null;
    const recPts = (state.scoringVals && state.scoringVals.recPts != null) ? state.scoringVals.recPts : 1;
    const total = recPts >= 0.75 ? rec.ppr : recPts <= 0.25 ? rec.std : rec.half;
    return { ppg: total / rec.gp, gp: rec.gp };
  }
  async function fetchTrending() {
    if (MOCK) { state.trendAdds = MOCK.trendAdds || {}; return; }
    try {
      const t = await fetchJson('https://api.sleeper.app/v1/players/nfl/trending/add?lookback_hours=24&limit=50');
      state.trendAdds = {};
      if (Array.isArray(t)) for (const x of t) state.trendAdds[String(x.player_id)] = x.count;
    } catch (e) {}
  }

  // ---------- weekly value ----------
  function onByeThisWeek(p) {
    if (!state.byesActive) return false;
    if (p.bye != null) return p.bye === state.seasonWeek;
    const sch = p.sTm && state.schedule[p.sTm];
    return !!(sch && Object.keys(sch).length >= 8 && !sch[state.seasonWeek]);
  }
  function injOf(p) {
    const k = keyOf(p);
    if (state.scrapedInj[k]) return state.scrapedInj[k]; // Yahoo's own flag is freshest
    const m = p.sid && state.slMeta[p.sid];
    return (m && m.inj) || null;
  }
  function propsProjFor(p) {
    const all = state.wkPropsAll;
    if (!all || p._unmatched) return null;
    const wk = String(state.seasonWeek);
    const cacheKey = wk + '|' + state.scoringLabel;
    if (p._wkpKey === cacheKey) return p._wkpVal;
    if (!state._wkPropsIdx || state._wkPropsIdx.wk !== wk) {
      const map = {};
      const block = all[wk] || {};
      for (const nm of Object.keys(block)) map[norm(nm)] = block[nm];
      state._wkPropsIdx = { wk, map };
    }
    const rec = state._wkPropsIdx.map[norm(p.n)];
    let out = null;
    const books = rec ? [rec.UD, rec.PP].filter(Boolean) : [];
    if (books.length) {
      const avg = (k) => {
        const vs = books.map((b) => b[k]).filter((v) => typeof v === 'number');
        return vs.length ? vs.reduce((a, b) => a + b, 0) / vs.length : null;
      };
      const py = avg('py'), ry = avg('ry'), rcy = avg('rcy');
      if (py != null || ry != null || rcy != null) {
        const sv = state.scoringVals || { recPts: 0.5, passTd: 4 };
        let pts = 0;
        if (py != null) {
          const ptd = avg('ptd');
          pts += py * 0.04 + (ptd != null ? ptd : py / 125) * (sv.passTd != null ? sv.passTd : 4);
          const ints = avg('int');
          if (ints != null) pts -= ints;
        }
        if (ry != null) pts += ry * 0.1;
        if (rcy != null) {
          pts += rcy * 0.1;
          const recEst = rcy / (p.s === 'RB' ? 7.5 : 11.5);
          pts += recEst * (sv.recPts != null ? sv.recPts : 0.5);
        }
        const atd = avg('atd');
        if (atd != null) {
          const prob = atd < 0 ? -atd / (-atd + 100) : 100 / (atd + 100);
          pts += prob * (p.s === 'QB' ? 1 : 1.1) * 6;
        }
        out = Math.round(pts * 10) / 10;
      }
    }
    p._wkpKey = cacheKey;
    p._wkpVal = out;
    return out;
  }
  // ---- Opponent matchup grade — mirrors the site's WEEKLY OPP color ----
  // Grades this week's opponent for the player's position on SCHEDULE-
  // ADJUSTED fantasy points allowed per game this season (site
  // fpa_2026.json, FINAL games only; the strength of the offenses faced is
  // stripped out by an additive defense-effect / offense-effect ridge fit)
  // 2026-10-05 (site app.js _mtObservedFpa, "THE OPPONENT GRADE"): when the
  // feed carries last season's numbers (fpa_2026.json `prior`, written by the
  // postgame importer from data/fpa_prior_2025.js) the grade is
  //   w x this season + (1 - w) x last season,  w = games / (games + k),
  // k QB 3 / RB 4 / WR 6 / TE 2 / D/ST 2, both sides schedule-adjusted and
  // TOUCHDOWN-NEUTRAL (<POS>_tdn keys). Clay is out of it. Backtest 2016-25
  // (scripts/research_opp_grade_schemes.py): beat in-season-only at every
  // position. Displayed points allowed stay ACTUAL in the board's format.
  // Fallback when the prior is missing: the schedule-adjusted points allowed
  // blended with Clay's preseason unit rank (sim_pack's CLAY_TEAM_GRADES_2026),
  // fading OUT by game 4 (was 8 until 2026-10-05): weight = min(1, sqrt(g / 4)).
  // Rank 1 = softest; top third easy (green), bottom third hard (red), middle =
  // tooltip only. D/ST grades the opposing OFFENSE (D/ST points it gives up;
  // Clay offRk in the fallback). K gets no grade, so wkOppInfo keeps its Vegas
  // fallback there (and whenever the fetch fails).
  // Same math as app.js _wkSchedAdjust / _mtObservedFpa / _wkOppBlendTable — keep in sync.
  const OPP_FADE_GAMES = 4;   // fallback only: Clay prior gone once the opponent has this many final games
  const OPP_PRIOR_K = { QB: 3, RB: 4, WR: 6, TE: 2, DST: 2 };   // last season is worth k games of this one
  const OPP_ABBR_FIX = { WSH: 'WAS', LA: 'LAR', JAC: 'JAX', OAK: 'LV', SD: 'LAC' };
  let _oppGradeCache = null;
  function oppSchedAdjust(games, K) {
    if (!games || !games.length) return null;
    if (typeof K !== 'number') K = 1;
    let mu = 0; games.forEach((g) => { mu += g.v; }); mu /= games.length;
    const dE = {}, oE = {}, dN = {}, oN = {};
    games.forEach((g) => { dE[g.d] = 0; oE[g.o] = 0; dN[g.d] = (dN[g.d] || 0) + 1; oN[g.o] = (oN[g.o] || 0) + 1; });
    for (let it = 0; it < 50; it++) {
      const ds = {}; games.forEach((g) => { ds[g.d] = (ds[g.d] || 0) + (g.v - mu - oE[g.o]); });
      Object.keys(dE).forEach((t) => { dE[t] = ds[t] / (dN[t] + K); });
      const os = {}; games.forEach((g) => { os[g.o] = (os[g.o] || 0) + (g.v - mu - dE[g.d]); });
      Object.keys(oE).forEach((t) => { oE[t] = os[t] / (oN[t] + K); });
    }
    return { mu, dE, oE };
  }
  // {team: {z, w}} - lower z = softer (site sign); null = fall back to the Clay fade
  function oppBlendedZ(pos) {
    const FP = state.fpa;
    const PR = FP && FP.prior && FP.prior.pos && FP.prior.pos[pos];
    if (!FP || !FP.weeks || !PR || !OPP_PRIOR_K[pos]) return null;
    const acc = {}, games = [];
    Object.keys(FP.weeks).forEach((wk) => {
      const teams = FP.weeks[wk];
      Object.keys(teams).forEach((team) => {
        const rec = teams[team];
        let v = rec[pos];
        if (typeof v !== 'number') return;
        if (typeof rec[pos + '_tdn'] === 'number') v = rec[pos + '_tdn'];
        const t = acc[team] || (acc[team] = { pts: 0, wks: {} });
        t.pts += v; t.wks[wk] = 1;
        let o = rec.opp ? String(rec.opp).toUpperCase() : null;
        if (o) { o = OPP_ABBR_FIX[o] || o; games.push({ d: team, o, v }); }
      });
    });
    const gp = (t) => (acc[t] ? Object.keys(acc[t].wks).length : 0);
    const perGame = {};
    Object.keys(acc).forEach((t) => { perGame[t] = acc[t].pts / gp(t); });
    const S = oppSchedAdjust(games, 1);
    if (S) Object.keys(perGame).forEach((t) => { if (typeof S.dE[t] === 'number') perGame[t] = S.mu + S.dE[t]; });
    const zOf = (m) => {
      const ks = Object.keys(m).filter((t) => typeof m[t] === 'number');
      if (ks.length < 24) return null;   // need most of the league before z-scoring
      const mu = ks.reduce((a, t) => a + m[t], 0) / ks.length;
      const sd = Math.sqrt(ks.reduce((a, t) => a + (m[t] - mu) * (m[t] - mu), 0) / ks.length) || 1;
      const z = {};
      ks.forEach((t) => { z[t] = -(m[t] - mu) / sd; });   // more allowed = softer = lower
      return z;
    };
    const zi = zOf(perGame), zp = zOf(PR);
    if (!zi || !zp) return null;
    const k = OPP_PRIOR_K[pos], out = {};
    Object.keys(Object.assign({}, zp, zi)).forEach((t) => {
      const a = zi[t], b = zp[t];
      const w = typeof a !== 'number' ? 0 : typeof b !== 'number' ? 1 : gp(t) / (gp(t) + k);
      out[t] = { z: w * (typeof a === 'number' ? a : 0) + (1 - w) * (typeof b === 'number' ? b : 0), w };
    });
    return out;
  }
  function oppFmtSuffix() {
    const recPts = (state.scoringVals && state.scoringVals.recPts != null) ? state.scoringVals.recPts : 1;
    return recPts >= 0.75 ? '_ppr' : recPts >= 0.25 ? '' : '_std';
  }
  function oppGradeTable(pos) {
    const FP = state.fpa;
    const suf = oppFmtSuffix();
    const src = (FP && FP.weeks) || null;
    if (!_oppGradeCache || _oppGradeCache.src !== src || _oppGradeCache.suf !== suf) _oppGradeCache = { src, suf, pos: {} };
    if (_oppGradeCache.pos[pos]) return _oppGradeCache.pos[pos];
    // 1) raw + schedule-adjusted points allowed per game to this position
    const acc = {}, games = [];
    if (src) Object.keys(src).forEach((wk) => {
      const teams = src[wk];
      Object.keys(teams).forEach((team) => {
        const rec = teams[team];
        const key = (pos === 'K' || pos === 'DST') ? pos : (typeof rec[pos + suf] === 'number' ? pos + suf : pos);
        const v = rec[key];
        if (typeof v !== 'number') return;
        const t = acc[team] || (acc[team] = { pts: 0, g: 0 });
        t.pts += v; t.g++;
        let o = rec.opp ? String(rec.opp).toUpperCase() : null;
        if (o) { o = OPP_ABBR_FIX[o] || o; games.push({ d: team, o, v }); }
      });
    });
    const A = {};
    const rows = Object.keys(acc).map((team) => ({ team, v: acc[team].pts / acc[team].g, g: acc[team].g }));
    rows.sort((a, b) => b.v - a.v);
    rows.forEach((r, i) => { A[r.team] = { v: Math.round(r.v * 10) / 10, rank: i + 1, n: rows.length, games: r.g }; });
    const S = oppSchedAdjust(games, 1);
    if (S) {
      const adj = rows.map((r) => ({ team: r.team, v: S.mu + (S.dE[r.team] || 0) }));
      adj.sort((a, b) => b.v - a.v);
      adj.forEach((r, i) => { A[r.team].adjV = Math.round(r.v * 10) / 10; A[r.team].adjRank = i + 1; });
    }
    // 2) the shared opponent grade (this season x last season) when the prior is in the feed
    const B = oppBlendedZ(pos);
    if (B) {
      const gr = Object.keys(B).map((t) => ({ team: t, score: -B[t].z })).sort((a, b) => b.score - a.score);
      const gn = gr.length, gThird = gn / 3, gOut = {};
      gr.forEach((r, i) => {
        const rank = i + 1, a = A[r.team];
        gOut[r.team] = { diff: rank <= gThird ? 'easy' : rank > 2 * gThird ? 'hard' : 'medium', rank, n: gn,
          games: a ? a.games : 0, w: B[r.team].w, clayRk: null, lastSeason: true,
          raw: a ? { v: a.v, rank: a.rank } : null,
          adj: (a && typeof a.adjRank === 'number') ? { v: a.adjV, rank: a.adjRank } : null };
      });
      _oppGradeCache.pos[pos] = gOut;
      return gOut;
    }
    // 3) fallback: blend with Clay's preseason rank (fades out by OPP_FADE_GAMES games)
    const CG = (typeof window !== 'undefined' && window.CLAY_TEAM_GRADES_2026) || {};
    const teams = {};
    Object.keys(CG).forEach((t) => { teams[t] = 1; });
    Object.keys(A).forEach((t) => { teams[t] = 1; });
    const list = Object.keys(teams).map((t) => {
      const cg = CG[t];
      const clayRk = cg ? (pos === 'DST' ? cg.offRk : cg.defRk) : null;
      const pClay = typeof clayRk === 'number' ? (clayRk - 1) / 31 : null;   // 1 = toughest → 0
      const a = A[t];
      const pIn = (a && a.n > 1 && typeof a.adjRank === 'number') ? 1 - (a.adjRank - 1) / (a.n - 1) : null;   // rank 1 = allows most → 1
      const g = a ? a.games : 0;
      const w = Math.min(1, Math.sqrt(g / OPP_FADE_GAMES));
      let score = null;
      if (pIn == null && pClay == null) score = null;
      else if (pIn == null) score = pClay;
      else if (pClay == null) score = pIn;
      else score = w * pIn + (1 - w) * pClay;
      return { team: t, score, clayRk, games: g, w: pIn == null ? 0 : w,
        raw: a ? { v: a.v, rank: a.rank } : null,
        adj: (a && typeof a.adjRank === 'number') ? { v: a.adjV, rank: a.adjRank } : null };
    }).filter((r) => r.score != null);
    list.sort((a, b) => b.score - a.score);
    const n = list.length, third = n / 3;
    const out = {};
    list.forEach((r, i) => {
      const rank = i + 1;
      out[r.team] = { diff: rank <= third ? 'easy' : rank > 2 * third ? 'hard' : 'medium', rank, n,
        games: r.games, w: r.w, clayRk: r.clayRk, raw: r.raw, adj: r.adj };
    });
    _oppGradeCache.pos[pos] = out;
    return out;
  }
  function oppGradeFor(opp, pos) {
    if (!opp || !pos || pos === 'K') return null;
    let o = String(opp).replace(/^@/, '').toUpperCase();
    o = OPP_ABBR_FIX[o] || o;
    const T = oppGradeTable(pos);
    return T[o] ? Object.assign({ opp: o }, T[o]) : null;
  }
  function oppGradeNote(m, pos) {
    if (!m) return '';
    const lbl = m.diff === 'hard' ? 'Tough' : m.diff === 'easy' ? 'Soft' : 'Average';
    const posLbl = pos === 'DST' ? 'D/STs' : pos + 's';
    let s = lbl + ' matchup for ' + posLbl + ' (#' + m.rank + ' of ' + m.n + ', 1 = softest)';
    if (m.adj) s += ' — allows ' + m.raw.v + ' pts/gm (#' + m.raw.rank + ' raw, #' + m.adj.rank + ' schedule-adjusted, ' + m.games + ' gm)';
    if (m.lastSeason) {
      const pc = Math.round(m.w * 100);
      s += ' · grade = ' + pc + '% this season, ' + (100 - pc) + '% last season, touchdown luck removed';
      return s;
    }
    if (typeof m.clayRk === 'number' && !(m.adj && m.w >= 1)) s += ' · Clay preseason ' + (pos === 'DST' ? 'offense' : 'defense') + ' #' + m.clayRk;
    s += m.adj ? ' · in-season weight ' + Math.round(m.w * 100) + '%' : ' · preseason only until final games post';
    return s;
  }
  function wkOppInfo(p) {
    const g = p.sTm && state.schedule[p.sTm] && state.schedule[p.sTm][state.seasonWeek];
    if (!g) return null;
    let val = g.implied, good, bad;
    if (p.s === 'DST') val = (g.total != null && g.implied != null) ? Math.round((g.total - g.implied) * 10) / 10 : null;
    // Site-style matchup grade first (schedule-adjusted pts allowed + fading
    // Clay prior, see oppGradeTable); Vegas implied-total thresholds only
    // when there's no grade (K, or the fpa_2026.json fetch hasn't landed).
    const m = oppGradeFor(g.opp, p.s);
    if (m) {
      good = m.diff === 'easy';
      bad = m.diff === 'hard';
    } else if (p.s === 'DST') {
      good = val != null && val <= 20.5;
      bad = val != null && val >= 25.5;
    } else {
      good = val != null && val >= 26;
      bad = val != null && val <= 20.5;
    }
    const col = good ? ['#2a4030', '#6dd06d'] : bad ? ['#402a2a', '#d06d6d'] : ['#2a2c33', '#c8ccd4'];
    const txt = (g.home ? 'vs' : '@') + g.opp;
    return {
      txt, bg: col[0], fg: col[1], cls: good ? 'good' : bad ? 'bad' : 'mid',
      tip: 'Wk ' + state.seasonWeek + ' ' + txt +
        (g.total != null ? ' · O/U ' + g.total : '') +
        (g.implied != null ? ' · implied ' + g.implied : '') +
        (p.s === 'DST' && val != null ? ' · opp implied ' + val : '') +
        (m ? ' — ' + oppGradeNote(m, p.s) : ''),
    };
  }
  function wkOppHTML(p) {
    const g = wkOppInfo(p);
    if (!g) return '';
    return `<span class="tag" style="background:${g.bg};color:${g.fg}" title="${esc(g.tip)}">${esc(g.txt)}</span>`;
  }
  // K/DST models — verbatim from the Sleeper/ESPN helpers. The built-in
  // defaults ARE Yahoo's default kicker/DST scoring, so they hold even with
  // no scraped scoring rules.
  const FG_MIX_AVG = [0.02, 0.22, 0.30, 0.30, 0.16];
  const FG_KEYS = ['fgm_0_19', 'fgm_20_29', 'fgm_30_39', 'fgm_40_49', 'fgm_50p'];
  const FG_DEF_PTS = [3, 3, 3, 4, 5];
  function kickerProjFor(p, g) {
    const T = g && g.implied != null ? g.implied : 22.5;
    if (p.kFga == null) return 5 + (T - 22.5) * 0.3;
    const gm = p.cGm || 17;
    const fgScale = (0.036 * T + 0.74) / 1.55;
    const xpScale = Math.max(0.2, (0.115 * T - 0.29) / 2.3);
    const fgm = (p.kFgm / gm) * fgScale;
    const fga = (p.kFga / gm) * fgScale;
    const xpm = ((p.kXpm != null ? p.kXpm : p.kFgm * 1.3) / gm) * xpScale;
    const xpa = ((p.kXpa != null ? p.kXpa : p.kXpm || 0) / gm) * xpScale;
    const sc = state.leagueScoring || {};
    const mix = (p.kD && p.kD.length === 5) ? p.kD : FG_MIX_AVG;
    let pts = 0;
    for (let i = 0; i < 5; i++) {
      pts += fgm * mix[i] * (sc[FG_KEYS[i]] != null ? sc[FG_KEYS[i]] : FG_DEF_PTS[i]);
    }
    pts += xpm * (sc.xpm != null ? sc.xpm : 1);
    if (sc.fgmiss) pts += (fga - fgm) * sc.fgmiss;
    if (sc.xpmiss) pts += Math.max(0, xpa - xpm) * sc.xpmiss;
    return pts;
  }
  const PA_BUCKETS = [
    ['pts_allow_0', -0.5, 0.5, 10],
    ['pts_allow_1_6', 0.5, 6.5, 7],
    ['pts_allow_7_13', 6.5, 13.5, 4],
    ['pts_allow_14_20', 13.5, 20.5, 1],
    ['pts_allow_21_27', 20.5, 27.5, 0],
    ['pts_allow_28_34', 27.5, 34.5, -1],
    ['pts_allow_35p', 34.5, 99.5, -4],
  ];
  function dstProjFor(p, g) {
    const O = g && g.total != null && g.implied != null ? g.total - g.implied : 22.5;
    const sc = state.leagueScoring || {};
    const val = (k, d) => (sc[k] != null ? sc[k] : d);
    const q = p.dRk != null ? 1 + (16.5 - p.dRk) * 0.012 : 1;
    const sacks = Math.max(0.5, 3.6 - 0.055 * O) * q;
    const ints = Math.max(0.2, 1.5 - 0.025 * O) * q;
    const dtd = Math.max(0.05, 0.28 - 0.005 * O) * q;
    let pts = sacks * val('sack', 1) + ints * val('int', 2) + 0.5 * q * val('fum_rec', 2) +
      dtd * val('def_td', 6) + 0.06 * q * val('safe', 2) + 0.07 * q * val('blk_kick', 2);
    if (sc.ff) pts += 0.85 * q * sc.ff;
    const cdf = (x) => 1 / (1 + Math.exp(-(x - O) / 5.6));
    for (let i = 0; i < PA_BUCKETS.length; i++) {
      const b = PA_BUCKETS[i];
      pts += (cdf(b[2]) - cdf(b[1])) * val(b[0], b[3]);
    }
    return pts;
  }
  function wkVal(p) {
    if (onByeThisWeek(p)) return 0;
    const act = actualPpgFor(p);
    const shrink = act ? act.gp / (act.gp + PRIOR_GAMES) : 0;
    let v;
    // SIM-FIRST, ALL positions (Jack 2026-09-08: "take it directly off the
    // site"): the site's Sim Lab weekly row IS the number — the same value
    // the site's WEEKLY PROJ column shows (K/DST included) — plus the
    // league-scoring delta (rec / pass-TD / TE premium) so custom leagues
    // re-score correctly. No rank nudge, no D/Q re-discount (the export
    // already prices designations); OUT (fresher live status) still zeroes.
    // Everything below is fallback for players without a sim row.
    {
      const _six = simProjIdx();
      const _wkMap = _six && (_six.weeks[state.seasonWeek] || _six.weeks[state.simProj.currentWeek]);
      const _sr = _wkMap && _wkMap[simKeyFor(p)];
      if (_sr && typeof _sr[1] === 'number') {
        if (_sr[1] === 0 && _sr[3] == null) return 0; // ruled out at export time
        if (injOf(p) === 'OUT') return 0;
        return Math.round(Math.max(0, _sr[1] + simLeagueDeltaPg(p)) * 100) / 100;
      }
    }
    if (p.s === 'K' || p.s === 'DST') {
      const g = p.sTm && state.schedule[p.sTm] && state.schedule[p.sTm][state.seasonWeek];
      v = p.s === 'K' ? kickerProjFor(p, g) : dstProjFor(p, g);
      if (act) {
        const prior = p.s === 'K' ? (p.pPg != null ? p.pPg : 7.5) : dstProjFor(p, null);
        v += (act.ppg - prior) * shrink;
      }
      v = Math.max(1, v);
    } else {
      // FALLBACK (no sim row): props/Clay blend.
      let base = p.pPg != null ? p.pPg : 0;
      if (act) base += (act.ppg - base) * shrink;
      v = base;
      const props = propsProjFor(p);
      if (props != null) v = (p.pPg != null || act) ? 0.8 * props + 0.2 * base : props;
    }
    const inj = injOf(p);
    if (inj) {
      if (inj === 'OUT') return 0;
      if (inj === 'D') v *= 0.3;
      else if (inj === 'Q') v *= 0.85;
    }
    if (v > 0 && p.rank != null && !p._unmatched && p.s !== 'K' && p.s !== 'DST') {
      v += Math.max(-0.67, Math.min(1, (100 - p.rank) / 100)) * 1.5;
      if (v < 0) v = 0;
    }
    return Math.round(v * 100) / 100;
  }

  // ---------- lineup / waivers (identity = keyOf) ----------
  function myPlayerObjs() {
    return state.roster.map((en) => en.p ||
      { n: en.name, s: en.pos || '?', sTm: en.team, rank: 9999, _unmatched: true });
  }
  function currentStarterKeys() {
    return new Set(state.roster.filter((en) => en.starting).map((en) => en.key));
  }
  function optimalLineup(pool) {
    const slots = state.seasonSlots || [];
    const order = slots.map((s, i) => ({ s, i, w: SLOT_ELIG[s] ? SLOT_ELIG[s].length : 99 }))
      .sort((a, b) => a.w - b.w);
    const entries = pool.map((p) => ({ p, v: wkVal(p) }))
      .sort((a, b) => b.v - a.v || ((a.p.rank || 9999) - (b.p.rank || 9999)));
    const used = new Set();
    const byIdx = {};
    let total = 0;
    for (const o of order) {
      const elig = SLOT_ELIG[o.s];
      if (!elig) { byIdx[o.i] = null; continue; }
      const e = entries.find((x) => !used.has(x) && elig.indexOf(x.p.s) !== -1);
      if (e) { used.add(e); byIdx[o.i] = e; total += e.v; }
      else byIdx[o.i] = null;
    }
    return {
      assign: slots.map((s, i) => ({ slot: s, e: byIdx[i] || null })),
      total: Math.round(total * 10) / 10,
    };
  }
  function lineupMoves(opt, starterSet, pool) {
    const adds = opt.assign
      .filter((a) => a.e && !starterSet.has(keyOf(a.e.p)))
      .map((a) => a.e)
      .sort((a, b) => b.v - a.v);
    const optKeys = new Set(opt.assign.filter((a) => a.e).map((a) => keyOf(a.e.p)));
    const sits = pool.filter((p) => starterSet.has(keyOf(p)) && !optKeys.has(keyOf(p)))
      .map((p) => ({ p, v: wkVal(p) }))
      .sort((a, b) => a.v - b.v);
    const usedSit = new Set();
    return adds.map((add) => {
      const sit = sits.find((s) => !usedSit.has(s) && s.p.s === add.p.s) ||
                  sits.find((s) => !usedSit.has(s)) || null;
      if (sit) usedSit.add(sit);
      return { add, sit, delta: sit ? Math.round((add.v - sit.v) * 10) / 10 : null };
    });
  }
  function seasonLineupCalc() {
    if (!state.roster.length || !state.seasonSlots) return null;
    const pool = myPlayerObjs();
    const opt = optimalLineup(pool);
    const starterSet = currentStarterKeys();
    const moves = lineupMoves(opt, starterSet, pool);
    const cls = {};
    for (const mv of moves) {
      if (mv.sit && mv.delta != null && Math.abs(mv.delta) < CLOSE_PPG) {
        cls[keyOf(mv.add.p)] = 'close';
        cls[keyOf(mv.sit.p)] = 'close';
      } else {
        cls[keyOf(mv.add.p)] = 'go';
        if (mv.sit) cls[keyOf(mv.sit.p)] = 'sit';
      }
    }
    return { pool, opt, starterSet, moves, cls };
  }
  // Yahoo can't enumerate league-mates' rosters over the DOM, so the FA pool
  // is what the user has BROWSED on the league's Players page (rows without
  // an owner link), accumulated per league.
  function freeAgents() {
    // `p.ir` = the site's OUT FOR SEASON flag. Never surface one as a free
    // agent worth adding; dynasty keeps them, matching the site's split.
    // `p.rm` = removed from Jack's live redraft board (see applyFullOrder).
    return state.players.filter((p) => state.faSeen[keyOf(p)] && !state.myKeys.has(keyOf(p)) &&
      !(p.ir && !isDynMode()) && !p.rm);
  }
  function waiverRecs() {
    const mine = myPlayerObjs();
    const base = optimalLineup(mine).total;
    const dyn = state.mode.indexOf('dyn') === 0;
    const mk = modeKeys();
    const fas = freeAgents().filter(
      (p) => state.seasonPosFilter === 'ALL' || p.s === state.seasonPosFilter
    );
    const scored = fas.map((p) => {
      const delta = Math.round((optimalLineup(mine.concat([p])).total - base) * 10) / 10;
      const trend = (p.sid && state.trendAdds[p.sid]) || 0;
      let score = delta * 4 + (p.pPg || 0) * 0.6;
      if (dyn && p[mk.ktc] != null) score += p[mk.ktc] / 400;
      if (trend) score += Math.min(3, Math.log10(trend + 1) * 1.5);
      return { p, delta, trend, score: Math.round(score * 10) / 10 };
    });
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, 25);
  }
  function dropCandidates() {
    const mine = myPlayerObjs();
    const base = optimalLineup(mine).total;
    const dyn = state.mode.indexOf('dyn') === 0;
    const mk = modeKeys();
    const slots = state.seasonSlots || [];
    const posCount = {};
    for (const p of mine) posCount[p.s] = (posCount[p.s] || 0) + 1;
    const required = new Set(slots.map((s) => (SLOT_ELIG[s] && SLOT_ELIG[s].length === 1) ? SLOT_ELIG[s][0] : null));
    return mine.map((p) => {
      const marginal = Math.round((base - optimalLineup(mine.filter((x) => x !== p)).total) * 10) / 10;
      let keep = marginal * 4 + (p.pPg || 0);
      if (dyn && !p._unmatched && p[mk.ktc] != null) keep += p[mk.ktc] / 300;
      if (required.has(p.s) && (posCount[p.s] || 0) <= 1) keep += 100;
      return { p, marginal, keep };
    }).sort((a, b) => a.keep - b.keep);
  }

  // ---------- SIMS tab: Monte Carlo season sims (port of the ESPN helper's) ----------
  // Engine + data ride the same bundle (engine_sim.js + data/sim_pack.js);
  // live Vegas lands in window.BETTING_2026 from the site fetch in main().
  // League rosters: Yahoo's pub-api has no fantasy-ownership route, so every
  // team's roster is read the way the EXPORT feature reads them — one
  // same-origin HTML fetch per team page, parsed with the sidebar's own row
  // parser, cached per day. Matchup pairings aren't exposed either, so the
  // sim always runs a synthetic round-robin schedule.
  const SIM_RUNS = 1500, SIM_SEED = 99;
  state.seasonTeams = [];
  state.myTeamId = null;
  state.playoffTeams = 6;
  state.playoffStart = 15;
  state.seasonSim = { leagueId: null, status: 'idle', results: null, placeCounts: null,
    sims: SIM_RUNS, recHash: null, synthPairs: true, note: '', selTeam: null };
  function simAvailable() {
    return !!(window.SimEngine && typeof MIKE_CLAY_PROJ !== 'undefined' &&
      typeof PLAYER_WEEKLY_SIGMA !== 'undefined' && window.BETTING_2026);
  }
  function simEnsureGlobals() {
    if (!window.SIM_SLEEPER) {
      window.SIM_SLEEPER = { players: state.players.filter((p) => p.sid).map((p) => ({
        n: p.n, sid: p.sid, a: p.a, age: p.age, ktc1qb: p.ktc1qb, ktcSf: p.ktcSf })) };
    }
    const meta = {};
    for (const sid of Object.keys(state.slMeta)) {
      const e = state.slMeta[sid];
      if (e.inj) meta[sid] = { inj: e.inj };
    }
    window.SIM_SLEEPER_META = meta;
  }
  function simUnavailable() {
    // Yahoo's slMeta collapses statuses to OUT/D/Q, so season-long vs weekly
    // outs can't be split like ESPN's: league-enforced IR slots sim as gone
    // all season; a weekly OUT flag benches the current week (regular season
    // only); Q/D stay in — the sim's variance owns those.
    const out = {};
    if (state.byesActive) {
      for (const sid of Object.keys(state.slMeta)) {
        if (state.slMeta[sid].inj === 'OUT') out[sid] = 'out';
      }
    }
    state.seasonTeams.forEach((t) => t.entries.forEach((en) => {
      if (!en.p || !en.p.sid) return;
      if (en.slotLbl === 'IR') out[en.p.sid] = 'ir';
      else if (state.byesActive && en.inj === 'OUT' && !out[en.p.sid]) out[en.p.sid] = 'out';
    }));
    return out;
  }
  function simTeams() {
    return state.seasonTeams.map((t) => ({
      rosterId: t.teamId,
      name: t.name,
      playerIds: t.entries.filter((en) => en.p && en.p.sid && en.slotLbl !== 'IR')
        .map((en) => String(en.p.sid)),
      record: null, // Yahoo standings records not parsed yet (preseason anyway)
    }));
  }
  function simRecHash() {
    return state.seasonTeams.map((t) =>
      t.teamId + ':' + t.entries.length).join('|');
  }
  function simRoundRobin(ids, weeks) {
    const arr = ids.slice();
    if (arr.length % 2) arr.push(null);
    const n = arr.length, half = n / 2, pairsByWeek = {};
    weeks.forEach((wk) => {
      const prs = [];
      for (let j = 0; j < half; j++) {
        const a = arr[j], b = arr[n - 1 - j];
        if (a != null && b != null) prs.push({ a, b });
      }
      pairsByWeek[wk] = prs;
      arr.splice(1, 0, arr.pop()); // rotate all but first
    });
    return pairsByWeek;
  }
  function fetchDoc(path) {
    return fetch(path, { credentials: 'include' }).then((r) => r.text())
      .then((t) => new DOMParser().parseFromString(t, 'text/html'));
  }
  function parseRosterDoc(doc) {
    const scoped = doc.querySelectorAll('table[id^="statTable"] tr');
    const rows = scoped.length ? scoped : doc.querySelectorAll('tr');
    const entries = [];
    for (const row of rows) {
      const cells = row.querySelectorAll('td');
      if (cells.length < 2) continue;
      const slotTok = cells[0].textContent.trim().toUpperCase().replace(/\s+/g, '');
      const slotLbl = SLOT_MAP[slotTok];
      if (!slotLbl) continue;
      const info = parsePlayerCell(row);
      if (!info) continue;
      entries.push(Object.assign(info, { slotLbl }));
    }
    return entries;
  }
  function detectMyTeamId(doc) {
    const lid = state.leagueId;
    for (const a of doc.querySelectorAll('a')) {
      if (!/my\s*team/i.test(a.textContent || '')) continue;
      const m = (a.getAttribute('href') || '').match(new RegExp('/f1/' + lid + '/(\\d{1,2})(?:$|[?#/])'));
      if (m) return parseInt(m[1], 10);
    }
    return null;
  }
  let _rostersLoading = false;
  async function fetchLeagueRosters(force) {
    if (MOCK) {
      if (MOCK.seasonTeams) {
        state.seasonTeams = MOCK.seasonTeams;
        if (MOCK.myTeamId != null) state.myTeamId = MOCK.myTeamId;
        if (state.seasonTab === 'sims') setTimeout(ensureSeasonSim, 0);
      }
      return;
    }
    const lid = state.leagueId;
    if (!lid || _rostersLoading) return;
    const day = new Date().toDateString();
    const cacheKey = 'yahooRosters_' + lid;
    if (!force) {
      try {
        const saved = await store.get([cacheKey]);
        const c = saved[cacheKey];
        if (c && c.day === day && Array.isArray(c.teams) && c.teams.length) {
          state.seasonTeams = c.teams.map((t) => ({
            teamId: t.teamId, name: t.name,
            entries: (t.entries || []).map((e) => {
              const p = matchScraped(e.name, e.pos, e.team);
              return { name: e.name, pos: e.pos, team: e.team, slotLbl: e.slotLbl,
                inj: e.inj || null, p: p || null, key: p ? keyOf(p) : norm(e.name) + '|' + e.pos };
            }),
          }));
          if (c.myTeamId != null) state.myTeamId = c.myTeamId;
          if (state.seasonTab === 'sims') setTimeout(ensureSeasonSim, 0);
          render();
          return;
        }
      } catch (e) {}
    }
    _rostersLoading = true;
    try {
      state.seasonStatus = 'Reading league rosters…';
      render();
      const home = await fetchDoc('/f1/' + lid);
      if (state.myTeamId == null) state.myTeamId = detectMyTeamId(home) || detectMyTeamId(document);
      const seen = {}, teams = [];
      home.querySelectorAll('a').forEach((a) => {
        const m = (a.getAttribute('href') || '').match(new RegExp('^/f1/' + lid + '/(\\d{1,2})(?:$|[?#])'));
        if (!m) return;
        const tid = parseInt(m[1], 10);
        const nm = a.textContent.trim();
        if (!nm || /my\s*team/i.test(nm)) return;
        const cur = teams.find((x) => x.teamId === tid);
        if (!cur) { seen[tid] = 1; teams.push({ teamId: tid, name: nm }); }
        else if (nm.length > cur.name.length) cur.name = nm;
      });
      if (!teams.length) throw new Error('no team links on league home');
      const out = [];
      for (let i = 0; i < teams.length; i++) {
        const t = teams[i];
        state.seasonStatus = 'Reading rosters… ' + (i + 1) + '/' + teams.length;
        render();
        try {
          const doc = await fetchDoc('/f1/' + lid + '/' + t.teamId);
          out.push({ teamId: t.teamId, name: t.name, entries: parseRosterDoc(doc) });
        } catch (e) { out.push({ teamId: t.teamId, name: t.name, entries: [] }); }
        await new Promise((r) => setTimeout(r, 250));
      }
      state.seasonTeams = out;
      store.set({ [cacheKey]: { day, myTeamId: state.myTeamId, teams: out.map((t) => ({
        teamId: t.teamId, name: t.name,
        entries: t.entries.map((e) => ({ name: e.name, pos: e.pos, team: e.team,
          slotLbl: e.slotLbl, inj: e.inj || null })),
      })) } });
      state.seasonStatus = state.players.length + ' players · rosters read';
      if (state.seasonTab === 'sims') setTimeout(ensureSeasonSim, 0);
    } catch (e) {
      state.seasonStatus = 'Roster read failed: ' + (e.message || e);
    }
    _rostersLoading = false;
    render();
  }
  async function ensureSeasonSim() {
    const lid = state.leagueId;
    const ps = state.seasonSim;
    if (!lid || !simAvailable()) return;
    if (!state.seasonTeams.length) { fetchLeagueRosters(); return; }
    const recHash = simRecHash();
    if (ps.leagueId === lid &&
      (ps.status === 'running' || (ps.status === 'done' && ps.recHash === recHash))) return;
    ps.leagueId = lid; ps.status = 'running'; ps.note = '';
    render();
    await new Promise((r) => setTimeout(r, 30)); // let the status paint before the sync sim
    try {
      const day = new Date().toDateString();
      const cacheKey = 'yahooSim_' + lid;
      try { // day+roster-keyed cache: finish distributions barely move intraday
        const saved = await store.get([cacheKey]);
        const c = saved[cacheKey];
        if (c && c.v === 1 && c.day === day && c.recHash === recHash && c.results) {
          Object.assign(ps, { status: 'done', results: c.results, placeCounts: c.placeCounts,
            sims: c.sims || SIM_RUNS, recHash, synthPairs: true });
          render();
          return;
        }
      } catch (e) {}
      const E2 = window.SimEngine;
      const sched = E2.buildSchedule();
      if (!sched || !Object.keys(sched.byTeam).length) throw new Error('no Vegas lines loaded');
      const curWeek = state.byesActive ? state.seasonWeek : 1;
      const playoffStart = state.playoffStart || 15;
      const regWeeks = [];
      for (let w = curWeek; w < playoffStart; w++) regWeeks.push(w);
      const teams = simTeams();
      const pairsByWeek = simRoundRobin(teams.map((t) => t.rosterId), regWeeks);
      simEnsureGlobals();
      const players = E2.buildPlayers(sched);
      const res = E2.simLeague({
        teams, sims: SIM_RUNS, seed: SIM_SEED,
        scoring: E2.scoringFromLeague(state.leagueScoring),
        schedule: sched, players, pairsByWeek, regWeeks,
        playoffTeams: state.playoffTeams || 6, playoffStart,
        lineupSlots: state.seasonSlots || [], unavailable: simUnavailable(), currentWeek: curWeek,
      });
      const placeCounts = {}, results = {};
      res.forEach((r) => {
        placeCounts[r.team.rosterId] = r.placeCounts;
        const games = regWeeks.length;
        const weekly = {};
        Object.keys(r.weekly || {}).forEach((wk) => {
          const w = r.weekly[wk];
          weekly[wk] = { opp: w.opp, winPct: +w.winPct.toFixed(3), pf: +w.avgPf.toFixed(1), pa: +w.avgPa.toFixed(1) };
        });
        results[r.team.rosterId] = {
          w: +r.avgWins.toFixed(1), l: +(games - r.avgWins).toFixed(1), pf: Math.round(r.avgPF),
          playoff: +r.playoffOdds.toFixed(3), bye: +r.byeOdds.toFixed(3),
          finals: +r.finalsOdds.toFixed(3), title: +r.titleOdds.toFixed(3), weekly,
        };
      });
      Object.assign(ps, { status: 'done', placeCounts, results, sims: SIM_RUNS, recHash });
      store.set({ [cacheKey]: { v: 1, day, recHash, placeCounts, results, sims: SIM_RUNS } });
    } catch (e) {
      ps.status = 'error';
      ps.note = e.message || String(e);
    }
    render();
  }
  function simExpFinish(rid) {
    const ps = state.seasonSim;
    const f = ps.status === 'done' && ps.placeCounts ? ps.placeCounts[rid] : null;
    if (!f) return null;
    const n = state.seasonTeams.length || 12;
    let ev = 0, mode = 1, modeP = 0;
    for (let pl = 1; pl <= n; pl++) {
      const p = (f[pl] || 0) / ps.sims;
      ev += pl * p;
      if (p > modeP) { modeP = p; mode = pl; }
    }
    return { ev, mode, modeP };
  }
  function simOrdinal(v) {
    const s = ['th', 'st', 'nd', 'rd'], t = v % 100;
    return v + (s[(t - 20) % 10] || s[t] || s[0]);
  }
  function seasonSimsHTML() {
    const ps = state.seasonSim;
    if (ps.status === 'running' || _rostersLoading) {
      return seasonHeaderHTML() +
        `<div style="padding:16px 6px;color:#8a8d96;font-size:12px">${_rostersLoading ? esc(state.seasonStatus) : 'Running ' + SIM_RUNS.toLocaleString() + ' season sims…'}</div>`;
    }
    if (ps.status === 'idle') setTimeout(ensureSeasonSim, 0);
    const note = ps.status === 'error'
      ? `<div style="background:#402a2a;color:#d06d6d;font-size:10px;padding:4px 6px;border-radius:4px;margin-bottom:6px">Sim unavailable: ${esc(ps.note || 'unknown')}</div>` : '';
    const myRid = state.myTeamId;
    const nameById = {};
    state.seasonTeams.forEach((t) => { nameById[t.teamId] = t.name; });
    const R = ps.results || {};
    const selRid = ps.selTeam != null ? ps.selTeam : myRid;
    const standOrder = state.seasonTeams.map((t) => t.teamId)
      .sort((a, b) => {
        const ra = R[a], rb = R[b];
        if (!ra || !rb) return 0;
        return (rb.w - ra.w) || (rb.pf - ra.pf);
      });
    const pct1 = (v) => v == null ? '—' : Math.round(v * 100) + '%';
    const standRows = Object.keys(R).length ? standOrder.map((rid) => {
      const r = R[rid];
      if (!r) return '';
      const fin = simExpFinish(rid);
      const sel = rid === selRid;
      return `<tr data-simteam="${rid}" style="cursor:pointer;${rid === myRid ? 'color:#b9e28c;' : ''}${sel ? 'background:#1c1e24;' : ''}border-bottom:1px solid #232529">
          <td style="padding:2px 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:95px">${sel ? '▸ ' : ''}${esc(nameById[rid] || rid)}</td>
          <td style="text-align:center;padding:2px 3px;white-space:nowrap">${r.w}-${r.l}</td>
          <td style="text-align:right;padding:2px 3px">${r.pf.toLocaleString()}</td>
          <td style="text-align:right;padding:2px 3px">${pct1(r.playoff)}</td>
          <td style="text-align:right;padding:2px 3px">${pct1(r.title)}</td>
          <td style="text-align:center;color:#8a8d96;padding:2px 3px;white-space:nowrap">${fin ? simOrdinal(fin.mode) : '—'}</td>
        </tr>`;
    }).join('') : '';
    const sel = R[selRid];
    let weeklyHtml = '';
    if (sel) {
      const wks = Object.keys(sel.weekly || {}).map(Number).sort((a, b) => a - b);
      const wkRows = wks.map((wk) => {
        const w = sel.weekly[wk];
        const wp = Math.round(w.winPct * 100);
        const col = wp >= 60 ? '#22c55e' : wp <= 40 ? '#d06d6d' : '#ffc166';
        return `<tr style="border-bottom:1px solid #232529">
            <td style="padding:2px 4px;color:#8a8d96">W${wk}</td>
            <td style="padding:2px 4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:105px">${esc(nameById[w.opp] || w.opp)}</td>
            <td style="text-align:right;padding:2px 4px;color:${col};font-weight:600">${wp}%</td>
            <td style="text-align:right;padding:2px 4px">${w.pf.toFixed(1)}</td>
            <td style="text-align:right;padding:2px 4px;color:#8a8d96">${w.pa.toFixed(1)}</td>
          </tr>`;
      }).join('');
      weeklyHtml = `
        <div style="font-size:10px;color:#8a8d96;text-transform:uppercase;letter-spacing:.5px;margin:10px 0 3px">Week by week · ${esc(nameById[selRid] || selRid)}</div>
        <div style="font-size:10px;color:#8a8d96;margin-bottom:3px">Playoffs ${pct1(sel.playoff)}${sel.bye ? ' · Bye ' + pct1(sel.bye) : ''} · Finals ${pct1(sel.finals)} · Title ${pct1(sel.title)}</div>
        ${wkRows ? `<table style="width:100%;border-collapse:collapse;font-size:11px">
          <thead><tr style="color:#8a8d96;font-size:9px;text-transform:uppercase">
            <th style="text-align:left;padding:2px 4px">Wk</th><th style="text-align:left;padding:2px 4px">Opp</th>
            <th style="text-align:right;padding:2px 4px">Win</th><th style="text-align:right;padding:2px 4px">Proj</th>
            <th style="text-align:right;padding:2px 4px">Opp proj</th>
          </tr></thead><tbody>${wkRows}</tbody></table>` : '<div style="font-size:11px;color:#8a8d96;padding:2px">No remaining regular-season weeks.</div>'}`;
    }
    const standingsHtml = standRows ? `
      <div style="font-size:10px;color:#8a8d96;text-transform:uppercase;letter-spacing:.5px;margin:2px 0 3px">Projected standings <span style="text-transform:none">(tap a team)</span></div>
      <table style="width:100%;border-collapse:collapse;font-size:11px">
        <thead><tr style="color:#8a8d96;font-size:9px;text-transform:uppercase">
          <th style="text-align:left;padding:2px 4px">Team</th><th style="padding:2px 3px">Rec</th>
          <th style="text-align:right;padding:2px 3px">PF</th><th style="text-align:right;padding:2px 3px">PO</th>
          <th style="text-align:right;padding:2px 3px">Title</th><th style="padding:2px 3px">Fin</th>
        </tr></thead><tbody>${standRows}</tbody></table>${weeklyHtml}` : '';
    const statTxt = ps.status === 'done' ? SIM_RUNS.toLocaleString() + ' sims · synth schedule' : '';
    return `${seasonHeaderHTML()}${note}${standingsHtml}
      <div style="display:flex;align-items:center;gap:6px;margin-top:8px">
        <button id="mff-sim-rerun" style="background:#2a2c33;border:none;color:#e9e9ec;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:10px;font-weight:600">RE-RUN SIM</button>
        <span style="font-size:9px;color:#8a8d96">${statTxt}</span>
      </div>
      <div style="font-size:9px;color:#8a8d96;margin-top:6px;line-height:1.35">Standings/odds = ${SIM_RUNS.toLocaleString()} Monte Carlo seasons (Clay projections × Vegas lines, scored to this league's settings). Yahoo doesn't expose real matchup pairings, so a synthetic round-robin schedule is used. Rosters read from each team page, refreshed daily; IR-slot players excluded; players without a Clay projection score 0.</div>`;
  }

  // ---------- UI ----------
  let root = null;
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }
  function buildPanel() {
    if (root) return;
    root = document.createElement('div');
    root.id = 'mff-sidebar';
    root.innerHTML = `
      <div id="mff-header">
        <span class="title">MFF YAHOO HELPER</span>
        <div class="controls">
          <button id="mff-collapse" title="Collapse">–</button>
          <button id="mff-close" title="Hide (reopen from the MFF chip)">✕</button>
        </div>
      </div>
      <div id="mff-body"></div>
      <div id="mff-resize-n" class="mff-resize-edge"></div>
      <div id="mff-resize-e" class="mff-resize-edge"></div>
      <div id="mff-resize-s" class="mff-resize-edge"></div>
      <div id="mff-resize"></div>`;
    document.body.appendChild(root);
    root.querySelector('#mff-collapse').addEventListener('click', () => {
      root.classList.toggle('collapsed');
    });
    root.querySelector('#mff-close').addEventListener('click', hidePanel);
    enableDrag();
    enableResize();
    root.querySelector('#mff-body').addEventListener('click', onBodyClick);
    root.querySelector('#mff-body').addEventListener('change', onBodyChange);
  }
  function destroyPanel() {
    if (root) { root.remove(); root = null; }
    const chip = document.getElementById('mff-reopen');
    if (chip) chip.remove();
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
    if (state.scrapeTimer) { clearInterval(state.scrapeTimer); state.scrapeTimer = null; }
  }
  function hidePanel() {
    if (!root) return;
    root.style.display = 'none';
    if (document.getElementById('mff-reopen')) return;
    const chip = document.createElement('div');
    chip.id = 'mff-reopen';
    chip.textContent = 'MFF';
    chip.title = 'Show MFF Yahoo Helper';
    chip.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:2147483647;' +
      'background:#7d2eff;color:#ffffff;font:700 11px -apple-system,BlinkMacSystemFont,sans-serif;' +
      'padding:8px 11px;border-radius:20px;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,0.5);user-select:none';
    chip.addEventListener('click', () => {
      chip.remove();
      if (root) root.style.display = 'flex';
    });
    document.body.appendChild(chip);
  }
  function enableDrag() {
    const header = root.querySelector('#mff-header');
    let sx, sy, ox, oy, dragging = false;
    header.addEventListener('mousedown', (e) => {
      if (e.target.closest('button')) return;
      dragging = true;
      sx = e.clientX; sy = e.clientY;
      const r = root.getBoundingClientRect();
      ox = r.left; oy = r.top;
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      root.style.left = ox + (e.clientX - sx) + 'px';
      root.style.top = Math.max(0, oy + (e.clientY - sy)) + 'px';
      root.style.right = 'auto';
    });
    window.addEventListener('mouseup', () => { dragging = false; });
  }
  function enableResize() {
    let sx, sy, sw, sh, st, mode = null;
    function arm(id, m) {
      const h = root.querySelector(id);
      if (!h) return;
      h.addEventListener('mousedown', (e) => {
        mode = m;
        sx = e.clientX; sy = e.clientY;
        const r = root.getBoundingClientRect();
        sw = r.width; sh = r.height; st = r.top;
        e.preventDefault();
      });
    }
    arm('#mff-resize', 'se');
    arm('#mff-resize-e', 'e');
    arm('#mff-resize-s', 's');
    arm('#mff-resize-n', 'n');
    window.addEventListener('mousemove', (e) => {
      if (!mode) return;
      root.style.maxHeight = 'none';
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (mode === 'se' || mode === 'e') root.style.width = Math.max(300, sw + dx) + 'px';
      if (mode === 'se' || mode === 's') root.style.height = Math.max(200, sh + dy) + 'px';
      if (mode === 'n') {
        const newTop = Math.max(0, st + dy);
        root.style.top = newTop + 'px';
        root.style.height = Math.max(200, sh + (st - newTop)) + 'px';
      }
    });
    window.addEventListener('mouseup', () => { mode = null; });
  }
  function render() {
    if (!root) return;
    if (!isDynMode() && state.seasonTeamSrc === 'ktc') state.seasonTeamSrc = 'jack';
    const body = root.querySelector('#mff-body');
    if (!body) return;
    if (!gateAllowed()) { body.innerHTML = gateLockHTML(); return; }
    const recsEl = body.querySelector('#mff-recs');
    const scrollTop = recsEl ? recsEl.scrollTop : 0;
    body.innerHTML = seasonHTML();
    const newRecs = body.querySelector('#mff-recs');
    if (newRecs) newRecs.scrollTop = scrollTop;
  }

  // Injury chip — clickable (detail popover) when the Sleeper dump has the
  // player; scraped-only hits (no sid) keep a plain chip.
  function injTagHTML(p) {
    const inj = injOf(p);
    if (!inj) return '';
    const cfg = inj === 'OUT' ? ['#402a2a', '#d06d6d', 'OUT']
      : inj === 'D' ? ['#453325', '#e0a060', 'DTD']
      : ['#4a3f30', '#ffc99b', 'Q'];
    const sid = (p.sid && state.slMeta[p.sid]) ? String(p.sid) : '';
    return `<span class="tag mff-inj-tag"${sid ? ` data-sid="${esc(sid)}" title="Click for injury detail"` : ''} style="background:${cfg[0]};color:${cfg[1]}${sid ? ';cursor:pointer' : ''}">${cfg[2]}</span>`;
  }
  // Injury detail popover: anchored to the clicked chip, appended to the host
  // page body (the sidebar re-renders its innerHTML too often to own it).
  function showInjPopover(sid, anchor) {
    let pop = document.getElementById('mff-inj-popover');
    if (!pop) {
      pop = document.createElement('div');
      pop.id = 'mff-inj-popover';
      document.body.appendChild(pop);
      document.addEventListener('click', (e) => {
        if (pop.style.display === 'block' && !pop.contains(e.target) && !e.target.closest('.mff-inj-tag')) pop.style.display = 'none';
      }, true);
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape') pop.style.display = 'none'; });
      window.addEventListener('scroll', () => { pop.style.display = 'none'; }, true);
    }
    if (pop.style.display === 'block' && pop._sid === sid) { pop.style.display = 'none'; return; }
    const m = state.slMeta[sid];
    if (!m) return;
    const rows = [];
    rows.push(['Status', m.is || (m.inj === 'OUT' ? 'Out' : m.inj === 'D' ? 'Doubtful' : 'Questionable')]);
    if (m.st) rows.push(['Roster', m.st]);
    rows.push(['Injury', m.ib || 'Undisclosed']);
    if (m.idt) rows.push(['Since', m.idt]);
    if (m.inx) rows.push(['Note', m.inx]);
    pop.innerHTML = '<div class="mip-name">' + esc(m.n || '') + '</div>'
      + '<div class="mip-grid">' + rows.map((r) => '<span class="mip-k">' + esc(r[0]) + '</span><span>' + esc(r[1]) + '</span>').join('') + '</div>'
      + '<div class="mip-foot">Sleeper injury feed</div>';
    pop._sid = sid;
    pop.style.display = 'block';
    const r = anchor.getBoundingClientRect();
    const pw = pop.offsetWidth;
    let left = r.left + window.scrollX - 10;
    left = Math.min(Math.max(8, left), window.scrollX + document.documentElement.clientWidth - pw - 8);
    pop.style.left = left + 'px';
    pop.style.top = (r.bottom + window.scrollY + 6) + 'px';
  }
  document.addEventListener('click', (e) => {
    const tag = e.target.closest && e.target.closest('.mff-inj-tag');
    if (!tag || !tag.getAttribute('data-sid')) return;
    e.stopPropagation();
    e.preventDefault();
    showInjPopover(tag.getAttribute('data-sid'), tag);
  }, true);
  function snBadges(p) {
    let out = '';
    if (onByeThisWeek(p)) {
      out += '<span class="tag" style="background:#3a3040;color:#c0a0d0">BYE</span>';
    }
    out += injTagHTML(p);
    return out;
  }
  function seasonHeaderHTML() {
    const modeLbl = MODES[state.mode] ? MODES[state.mode].label : '';
    const hasProps = !!(state.wkPropsAll && state.wkPropsAll[String(state.seasonWeek)]);
    return `
      <div id="mff-pick-line">
        <span class="pl-pick">${esc(state.teamName || ('League ' + (state.leagueId || '')))}</span>
        <span class="pl-sep">·</span><span class="pl-round">Wk ${state.seasonWeek}${state.byesActive ? '' : ' (pre)'}</span>
        <span class="pl-sep">·</span><span class="pl-mine">${esc(state.scoringLabel)}</span>
        <span class="pl-sep">·</span><span class="pl-mine">${esc(modeLbl)}</span>
        ${hasProps ? '<span class="pl-sep">·</span><span class="pl-mine" style="color:#6dd06d" title="Weekly values blend the site\'s Wk ' + state.seasonWeek + ' prop boards (UD+PP) with Clay projections + Jack\'s rank">W' + state.seasonWeek + ' props</span>' : ''}
      </div>`;
  }
  // Site consensus weekly numbers (Sleeper h/p/s, ESPN/FP [half,ppr,std]) in
  // the league's rec-scoring bucket. Only for the week the feed was pulled for.
  function wkConsensusRow(p) {
    const c = state.wkConsensus || (MOCK && MOCK.consensus) || null;
    if (!c || !c.players || c.week !== state.seasonWeek) return '';
    let row = c.players[p.n];
    if (!row) {
      if (!state.wkConsensusIdx) {
        const idx = Object.create(null);
        for (const n of Object.keys(c.players)) idx[norm(n)] = c.players[n];
        state.wkConsensusIdx = idx;
      }
      row = state.wkConsensusIdx[norm(p.n)];
    }
    if (!row) return '';
    const recPts = state.scoringVals ? state.scoringVals.recPts : 1;
    const fi = recPts >= 0.75 ? 1 : recPts >= 0.25 ? 0 : 2; // [half, ppr, std]
    const slp = fi === 1 ? row.p : fi === 0 ? row.h : row.s;
    const parts = [];
    if (typeof slp === 'number') parts.push('SLP ' + slp.toFixed(1));
    if (row.e && typeof row.e[fi] === 'number') parts.push('ESPN ' + row.e[fi].toFixed(1));
    if (row.f && typeof row.f[fi] === 'number') parts.push('FP ' + row.f[fi].toFixed(1));
    if (!parts.length) return '';
    return `<div class="prof-row"><span class="k" title="Site consensus weekly projections (Sleeper / ESPN / FantasyPros), ${fi === 1 ? 'PPR' : fi === 0 ? 'half-PPR' : 'standard'} — reference only, not the sim number">Wk ${c.week} sources</span><span class="v">${esc(parts.join(' · '))}</span></div>`;
  }

  // K/DST full-season weekly projection strip (mirrors the site card's strip):
  // all 18 weeks scored with the league-scored Vegas models above against each
  // week's line from the site schedule map. Colored by matchup delta vs the
  // neutral-implied baseline; W15-17 carry the playoff border. Pure model —
  // no injury/actuals decay (it's a planning strip, not a lineup verdict).
  function kdstWeekStripHTML(p) {
    if ((p.s !== 'K' && p.s !== 'DST') || !p.sTm) return '';
    const sched = state.schedule[p.sTm];
    if (!sched || !Object.keys(sched).length) return '';
    const base = p.s === 'K' ? kickerProjFor(p, null) : dstProjFor(p, null);
    if (base == null || !isFinite(base)) return '';
    let cells = '';
    for (let wk = 1; wk <= 18; wk++) {
      const g = sched[wk];
      const border = (wk >= 15 && wk <= 17)
        ? 'border:1px solid rgba(224,160,96,.55);' : 'border:1px solid #26304d;';
      if (!g) {
        const isBye = p.bye != null && +p.bye === wk;
        cells += `<div style="flex:0 0 44px;text-align:center;padding:3px 1px;border-radius:4px;background:#141a2e;${border}${isBye ? '' : 'opacity:.5;'}" title="${isBye ? 'Bye week' : 'W' + wk + ' — line not posted yet'}">` +
          `<div style="font-size:8px;color:#8b94b3">W${wk}</div>` +
          `<div style="font-size:10px;font-weight:700;color:#8b94b3;padding:3px 0 2px">${isBye ? 'BYE' : '—'}</div></div>`;
        continue;
      }
      const v = p.s === 'K' ? kickerProjFor(p, g) : dstProjFor(p, g);
      const delta = v - base;
      const clr = delta >= 0.4 ? '#6dd06d' : delta >= 0.15 ? '#9ed08f'
        : delta <= -0.4 ? '#d06d6d' : delta <= -0.15 ? '#e0a060' : '#cbd2e6';
      const oppTxt = (g.home ? 'vs' : '@') + g.opp;
      const imp = p.s === 'DST'
        ? (g.total != null && g.implied != null ? g.total - g.implied : null)
        : g.implied;
      const tip = 'W' + wk + ' ' + oppTxt +
        (imp != null ? ' · ' + (p.s === 'DST' ? 'opp implied ' : 'implied ') + (Math.round(imp * 10) / 10) : '') +
        (g.total != null ? ' · O/U ' + g.total : '') +
        ' · ' + (delta >= 0 ? '+' : '') + delta.toFixed(1) + ' vs ' + base.toFixed(1) + ' baseline (league scoring)';
      cells += `<div style="flex:0 0 44px;text-align:center;padding:3px 1px;border-radius:4px;background:#141a2e;cursor:help;${border}" title="${esc(tip)}">` +
        `<div style="font-size:8px;color:#8b94b3">W${wk}</div>` +
        `<div style="font-size:12px;font-weight:800;line-height:1.15;color:${clr}">${v.toFixed(1)}</div>` +
        `<div style="font-size:7.5px;color:#8b94b3;white-space:nowrap">${esc(oppTxt)}${imp != null ? '·' + Math.round(imp) : ''}</div></div>`;
    }
    return `<div class="prof-row" style="display:block">` +
      `<span class="k" style="display:block;margin-bottom:3px">WEEKLY PROJ <span style="color:#8b94b3;font-weight:400">· Vegas model, league scoring · amber = W15-17</span></span>` +
      `<div style="display:flex;gap:3px;overflow-x:auto;padding-bottom:3px">${cells}</div></div>`;
  }

  function profileHTML(p, k) {
    const mk = modeKeys();
    const modeLbl = MODES[state.mode].label;
    const sfMode = state.mode.endsWith('_sf');
    const rows = [
      ["Jack " + modeLbl, p[mk.jack] == null ? null
        : '#' + p[mk.jack] + (() => { const t = jackTierFor(p[mk.jack]); return t ? ' · ' + (t.n || 'Tier ' + t.l) : ''; })()],
      ["Jack Redraft", mk.jack !== 'rank' && p.rank != null ? '#' + p.rank : null],
      ['FP ' + modeLbl, p[mk.fp] == null ? null : '#' + p[mk.fp]],
      ['Sleeper ' + modeLbl, p[mk.sl] == null ? null : '#' + p[mk.sl]],
      ['ADP ' + modeLbl, p[mk.adp]],
      ['KTC Superflex', isDynMode() ? p.ktcSf : null],
      ['KTC 1QB', isDynMode() ? p.ktc1qb : null],
      ['Proj PPG (Clay, ' + state.scoringLabel + ')', p.pPg],
      ['Proj Season', p.szn],
      ['Ceiling PPG', p.cPpg],
      ['VOR' + (sfMode ? ' (SF)' : ''), p[mk.vor]],
      ['Upside' + (sfMode ? ' (SF)' : ''), p[mk.up]],
      ['Age', p.age], ["'25 PPG", p.p25],
      ['Team', p.sTm || p.t],
    ].filter((r) => r[1] != null)
      .map((r) => `<div class="prof-row"><span class="k">${r[0]}</span><span class="v">${esc(r[1])}</span></div>`)
      .join('');
    let sosRow = '';
    const sosData = window.MFF_PLAYOFF_SOS;
    const sos = sosData && p.sTm && sosData[p.sTm] && sosData[p.sTm][p.s];
    if (sos) {
      const pills = ['15', '16', '17'].map((w) => {
        const m = sos[w];
        if (!m) return '';
        return `<span style="background:${esc(m.color)};color:#0e0f12;border-radius:3px;padding:1px 5px;font-size:9px;font-weight:700" title="SOS rank ${m.rank}/32 · implied ${m.impliedTotal} pts">W${w} ${m.home ? 'vs' : '@'}${esc(m.opp)}</span>`;
      }).join('');
      sosRow = `<div class="prof-row"><span class="k">Playoff SOS</span><span class="v" style="display:flex;gap:3px;flex-wrap:wrap">${pills}</span></div>`;
    }
    return `<div class="mff-profile" style="pointer-events:auto">${rows}${wkConsensusRow(p)}${sosRow}${kdstWeekStripHTML(p)}</div>`;
  }
  function seasonLineupHTML() {
    if (!state.roster.length || !state.seasonSlots) {
      return seasonHeaderHTML() +
        '<div class="mff-proj-empty">Open YOUR team page (My Team) so the helper can read your roster.</div>';
    }
    const calc = seasonLineupCalc();
    const pool = calc.pool;
    const opt = calc.opt;
    const starterSet = calc.starterSet;
    const moves = calc.moves;
    const optKeys = new Set(opt.assign.filter((a) => a.e).map((a) => keyOf(a.e.p)));
    const rowCls = {};
    for (const k of Object.keys(calc.cls)) rowCls[k] = 'mff-row-' + calc.cls[k];
    const POS_COLORS = { QB: '#c084fc', RB: '#4ade80', WR: '#fb923c', TE: '#60a5fa', K: '#bd66ff', DEF: '#7988a1' };
    const rows = opt.assign.map((a) => {
      const slotLbl = a.slot === 'SUPER_FLEX' ? 'SFLX' : a.slot === 'WRRB_FLEX' ? 'W/R'
        : a.slot === 'REC_FLEX' ? 'W/T' : a.slot === 'FLEX' ? 'W/R/T' : a.slot === 'DEF' ? 'DEF' : a.slot;
      const col = POS_COLORS[a.slot] || '#8a8d96';
      if (!a.e) {
        return `<div class="mff-proj-roster-player"><span class="t" style="color:${col}">${esc(slotLbl)}</span>
          <span class="n" style="color:#d06d6d">— empty${SLOT_ELIG[a.slot] ? '' : ' (unsupported slot)'}</span><span class="v"></span></div>`;
      }
      const p = a.e.p;
      const k = keyOf(p);
      const cls = rowCls[k] || '';
      const starting = starterSet.has(k);
      const mark = starting ? '<span style="color:#5a5d66">✓</span>'
        : cls === 'mff-row-close'
          ? '<span style="color:#ffc166;font-weight:800" title="Toss-up — projections are very close">≈</span>'
          : '<span style="color:#6dd06d;font-weight:800" title="Currently on your bench — start him">▲</span>';
      return `<div class="mff-proj-roster-player mff-rec ${cls}" data-key="${esc(k)}" style="cursor:pointer">
        <span class="t" style="color:${col}">${esc(slotLbl)}</span>
        <span class="n">${mark} ${esc(p.n)} ${wkOppHTML(p)}${snBadges(p)}${liveTagHTML(p)}${p._unmatched ? ' <span style="color:#8a8d96;font-size:9px">(no proj)</span>' : ''}</span>
        <span class="v" title="Projected ppg this week (${esc(state.scoringLabel)})">${a.e.v ? a.e.v.toFixed(1) : '0'}</span>
        ${state.expandedKey === k && !p._unmatched ? profileHTML(p, k) : ''}
      </div>`;
    }).join('');
    let movesHtml = '';
    if (moves.length) {
      movesHtml = '<div class="mff-section"><h3>Start / Sit moves</h3>' + moves.map((mv) => {
        const isClose = mv.sit && mv.delta != null && Math.abs(mv.delta) < CLOSE_PPG;
        if (isClose) {
          return `<div style="font-size:11px;color:#ffc166;padding:2px 2px">≈ Toss-up: <b>${esc(mv.add.p.n)}</b> / <b>${esc(mv.sit.p.n)}</b> <span style="color:#8a8d96">(${mv.delta >= 0 ? '+' : ''}${mv.delta.toFixed(1)})</span></div>`;
        }
        const sitTxt = mv.sit ? ' over <b style="color:#d06d6d">' + esc(mv.sit.p.n) + '</b>' : '';
        const d = mv.delta != null && mv.delta > 0 ? ` <span class="tag STEAL">+${mv.delta.toFixed(1)}</span>` : '';
        return `<div style="font-size:11px;color:#c8ccd4;padding:2px 2px">▲ Start <b style="color:#6dd06d">${esc(mv.add.p.n)}</b>${sitTxt}${d}</div>`;
      }).join('') + '</div>';
    } else if (starterSet.size) {
      movesHtml = '<div class="mff-section"><h3>Start / Sit moves</h3>' +
        '<div style="font-size:11px;color:#6dd06d;padding:2px">✓ Your lineup is already optimal</div></div>';
    }
    const bench = pool.filter((p) => !optKeys.has(keyOf(p)))
      .map((p) => ({ p, v: wkVal(p) })).sort((a, b) => b.v - a.v);
    const benchRows = bench.map((b) => {
      const k = keyOf(b.p);
      const cls = rowCls[k] || '';
      const mark = cls === 'mff-row-sit'
        ? '<span style="color:#d06d6d;font-weight:800" title="Currently starting — bench him">▼</span> '
        : cls === 'mff-row-close'
          ? '<span style="color:#ffc166;font-weight:800" title="Toss-up — projections are very close">≈</span> '
          : '';
      return `
      <div class="mff-proj-roster-player mff-rec ${cls}" data-key="${esc(k)}" style="cursor:pointer">
        <span class="t">${esc(b.p.s)}</span>
        <span class="n">${mark}${esc(b.p.n)} ${wkOppHTML(b.p)}${snBadges(b.p)}${liveTagHTML(b.p)}</span>
        <span class="v" title="Projected ppg this week (${esc(state.scoringLabel)})">${b.v ? b.v.toFixed(1) : '0'}</span>
        ${state.expandedKey === k && !b.p._unmatched ? profileHTML(b.p, k) : ''}
      </div>`;
    }).join('');
    const stale = state.rosterTs && Date.now() - state.rosterTs > 24 * 3600 * 1000;
    return `
      ${seasonHeaderHTML()}
      ${stale ? '<div style="font-size:10px;color:#ffc99b;padding:2px">Roster last read ' + Math.round((Date.now() - state.rosterTs) / 3600000) + 'h ago — open your team page to refresh.</div>' : ''}
      ${movesHtml}
      <div class="mff-section"><h3>Optimal lineup <span style="color:#b388ff">${opt.total} ppg</span></h3>
        <div class="mff-proj-roster">${rows}</div></div>
      <div class="mff-section"><h3>Bench</h3>
        <div class="mff-proj-roster">${benchRows || '<div class="mff-proj-empty">No bench players</div>'}</div></div>`;
  }
  function seasonWaiversHTML() {
    if (!state.roster.length) {
      return seasonHeaderHTML() +
        '<div class="mff-proj-empty">Open YOUR team page first so waivers can rank vs YOUR lineup.</div>';
    }
    const posChips = ['ALL', 'QB', 'RB', 'WR', 'TE', 'K', 'DST'].map((p) =>
      `<button class="pos-filter ${state.seasonPosFilter === p ? 'active' : ''}" data-snpos="${p}">${p}</button>`
    ).join('');
    const faCount = Object.keys(state.faSeen).length;
    const drops = dropCandidates().slice(0, 3);
    const recs = waiverRecs();
    const cards = recs.map((r, i) => {
      const p = r.p;
      const k = keyOf(p);
      const expanded = state.expandedKey === 'wv|' + k;
      const upgrade = r.delta >= 0.5;
      const tags = [];
      if (upgrade) tags.push(`<span class="tag STEAL">LINEUP +${r.delta.toFixed(1)} ppg</span>`);
      else if (r.delta > 0) tags.push(`<span class="tag Value">+${r.delta.toFixed(1)} ppg</span>`);
      else tags.push('<span class="tag" style="background:#2a2c33;color:#8a8d96">DEPTH</span>');
      if (r.trend) tags.push(`<span class="tag" style="background:#453325;color:#e0a060">🔥 ${r.trend} adds</span>`);
      const dropLine = expanded && drops.length
        ? `<div class="mff-profile" style="pointer-events:auto;margin-top:2px"><div class="prof-row"><span class="k">SUGGESTED DROP</span><span class="v">${esc(drops[0].p.n)} (${esc(drops[0].p.s)})</span></div></div>`
        : '';
      return `
      <div class="mff-rec ${upgrade ? 'need' : ''}" data-key="wv|${esc(k)}">
        <div class="num">${i + 1}</div>
        <div class="info">
          <div class="name">${esc(p.n)}</div>
          <div class="meta">
            <span class="pos ${p.s}">${p.s}</span>
            <span>${esc(p.sTm || p.t || '')}</span>
            ${p.pPg != null ? `<span>${p.pPg}ppg</span>` : ''}
            ${wkOppHTML(p)}
            ${snBadges(p)}
          </div>
          <div class="why">${tags.join('')}</div>
        </div>
        <div class="score" style="color:${upgrade ? '#6dd06d' : '#8a8d96'}">${r.delta > 0 ? '+' + r.delta.toFixed(1) : '·'}</div>
        ${expanded ? profileHTML(p, k) + dropLine : ''}
      </div>`;
    }).join('');
    const dropWatch = drops.length
      ? `<div class="mff-section"><h3>Drop watch</h3>${drops.map((d) =>
          `<div style="font-size:11px;color:#c8ccd4;padding:1px 2px">${esc(d.p.n)} <span style="color:#8a8d96">(${esc(d.p.s)} · ${d.marginal > 0 ? 'costs ' + d.marginal.toFixed(1) + ' ppg' : 'not in lineup'})</span></div>`
        ).join('')}</div>`
      : '';
    return `
      ${seasonHeaderHTML()}
      <div class="mff-section"><h3>Waiver targets <span style="color:#8a8d96;font-weight:400;font-size:9px">vs your lineup</span></h3>
        <div style="font-size:10px;color:#8a8d96;margin-bottom:3px">${faCount} free agents captured — browse your league's <b>Players</b> page (Available filter) to add more; rows you see are captured automatically.</div>
        <div id="mff-pos-toggle" style="display:flex;gap:3px;margin-bottom:4px">${posChips}</div>
        <div id="mff-recs">${cards || '<div class="mff-proj-empty">No free agents captured yet — open the league Players page.</div>'}</div>
      </div>
      ${dropWatch}`;
  }
  const POS_ORDER = ['QB', 'RB', 'WR', 'TE', 'K', 'DST'];
  function seasonTeamHTML() {
    if (!state.roster.length) {
      return seasonHeaderHTML() +
        '<div style="font-size:11px;color:#8a8d96;padding:8px 2px">Open YOUR team page first.</div>';
    }
    const srcId = (SOURCES[state.seasonTeamSrc] && (state.seasonTeamSrc !== 'ktc' || isDynMode()))
      ? state.seasonTeamSrc : (isDynMode() ? 'ktc' : 'jack');
    const src = SOURCES[srcId];
    const chips = Object.entries(SOURCES)
      .filter(([id]) => id !== 'ktc' || isDynMode()) // KTC = dynasty-only
      .filter(([id]) => id !== 'mine' || myRanksAvailable())
      .map(([id, s]) =>
      `<button class="pos-filter ${id === srcId ? 'active' : ''}" data-pksrc="${id}" style="flex:0 0 auto">${
        id === 'ktc' ? 'KTC' : id === 'jack' ? "JACK'S" : id === 'fp' ? 'FP' : id === 'mine' ? 'MINE' : 'SLPR'}</button>`).join('');
    const mine = myPlayerObjs();
    const val = (p) => p._unmatched ? null : src.get(p);
    const groups = POS_ORDER.map((pos) => {
      const list = mine.filter((p) => p.s === pos).sort((a, b) => {
        const va = val(a), vb = val(b);
        if (va == null && vb == null) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return src.desc ? vb - va : va - vb;
      });
      if (!list.length) return '';
      const sub = srcId === 'ktc'
        ? list.reduce((t, p) => t + (val(p) || 0), 0) : null;
      const rows = list.map((p) => {
        const v = val(p);
        const inj = injOf(p);
        const t = srcId === 'jack' ? jackTierFor(p[modeKeys().jack]) : null;
        const tierB = t ? ` <b class="mff-jtier" style="color:${jackTierColor(t.l)}" title="Jack's tier: ${esc(t.n || t.l)}">${esc(t.l)}</b>` : '';
        return `<div style="display:flex;justify-content:space-between;align-items:baseline;padding:2px 2px;border-bottom:1px solid #232529;font-size:12px">
            <span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px">${esc(p.n)}
              <span style="color:#8a8d96;font-size:10px">${esc(p.sTm || '')}${p.age ? ' · ' + p.age : ''}${inj ? ' · <span style="color:#d06d6d">' + inj + '</span>' : ''}</span></span>
            <span style="font-weight:600;color:${v == null ? '#8a8d96' : '#e9e9ec'}">${
              v == null ? '—' : src.desc ? v.toLocaleString() : '#' + v}${tierB}</span>
          </div>`;
      }).join('');
      return `<div style="display:flex;justify-content:space-between;font-size:10px;color:#8a8d96;text-transform:uppercase;letter-spacing:.5px;margin:8px 0 2px">
          <span class="pos pos-${pos.toLowerCase()}" style="padding:0 5px;border-radius:3px">${pos}</span>
          ${sub != null ? '<span>' + sub.toLocaleString() + '</span>' : ''}</div>${rows}`;
    }).join('');
    const total = srcId === 'ktc' ? mine.reduce((t, p) => t + (val(p) || 0), 0) : null;
    return `
      ${seasonHeaderHTML()}
      <div style="display:flex;gap:3px;flex-wrap:wrap;margin-bottom:4px">${chips}</div>
      ${total != null ? `<div style="display:flex;justify-content:space-between;font-size:12px;padding:2px;border-bottom:1px solid #2a2c33"><b>Team total (${esc(src.label)} ${state.mode.endsWith('_sf') ? 'SF' : '1QB'})</b><b style="color:#b388ff">${total.toLocaleString()}</b></div>` : ''}
      ${groups}
      <div style="font-size:9px;color:#8a8d96;margin-top:6px">${esc(src.label)} in the selected format (${state.mode.replace('_', ' ').toUpperCase()}). Players outside the export show —.</div>`;
  }
  function seasonSettingsHTML() {
    let ver = '';
    try { ver = chrome.runtime.getManifest().version; } catch (e) {}
    const recChips = [[1, 'PPR'], [0.5, '½PPR'], [0, 'STD']].map(([v, lbl]) =>
      `<button class="pos-filter ${state.scoringPrefs.rec === v ? 'active' : ''}" data-snrec="${v}" style="flex:0 0 auto">${lbl}</button>`).join('');
    const tdChips = [[4, '4pt paTD'], [6, '6pt paTD']].map(([v, lbl]) =>
      `<button class="pos-filter ${state.scoringPrefs.passTd === v ? 'active' : ''}" data-snptd="${v}" style="flex:0 0 auto">${lbl}</button>`).join('');
    const modeOpts = Object.entries(MODES).map(([k, m]) =>
      `<option value="${k}" ${state.mode === k ? 'selected' : ''}>${m.label}${state.modeDetected === k ? ' ✓' : ''}</option>`).join('');
    return `
      ${seasonHeaderHTML()}
      <div class="mff-section"><h3>Scoring <span style="color:#8a8d96;font-weight:400;font-size:9px">${state.scoringManual ? '(manual override)' : state.apiScoring ? '(✓ read from your league settings)' : '(league settings unavailable — set yours)'}</span></h3>
        <div style="display:flex;gap:3px;margin-bottom:3px">${recChips}</div>
        <div style="display:flex;gap:3px">${tdChips}</div></div>
      <div class="mff-section"><h3>Format</h3>
        <select class="mff-select" id="mff-mode">${modeOpts}</select>
        <div style="font-size:9px;color:#8a8d96;margin-top:2px">SF auto-detects from your lineup slots; dynasty can't be scraped — pick it here.</div></div>
      <div class="mff-section"><h3>Roster</h3>
        <div style="font-size:11px;color:#c8ccd4">${state.roster.length ? state.roster.length + ' players · read ' + (state.rosterTs ? Math.round((Date.now() - state.rosterTs) / 60000) + ' min ago' : '—') : 'not read yet — open your team page'}</div>
        <div style="font-size:11px;color:#c8ccd4">${Object.keys(state.faSeen).length} free agents captured from the Players page</div>
        <button data-clearfa="1" class="pos-filter" style="margin-top:3px">CLEAR FA CACHE</button></div>
      <div class="mff-section"><h3>API probe</h3>
        <div style="font-size:10px;color:#8a8d96">${state.probeCount} internal endpoints recorded this session (upgrade path off DOM scraping).</div>
        <button data-copyprobe="1" class="pos-filter" style="margin-top:3px">COPY PROBE LOG</button></div>
      <div style="font-size:10px;color:#8a8d96">Players: ${state.players.length} · data ${esc(state.exportedAt)}${ver ? ' · v' + ver : ''}</div>`;
  }
  function seasonHTML() {
    const tabs = [['lineup', 'LINEUP'], ['team', 'TEAM'], ['waivers', 'WAIVERS']]
      .concat(simAvailable() ? [['sims', 'SIMS']] : [])
      .concat([['snset', 'SETTINGS']])
      .map(([id, lbl]) =>
        `<button class="mff-tab ${state.seasonTab === id ? 'active' : ''}" data-sntab="${id}">${lbl}</button>`).join('');
    const content = state.seasonTab === 'waivers' ? seasonWaiversHTML()
      : state.seasonTab === 'team' ? seasonTeamHTML()
      : state.seasonTab === 'sims' && simAvailable() ? seasonSimsHTML()
      : state.seasonTab === 'snset' ? seasonSettingsHTML()
      : seasonLineupHTML();
    return `
      <div id="mff-tabs">${tabs}</div>
      ${content}
      <div id="mff-mode-line" style="display:flex;gap:6px;font-size:10px;color:#8a8d96;align-items:center">
        <span class="badge live" style="background:#2a4030;color:#6dd06d;padding:2px 6px;border-radius:3px;letter-spacing:0.5px;text-transform:uppercase;font-weight:600">SEASON</span>
        <span id="mff-status-line" style="flex:1">${esc(state.seasonStatus)}</span>
      </div>`;
  }

  // ---------- events ----------
  function onBodyClick(e) {
    const snTab = e.target.closest('[data-sntab]');
    if (snTab) {
      state.seasonTab = snTab.dataset.sntab;
      saveLeagueState();
      render();
      if (state.seasonTab === 'sims' && simAvailable()) setTimeout(ensureSeasonSim, 0);
      return;
    }
    const simTeam = e.target.closest('[data-simteam]');
    if (simTeam) {
      state.seasonSim.selTeam = parseInt(simTeam.dataset.simteam, 10);
      render();
      return;
    }
    if (e.target.closest('#mff-sim-rerun')) {
      const lid = state.leagueId;
      store.set({ ['yahooSim_' + lid]: null, ['yahooRosters_' + lid]: null });
      state.seasonSim.status = 'idle';
      state.seasonSim.recHash = null;
      state.seasonTeams = [];
      fetchLeagueRosters(true);
      return;
    }
    const snPos = e.target.closest('[data-snpos]');
    if (snPos) {
      state.seasonPosFilter = snPos.dataset.snpos;
      saveLeagueState();
      render();
      return;
    }
    const pkSrc = e.target.closest('[data-pksrc]');
    if (pkSrc) {
      state.seasonTeamSrc = pkSrc.dataset.pksrc;
      saveLeagueState();
      render();
      return;
    }
    const rec = e.target.closest('[data-snrec]');
    if (rec) {
      state.scoringPrefs.rec = parseFloat(rec.dataset.snrec);
      state.scoringManual = true;
      applyScoringPrefs();
      saveLeagueState();
      render();
      return;
    }
    const ptd = e.target.closest('[data-snptd]');
    if (ptd) {
      state.scoringPrefs.passTd = parseInt(ptd.dataset.snptd, 10);
      state.scoringManual = true;
      applyScoringPrefs();
      saveLeagueState();
      render();
      return;
    }
    if (e.target.closest('[data-clearfa]')) {
      state.faSeen = {};
      saveLeagueState();
      render();
      return;
    }
    if (e.target.closest('[data-copyprobe]')) {
      store.get(['mff_yahoo_probe']).then((saved) => {
        const log = saved.mff_yahoo_probe || { urls: [] };
        try {
          navigator.clipboard.writeText(JSON.stringify(log, null, 2));
          state.seasonStatus = 'Probe log copied (' + (log.urls || []).length + ' endpoints)';
        } catch (err) {
          console.log('[MFF/yahoo] probe log:', log);
          state.seasonStatus = 'Clipboard blocked — probe log dumped to console';
        }
        render();
      });
      return;
    }
    const rowEl = e.target.closest('.mff-rec[data-key]');
    if (rowEl) {
      const k = rowEl.dataset.key;
      state.expandedKey = state.expandedKey === k ? null : k;
      render();
    }
  }
  function onBodyChange(e) {
    if (e.target.id === 'mff-mode') {
      applyMode(e.target.value, true);
      saveLeagueState();
      render();
    }
  }

  // ---------- on-page decoration ----------
  // Yahoo's own rows get inline pills next to the player name: verdict
  // (▲ START / ▼ SIT / ≈ TOSS-UP) for YOUR roster, the colored Vegas matchup
  // pill, this week's projected ppg — and on the league Players page, the
  // "LINEUP +x.x" upgrade delta each free agent would add to your optimal
  // lineup. Runs on the same 2.5s scrape tick, signature-cached per row.
  // On-page pills only (the sidebar keeps its own dark .tag styling) — Yahoo is
  // a light theme, so these are light chips with a hairline border, mirroring
  // ESPN 0.20.22 (v0.9.16).
  function pillHTML(text, bg, fg, title) {
    return `<span ${title ? 'title="' + esc(title) + '"' : ''} style="background:${bg};color:${fg};` +
      'font-size:10px;font-weight:700;border-radius:3px;padding:0 4px;line-height:15px;' +
      'border:1px solid rgba(0,0,0,.08);white-space:nowrap;flex:0 0 auto">' + esc(text) + '</span>';
  }
  // Yahoo already prints the opponent in every player cell — the
  // `.ysf-game-status` line ("Sun 4:25 pm @ Phi" / "… vs Bal") right under
  // "Was - QB" — so instead of a duplicate @/vs pill we tint that native
  // text (green = plus Vegas matchup, red = tough, mid = tooltip only) and
  // hang the O/U + implied tooltip on it. Tinted whole, never split (Yahoo
  // live-updates it to the score/clock during games). Mirrors ESPN 0.20.30 /
  // Sleeper's tintGameLine. Returns the tinted element, null when the cell
  // has no game line (then the caller keeps the pill).
  const OPP_TINT = { good: ['#e2f3e6', '#1d7a34'], bad: ['#fbe7e7', '#b33636'] };
  function tintYahooGameLine(box, g) {
    const cell = box.closest('td') || box.parentElement;
    const gs = cell && cell.querySelector('.ysf-game-status');
    if (!gs) return null;
    let tgt = null;
    for (const cand of gs.querySelectorAll('a,span')) {
      if (cand.childElementCount) continue;
      const t = (cand.textContent || '').trim();
      if (t && t.length <= 40 && /(^|\s)(vs|@)\s?[A-Za-z]{2,4}\b/.test(t)) { tgt = cand; break; }
    }
    if (!tgt) return null;
    const sig = g.cls + '|' + g.tip;
    if (tgt.dataset.mffOppSig !== sig) {
      tgt.dataset.mffOppSig = sig;
      tgt.classList.add('mff-opp-hl');
      tgt.title = g.tip;
      // colored bold TEXT only — no background bar (Jack, 2026-09-09)
      const c = OPP_TINT[g.cls];
      tgt.style.setProperty('color', c ? c[1] : '', c ? 'important' : '');
      tgt.style.fontWeight = c ? '700' : '';
    }
    return tgt;
  }
  // Weekly odds pill — the site's exported boom/bust for this week's sim row.
  function simOddsPillHTML(sr) {
    const tip = 'From the site sim: ' + sr[3] + '% boom (≥1.5× his median game) · ' +
      sr[4] + '% bust (≤0.5× his median game)';
    return `<span title="${esc(tip)}" style="background:#f0f2f5;font-size:10px;font-weight:700;` +
      'border-radius:3px;padding:0 4px;line-height:15px;border:1px solid rgba(0,0,0,.08);' +
      'white-space:nowrap;flex:0 0 auto">' +
      `<span style="color:#1d7a34">▲${sr[3]}</span>&nbsp;<span style="color:#b33636">▼${sr[4]}</span></span>`;
  }
  // ---- MFF matchup strip (Yahoo matchup page): our proj totals + win odds ----
  // The matchup page renders BOTH teams' slot-labeled starter rows (mirrored
  // one-row-per-slot on desktop, a column per team otherwise). Scrape both
  // sides, score them with the same wkVal the row pills use, and pin a strip
  // with our totals + win odds above the first roster table — right under
  // Yahoo's own projected-points header. Win odds = normal approximation
  // (each starter sd = proj × position sigma; correlations ignored).
  const POS_SIG_DEFAULT = { QB: 0.42, RB: 0.52, WR: 0.58, TE: 0.65, K: 0.55, DST: 0.6 };
  // ---------- LIVE projections (v0.9.23, Sleeper 0.29.24 / ESPN 0.20.31 port) ----------
  // Once a player's game kicks off his number becomes what he has scored +
  // what he should still score: actual = Yahoo's own Fan Pts cell (scraped
  // off the page every tick, league-scored) + remaining = pregame proj ×
  // (1 − f), f = fraction of the game played from the ESPN public scoreboard
  // (period + clock; halftime 0.5; OT ≈ 0.97; final 1). A pace term
  // (w = 0.25·f) nudges the remainder toward the player's own rate late.
  // Pregame = wkVal; final = actual. START/SIT verdicts stay on the pregame
  // projection. No new host permission: the scoreboard sends CORS *.
  const SCOREBOARD_URL = 'https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard';
  const ESPN_TEAM_FIX = { WSH: 'WAS', JAC: 'JAX', LA: 'LAR', OAK: 'LV', SD: 'LAC' };
  // WEEK PIN (0.9.36, Jack 09-15: "showing week 1 scores for week 2"). Without
  // a week the scoreboard returns ESPN's OWN current week, which stays on the
  // finished week through Tuesday/Wednesday — every game came back FINAL and
  // last week's totals rendered as this week's "final". Ask for the fantasy
  // week explicitly and refuse a reply that reports any other week.
  function scoreboardQuery() {
    const season = (state.nflState && state.nflState.season) || '';
    return '?seasontype=2&week=' + state.seasonWeek + (season ? '&dates=' + season : '');
  }
  function parseScoreboard(sb, wantWeek) {
    const out = {};
    const sbWk = sb && sb.week && +sb.week.number;
    if (wantWeek && sbWk && sbWk !== wantWeek) {
      console.warn('[MFF] scoreboard returned week ' + sbWk + ' (wanted ' + wantWeek + ') — ignored, games treated as not started');
      return out;
    }
    for (const ev of (sb && sb.events) || []) {
      const c = ev.competitions && ev.competitions[0];
      if (!c) continue;
      const st = (c.status && c.status.type) || {};
      const nm = String(st.name || '');
      const s = st.state === 'in' ? 'in' : (st.state === 'post' || st.completed) ? 'post' : 'pre';
      const period = +(c.status && c.status.period) || 0;
      const clock = String((c.status && c.status.displayClock) || '0:00');
      const half = /HALFTIME/i.test(nm);
      let f = 0;
      if (s === 'post') f = 1;
      else if (s === 'in') {
        if (half) f = 0.5;
        else if (period >= 5) f = 0.97;
        else {
          const mm = clock.match(/^(\d+):(\d+)/);
          const left = mm ? (+mm[1] * 60 + +mm[2]) : 0;
          f = Math.min(0.99, Math.max(0.01, ((Math.max(1, period) - 1) * 900 + (900 - left)) / 3600));
        }
      }
      const comps = c.competitors || [];
      const home = comps.find((x) => x.homeAway === 'home'), away = comps.find((x) => x.homeAway === 'away');
      const abbr = (x) => { const a = String((x && x.team && x.team.abbreviation) || '').toUpperCase(); return ESPN_TEAM_FIX[a] || a; };
      const sc = (x) => (x && x.score != null && x.score !== '') ? +x.score : null;
      const h = abbr(home), a = abbr(away);
      const tag = s === 'in' ? (half ? 'HALF' : period >= 5 ? 'OT ' + clock : 'Q' + period + ' ' + clock) : s === 'post' ? 'FINAL' : '';
      if (h) out[h] = { st: s, f, tag, opp: a, home: true, pts: sc(home), oppPts: sc(away), kick: ev.date || null };
      if (a) out[a] = { st: s, f, tag, opp: h, home: false, pts: sc(away), oppPts: sc(home), kick: ev.date || null };
    }
    return out;
  }
  async function refreshScoreboard(force) {
    if (MOCK) {
      if (MOCK.scoreboard) { state.liveGames = parseScoreboard(MOCK.scoreboard); liveFeedBaseline(); state.liveAt = Date.now(); }
      return;
    }
    if (!state.byesActive) return; // preseason — nothing can be live
    const now = Date.now();
    if (!force && now < state.liveNextAt) return;
    state.liveNextAt = now + 60 * 1000;
    try {
      const sb = await fetchJson(SCOREBOARD_URL + scoreboardQuery() + '&t=' + now); // CORS * (direct), bg proxy fallback
      state.liveGames = parseScoreboard(sb, state.seasonWeek); liveFeedBaseline();
      state.liveAt = now;
      // Idle throttle: nothing in progress and no kickoff inside 20 min →
      // one scoreboard call every 10 min instead of every poll.
      const vals = Object.values(state.liveGames);
      const anyIn = vals.some((g) => g.st === 'in');
      const soon = vals.some((g) => g.st === 'pre' && g.kick && (Date.parse(g.kick) - now) < 20 * 60 * 1000);
      if (!anyIn && !soon) state.liveNextAt = now + 10 * 60 * 1000;
    } catch (e) { /* keep the last parse; pregame numbers still show */ }
  }
  function liveGameFor(p) {
    const raw = p && (p.sTm || p.t);
    const tm = raw ? (ESPN_TEAM_FIX[raw] || raw) : null;
    const g = tm ? state.liveGames[tm] : null;
    return g && g.st !== 'pre' ? g : null;
  }
  // {live, actual, rem, f, st, tag, proj}; live === wkVal(p) before kickoff.
  // `key` = scraped-row key (defaults to keyOf(p)).
  // Sim Lab live model (sim_proj_2026.json `liveModel`, fitted on 2019-25
  // play-by-play by sim_lab/backtest_live_remaining.py): remaining =
  // a·proj·(1−f) + b·pace·(1−f) + m·proj·(1−f)·(margin/10), coefficients per
  // position class (QB / RB / REC = WR+TE) interpolated over the game
  // fraction. Captures the second-half discount (players score less after
  // halftime than a uniform split says), the late-game pace weight and the
  // trailing-team passing boost. K/DST (unmodeled) and a not-yet-loaded
  // export fall back to the v1 heuristic (w = 0.25·f).
  function liveModelCoefs(p, f) {
    const lm = state.simProj && state.simProj.liveModel;
    if (!lm || !lm.pos || !lm.grid || !lm.grid.length) return null;
    // K and DST rows (live model v2, sim_lab/backtest_live_kdst.py) carry a 4th
    // coefficient on the score that matters to them (own team pts for K, points
    // allowed for DST); an export without them falls back to v1 as before.
    const cls = p.s === 'QB' ? 'QB' : p.s === 'RB' ? 'RB' : (p.s === 'WR' || p.s === 'TE') ? 'REC' : (p.s === 'K' || p.s === 'DST') ? p.s : null;
    const rows = cls && lm.pos[cls];
    if (!rows || rows.length !== lm.grid.length) return null;
    const g = lm.grid;
    if (f <= g[0]) return rows[0];
    if (f >= g[g.length - 1]) return rows[rows.length - 1];
    let i = 0;
    while (i < g.length - 2 && g[i + 1] < f) i++;
    const t = (f - g[i]) / (g[i + 1] - g[i]);
    return rows[i].map((v, k) => v + (rows[i + 1][k] - v) * t);
  }
  // ---- PLAYER-EXITED rule (0.9.26) ----
  // A player whose league-scored total has not moved for a long stretch of
  // GAME CLOCK has very likely left the game (2026 W1: Darnold exited after 2
  // attempts at 0.5 pts and this layer kept projecting ~8 more at halftime).
  // state.liveSeen[key] = {pts, f0}: the total and the game fraction at which
  // it last changed (0 when watched from kickoff, else first sight). stale =
  // f − f0 scales `rem` by a per-position ramp [start, full, floor]: a playing
  // QB moves the total every drive (short ramp, floor 0); RB/WR/TE have normal
  // quiet stretches (slower ramp, floor 0.15); K/DST exempt. QB accelerator:
  // another QB on the same team with ≥ 2 live pts while this one is stale
  // ≥ 0.10 → 0 (the backup has the job). Same math as sim_lab/live_tracker.py
  // (`live_fitx`): W1 NE@SEA replay MAE 3.17 → 2.85, Darnold 7.55 → 2.52.
  // CALIBRATED on nflverse pbp 2019-25 (sim_lab/backtest_exit_rule.py, empirical
  // multiplier = actual remaining / fitted remaining by stale bucket, RMSE-fit so
  // the live number stays a MEAN): QB [start 0.15, full 0.35, floor 0.40] on any
  // total; RB [0.20, 0.80, 0.10] only once he has scored (a zero-total RB is a
  // quiet committee back, not an exit); WR/TE NO ramp (their multiplier is ~1.0
  // at every stale bucket — the hand-set ramp lost on holdout). Teammate-QB
  // trigger keeps x0.30 (it is right ~68% of the time; 0 would over-cut).
  const LIVE_EXIT_RAMP = { QB: [0.15, 0.35, 0.40], RB: [0.20, 0.80, 0.10] };
  const LIVE_EXIT_GATED = { RB: true };       // ramp only after the player has scored
  const LIVE_EXIT_TEAMMATE_MULT = 0.30;
  function liveTeamOf(p) { const raw = p && (p.sTm || p.t); return raw ? (ESPN_TEAM_FIX[raw] || raw) : null; }
  function livePreSeed(p, k) {
    const tm = liveTeamOf(p);
    const g = tm ? state.liveGames[tm] : null;
    if (k != null && g && g.st === 'pre') state.liveSeen[k] = { pts: 0, f0: 0 };
  }
  function liveSeenNote(k, actual, f) {
    const s = state.liveSeen[k];
    if (!s) {
      const n = { pts: actual, f0: f <= 0.02 ? 0 : f };
      if (actual > 0) { if (f <= 0.02) n.fIn = 0; else n.fInUnknown = true; }  // already producing at first sight: entry unknown
      state.liveSeen[k] = n; return 0;
    }
    if (s.pts !== actual) {
      if (actual > 0 && s.fIn == null && !s.fInUnknown) s.fIn = f;  // first points: entry fraction (backup rule)
      s.pts = actual; s.f0 = f; return 0;
    }
    return Math.max(0, f - s.f0);
  }
  // Another QB on the same team already producing (scraped off this page, so
  // state.liveMeta knows his team/pos): the starter is out.
  function liveTeammateQB(k, tm) {
    if (!tm) return false;
    for (const o of Object.keys(state.livePts)) {
      if (o === k || !(state.livePts[o] >= 2)) continue;
      const m = state.liveMeta[o];
      if (m && m.pos === 'QB' && (ESPN_TEAM_FIX[m.tm] || m.tm) === tm) return true;
    }
    return false;
  }
  // ---- FEED-FROZEN guard (0.9.28) ----
  // The exit rule assumes live totals keep flowing. If NO total anywhere in
  // the league has changed for LIVE_FEED_FROZEN of game clock in this player's
  // game (API stall, dead scrape), the rule is PAUSED rather than fading whole
  // rosters. state.liveFeedF = every in-progress game's f at the last observed
  // change (liveFeedMark, called by the harvesters); liveFeedBaseline seeds a
  // game that kicks off after the last change so a feed dead from kickoff
  // still trips the guard.
  const LIVE_FEED_FROZEN = 0.10;
  function liveFeedMark() {
    const m = {};
    for (const t of Object.keys(state.liveGames)) { const g = state.liveGames[t]; if (g && g.st === 'in') m[t] = g.f; }
    state.liveFeedF = m;
  }
  function liveFeedBaseline() {
    if (!state.liveFeedF) return;
    for (const t of Object.keys(state.liveGames)) { const g = state.liveGames[t]; if (g && g.st === 'in' && state.liveFeedF[t] == null) state.liveFeedF[t] = g.f; }
  }
  function liveFeedFrozen(p) {
    const m = state.liveFeedF, tm = liveTeamOf(p);
    const g = tm ? state.liveGames[tm] : null;
    if (!m || !g || g.st !== 'in') return false;
    const at = m[tm] != null ? m[tm] : (g.opp && m[g.opp] != null ? m[g.opp] : null);
    return at != null && g.f - at >= LIVE_FEED_FROZEN;
  }
  function liveExitMult(p, k, actual, f) {
    const ramp = p && LIVE_EXIT_RAMP[p.s];
    if (!ramp || k == null) return { mult: 1, stale: 0 };
    const stale = liveSeenNote(k, actual, f);
    if (stale > ramp[0] && liveFeedFrozen(p)) return { mult: 1, stale, frozen: true };
    let mult = 1;
    if (!(LIVE_EXIT_GATED[p.s] && actual === 0) && stale > ramp[0]) {
      const t = Math.min(1, (stale - ramp[0]) / (ramp[1] - ramp[0]));
      mult = 1 - (1 - ramp[2]) * t;
    }
    if (p.s === 'QB' && stale >= 0.10 && liveTeammateQB(k, liveTeamOf(p))) mult = Math.min(mult, LIVE_EXIT_TEAMMATE_MULT);
    return { mult: Math.round(mult * 1000) / 1000, stale };
  }
  // ---- BACKUP-QB inheritance (0.9.27; Jack 09-10: "track the backup QB when
  // the starter goes out") ----
  // A QB projected under LIVE_BACKUP_RATIO of his team's top QB who has
  // >= 2 live points is in for the starter (W1 2026: Lock for Darnold): his
  // remaining inherits LIVE_BACKUP_SHARE of the starter's projection, paced
  // from the fraction his points started (liveSeen.fIn), and the tooltip says
  // "in for <starter>". Without it a backup shows actual + ~0. Same math as
  // sim_lab/live_tracker.py role=backup rows. The starter himself is zeroed
  // by the teammate rule above.
  // Share calibrated 2019-25: backups score 0.95 of the starter's per-game
  // expectation after an injury-like exit but 0.59 after a blowout pull
  // (|margin| >= 17), so the share follows the scoreboard margin.
  const LIVE_BACKUP_SHARE = 0.90, LIVE_BACKUP_SHARE_BLOWOUT = 0.60, LIVE_BLOWOUT_MARGIN = 17, LIVE_BACKUP_RATIO = 0.4;
  function liveBackupShare(p) {
    const tm = liveTeamOf(p), g = tm ? state.liveGames[tm] : null;
    const margin = g && typeof g.pts === 'number' && typeof g.oppPts === 'number' ? Math.abs(g.pts - g.oppPts) : 0;
    return margin >= LIVE_BLOWOUT_MARGIN ? LIVE_BACKUP_SHARE_BLOWOUT : LIVE_BACKUP_SHARE;
  }
  function liveTeamTopQB(p) {
    const tm = liveTeamOf(p);
    if (!tm) return null;
    let best = null;
    for (const q of state.players) {
      if (q === p || q.s !== 'QB' || liveTeamOf(q) !== tm) continue;
      const v = wkVal(q);
      if (!best || v > best.proj) best = { p: q, proj: v };
    }
    return best;
  }
  function liveBackupInherit(p, k, actual, f, proj) {
    if (!p || p.s !== 'QB' || k == null || !(actual >= 2)) return null;
    const top = liveTeamTopQB(p);
    if (!top || !(top.proj > 0) || proj >= top.proj * LIVE_BACKUP_RATIO) return null;
    liveSeenNote(k, actual, f);
    const s = state.liveSeen[k];
    // entry fraction: his first points if we saw them; else when the starter's
    // total last moved (he left about then); else in from kickoff (conservative pace)
    let fIn = s && s.fIn != null ? s.fIn : null;
    if (fIn == null) { const ss = state.liveSeen[keyOf(top.p)]; fIn = ss && ss.f0 < f ? ss.f0 : 0; }
    const share = liveBackupShare(p);
    return { proj: Math.round(top.proj * share * 100) / 100, fIn, starter: top.p.n, share };
  }
  function wkLive(p, key) {
    const proj = p && !p._unmatched ? wkVal(p) : 0;
    const g = liveGameFor(p);
    const k = key || (!p || p._unmatched ? null : keyOf(p));
    if (!g) { livePreSeed(p, k); return { live: proj, actual: null, rem: proj, f: 0, st: 'pre', tag: '', proj }; }
    const raw = k != null ? state.livePts[k] : undefined;
    const actual = typeof raw === 'number' ? Math.round(raw * 100) / 100 : 0;
    if (g.st === 'post') return { live: actual, actual, rem: 0, f: 1, st: 'post', tag: g.tag, proj };
    const f = g.f;
    const co = liveModelCoefs(p, f);
    const inh = liveBackupInherit(p, k, actual, f, proj);
    const pj = inh ? inh.proj : proj;                    // projection the remaining is based on
    const span = Math.max(f - (inh ? inh.fIn : 0), 0.1); // game fraction the player has been in
    let rem;
    if (co) {
      const pace = actual / span;
      const margin = (typeof g.pts === 'number' && typeof g.oppPts === 'number') ? (g.pts - g.oppPts) : 0;
      const rel = p.s === 'DST' ? g.oppPts : g.pts;  // K: own team score so far; DST: points allowed so far
      const extra = co.length > 3 && typeof rel === 'number' ? co[3] * (rel / 10) : 0;
      rem = (1 - f) * (co[0] * pj + co[1] * pace + co[2] * pj * (margin / 10) + extra);
    } else {
      const pace = span >= 0.15 ? actual / span : pj;
      const w = 0.25 * f;
      rem = (1 - f) * ((1 - w) * pj + w * pace);
    }
    // D/ST remaining is legitimately NEGATIVE (the points-allowed tier drops as the
    // opponent scores): floor the live total at -4 (the lowest PA tier) instead of 0.
    rem = Math.round(Math.max(p.s === 'DST' ? -4 - actual : 0, rem) * 100) / 100;
    const ex = liveExitMult(p, k, actual, f);
    if (ex.mult < 1) rem = Math.round(rem * ex.mult * 100) / 100;
    return { live: Math.round((actual + rem) * 100) / 100, actual, rem, f, st: 'in', tag: g.tag, proj, pos: p.s, model: co ? 'sim' : 'v1', exitMult: ex.mult, stale: ex.stale, feedFrozen: !!ex.frozen,
      backupFor: inh ? inh.starter : undefined, inhProj: inh ? inh.proj : undefined, inhShare: inh ? inh.share : undefined };
  }
  function liveTip(l) {
    if (l.st === 'post') return 'FINAL — scored ' + l.actual.toFixed(1) + ' (pregame proj ' + l.proj.toFixed(1) + ')';
    return 'LIVE ' + l.tag + ' — scored ' + l.actual.toFixed(1) +
      (l.rem < 0 ? ' − ' + (-l.rem).toFixed(1) + ' expected to come off as points are allowed' : ' + ' + l.rem.toFixed(1) + ' still expected') +
      ' (pregame proj ' + l.proj.toFixed(1) + ').' +
      (l.model === 'sim'
        ? (l.pos === 'K' || l.pos === 'DST'
          ? ' Remaining = Sim Lab live model (2019-25 play-by-play: pace, score margin and ' + (l.pos === 'DST' ? 'points allowed' : 'own team score') + ' so far).'
          : ' Remaining = Sim Lab live model (2019-25 play-by-play: second-half discount, pace, score margin).')
        : ' Remaining = proj × game left, nudged toward his pace late.') +
      (l.backupFor ? ' In for ' + l.backupFor + ' — remaining inherits ' + Math.round(l.inhShare * 100) + '% of his projection (' + l.inhProj.toFixed(1) + (l.inhShare < LIVE_BACKUP_SHARE ? ', blowout share' : '') + ').' : '') +
      (l.feedFrozen ? ' Live totals have not moved for a while — exit rule paused until the feed catches up.' : '') +
      (l.exitMult < 1
        ? ' No points for ' + Math.round(l.stale * 100) + '% of the game — remaining ×' + l.exitMult.toFixed(2) +
          (l.exitMult === 0 ? ' (out of the game).' : ' (likely out of the game).')
        : '');
  }
  // Sidebar name-line tag (LINEUP rows): "● 12.3 live" / "✓ 8.2 final"
  function liveTagHTML(p) {
    const l = wkLive(p);
    if (l.st === 'pre') return '';
    const col = l.st === 'post' ? '#8a8d96' : '#6dd06d';
    const txt = l.st === 'post' ? '✓ ' + l.live.toFixed(1) + ' final' : '● ' + l.live.toFixed(1) + ' live';
    return ` <span title="${esc(liveTip(l))}" style="font-size:9px;font-weight:700;color:${col};white-space:nowrap">${txt}</span>`;
  }
  // On-page pill (team / matchup / players rows): live/final replaces "N proj".
  function livePillHTML(l) {
    if (l.st === 'post') return pillHTML(l.live.toFixed(1) + ' final', '#f0f2f5', '#5b6068', liveTip(l));
    return pillHTML(l.live.toFixed(1) + ' live', '#e2f3e6', '#1d7a34', liveTip(l));
  }
  // Live-aware side totals over scraped starter infos ({p, key, pos, team}):
  // each = wkLive (actual + remaining once his game starts); only the
  // REMAINING part carries variance, so odds tighten toward 100/0 as the
  // week plays out. Unmatched starters still count their live Fan Pts.
  // ---- LIVE WIN-ODDS variance (0.9.31) ----
  // sd of a starter's remaining points from the site export's `liveVar` table
  // (sim_lab/backtest_live_variance.py, pbp 2019-25). The old sd = rem × sigma
  // shrinks with the remaining projection: 1.3-1.5× too tight pregame and 2-4×
  // too tight late, since a touchdown is 6 points whenever it lands, and it hits
  // 0 the moment the remaining projection does. Forms: F4 sd = sqrt(c0 + c1·rem²)
  // (floor + scale), F3 sd = sqrt(a·E·(1−f)), F2 sd = k·rem; rows interpolated
  // over the grid (the last row, f = 1, is zero). Pregame uses the f = 0 row.
  // Falls back to rem × sigma when the export has no table.
  function liveVarSd(p, l, sigFallback) {
    if (l.st === 'post') return 0;
    const lm = state.simProj && state.simProj.liveModel, lv = lm && lm.liveVar;
    const cls = p && (p.s === 'QB' ? 'QB' : p.s === 'RB' ? 'RB' : (p.s === 'WR' || p.s === 'TE') ? 'REC' : (p.s === 'K' || p.s === 'DST') ? p.s : null);
    const rows = lv && lv.pos && cls && lv.pos[cls];
    if (!rows || !lv.grid || rows.length !== lv.grid.length) return Math.abs(l.rem) * sigFallback;
    const f = l.st === 'pre' ? 0 : l.f, g = lv.grid;
    let co;
    if (f <= g[0]) co = rows[0];
    else if (f >= g[g.length - 1]) co = rows[rows.length - 1];
    else {
      let i = 0;
      while (i < g.length - 2 && g[i + 1] < f) i++;
      const t = (f - g[i]) / (g[i + 1] - g[i]);
      co = rows[i].map((v, k) => v + (rows[i + 1][k] - v) * t);
    }
    const rem = Math.abs(l.rem), E = Math.max(0, l.proj);
    const v = lv.form === 'F4' ? co[0] + co[1] * rem * rem : lv.form === 'F3' ? co[0] * E * (1 - f) : (co[0] * rem) * (co[0] * rem);
    return Math.sqrt(Math.max(0, v));
  }
  // ---- SAME-GAME correlation (0.9.32) ----
  // Starters in the same game are not independent: a QB and his own receiver
  // rise and fall together, a lineup facing the D/ST that plays its own QB is
  // hedged. `liveCorr` (sim_lab/backtest_live_corr.py, pbp 2019-25) holds the
  // correlation of standardized remaining residuals per relationship
  // (same team / opponents) x class pair x game fraction. The matchup variance
  // becomes var(A) + var(B) + 2 * sum_{i<j} s_i s_j rho sd_i sd_j over every
  // pair in the same game across BOTH lineups (s = +1 mine, -1 theirs).
  function liveClassOf(p) {
    return p && (p.s === 'QB' ? 'QB' : p.s === 'RB' ? 'RB' : (p.s === 'WR' || p.s === 'TE') ? 'REC' : (p.s === 'K' || p.s === 'DST') ? p.s : null);
  }
  function liveCorrRho(key, f) {
    const lm = state.simProj && state.simProj.liveModel, lc = lm && lm.liveCorr;
    const e = lc && lc.pairs && lc.pairs[key];
    if (!e || !e.rho || !lc.grid || e.rho.length !== lc.grid.length) return 0;
    const g = lc.grid, r = e.rho;
    if (f <= g[0]) return r[0];
    if (f >= g[g.length - 1]) return r[r.length - 1];
    let i = 0;
    while (i < g.length - 2 && g[i + 1] < f) i++;
    return r[i] + (r[i + 1] - r[i]) * (f - g[i]) / (g[i + 1] - g[i]);
  }
  // ents = [{tm, opp, cls, sd, f, st, ref}] from sideProjOf; returns the covariance term
  function liveCovar(entsA, entsB) {
    const all = entsA.map((e) => Object.assign({ s: 1 }, e)).concat(entsB.map((e) => Object.assign({ s: -1 }, e)));
    let cov = 0;
    for (let i = 0; i < all.length; i++) {
      const a = all[i];
      if (!a.tm || !a.cls || !(a.sd > 0) || a.st === 'post') continue;
      for (let j = i + 1; j < all.length; j++) {
        const b = all[j];
        if (!b.tm || !b.cls || !(b.sd > 0) || b.st === 'post' || a.ref === b.ref) continue;
        const same = a.tm === b.tm, opp = a.opp && a.opp === b.tm;
        if (!same && !opp) continue;
        const cls = a.cls < b.cls ? a.cls + '|' + b.cls : b.cls + '|' + a.cls;
        const rho = liveCorrRho((same ? 'same:' : 'opp:') + cls, a.st === 'pre' ? 0 : a.f);
        if (rho) cov += 2 * a.s * b.s * rho * a.sd * b.sd;
      }
    }
    return cov;
  }
  function sideProjOf(infos) {
    let total = 0, varSum = 0, missing = 0, played = 0, done = 0, scored = 0, n = 0;
    const ents = [];  // per counted starter: team/opp/class/sd for the same-game covariance
    for (const info of infos) {
      n++;
      const p = info.p || { n: info.name, s: info.pos, sTm: info.team, _unmatched: true };
      const l = wkLive(p, info.key);
      if (!info.p && l.st === 'pre') { missing++; continue; }
      total += l.live;
      const sig = POS_SIG_DEFAULT[p.s] || 0.55;
      const sd = liveVarSd(p, l, sig);  // calibrated spread (liveVar table) or rem × sigma
      varSum += sd * sd;
      { const tm = liveTeamOf(p), g = tm ? state.liveGames[tm] : null; ents.push({ tm, opp: g ? g.opp : null, cls: liveClassOf(p), sd, f: l.f, st: l.st, ref: p }); }
      if (l.st !== 'pre') { played++; scored += l.actual; }
      if (l.st === 'post') done++;
    }
    return { total: Math.round(total * 10) / 10, varSum, ents, missing, played, done, scored: Math.round(scored * 10) / 10, n };
  }
  function normCdf(z) {
    const t = 1 / (1 + 0.2316419 * Math.abs(z));
    const d = 0.3989422804014327 * Math.exp(-z * z / 2);
    const p = d * t * (0.31938153 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
    return z >= 0 ? 1 - p : p;
  }
  function scrapeMatchupSides() {
    const sides = [[], []];
    const singles = [];
    let firstTable = null;
    let twoCol = false;
    for (const row of document.querySelectorAll('tr')) {
      if (row.closest('#mff-sidebar')) continue;
      const cells = row.querySelectorAll('td,th');
      if (!cells.length) continue;
      let slot = null;
      for (const c of cells) {
        const tok = (c.textContent || '').trim().toUpperCase().replace(/\s+/g, '');
        if (tok && tok.length <= 7 && SLOT_MAP[tok]) { slot = SLOT_MAP[tok]; break; }
      }
      if (!slot || slot === 'BN' || slot === 'IR') continue;
      const boxes = [...row.querySelectorAll('.ysf-player-name')];
      if (!boxes.length) continue;
      if (!firstTable) firstTable = row.closest('table');
      if (boxes.length >= 2) { // mirrored row: first cell = left team
        twoCol = true;
        const i0 = parsePlayerCell(boxes[0].closest('td') || row);
        const i1 = parsePlayerCell(boxes[boxes.length - 1].closest('td') || row);
        if (i0) sides[0].push(i0);
        if (i1) sides[1].push(i1);
      } else {
        const info = parsePlayerCell(boxes[0].closest('td') || row);
        if (info) singles.push({ row, info });
      }
    }
    if (!twoCol && singles.length) { // column-per-team layout: split at midline
      const midX = document.documentElement.clientWidth / 2;
      for (const s of singles) {
        const r = s.row.getBoundingClientRect();
        sides[r.left + r.width / 2 < midX ? 0 : 1].push(s.info);
      }
    }
    return { sides, firstTable };
  }
  // Yahoo's matchup header ends with a "Chance to win N%" row + probability
  // bar (both inside one block above the roster table). Anchor = the lowest
  // common ancestor of the two "Chance to win" texts, then hop past the bar
  // sibling so our strip sits right under Yahoo's odds. Null when the header
  // isn't there (older layouts) → caller falls back to above-the-table.
  function chanceToWinAnchor() {
    const owners = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let n;
    while ((n = walker.nextNode())) {
      const tx = (n.nodeValue || '').trim();
      if (tx.length > 40 || !/chance\s*to\s*win/i.test(tx)) continue;
      const el = n.parentElement;
      if (!el || el.closest('#mff-sidebar') || el.closest('#mff-matchup-strip')) continue;
      if (owners.indexOf(el) < 0) owners.push(el);
      if (owners.length === 2) break;
    }
    if (owners.length < 2) return null;
    const ups = new Set();
    for (let m = owners[0]; m; m = m.parentElement) ups.add(m);
    let lca = owners[1];
    while (lca && !ups.has(lca)) lca = lca.parentElement;
    if (!lca || lca === document.body || lca === document.documentElement) return null;
    let anchor = lca;
    let sib = lca.nextElementSibling;
    while (sib && sib.id === 'mff-matchup-strip') sib = sib.nextElementSibling;
    // the probability bar: a text-free sibling right after the odds row
    if (sib && !(sib.textContent || '').trim()) anchor = sib;
    return anchor;
  }
  function matchupStripTick() {
    const existing = document.getElementById('mff-matchup-strip');
    if (!onMatchupPage() || !state.players.length) { if (existing) existing.remove(); return; }
    const scr = scrapeMatchupSides();
    const L = scr.sides[0], R = scr.sides[1];
    if (!scr.firstTable || L.length < 4 || R.length < 4) { if (existing) existing.remove(); return; }
    const proj = [sideProjOf(L), sideProjOf(R)];
    const live = (proj[0].played + proj[1].played) > 0;
    const sd = Math.sqrt(Math.max(0, proj[0].varSum + proj[1].varSum + liveCovar(proj[0].ents, proj[1].ents)));
    const winL = sd < 0.05
      ? (proj[0].total > proj[1].total ? 100 : proj[0].total < proj[1].total ? 0 : 50)
      : Math.round(normCdf((proj[0].total - proj[1].total) / sd) * 100);
    const missing = proj[0].missing + proj[1].missing;
    const tip = (live
      ? 'MFF LIVE numbers for this matchup — each starter = Yahoo\'s Fan Pts so far + what he should still ' +
        'score (pregame proj × game left, nudged toward his pace late); finals count as scored. Win odds ' +
        'only vary the unplayed part. Left: ' + proj[0].scored.toFixed(1) + ' in, ' + proj[0].done + '/' + proj[0].n +
        ' final · Right: ' + proj[1].scored.toFixed(1) + ' in, ' + proj[1].done + '/' + proj[1].n + ' final.'
      : 'MFF numbers for this matchup — our proj totals (same weekly projection as the row ' +
        'pills: site sim first, ' + state.scoringLabel + ' scored, injuries priced) summed over the ' +
        'starters shown on each side, and our win odds (normal approximation; player correlations ' +
        'ignored). Left/right match the page\'s two teams.') +
      (missing ? ' ' + missing + ' starter(s) without a projection count 0.' : '');
    const wCol = (w) => (w >= 55 ? '#1d7a34' : w <= 45 ? '#b33636' : '#a06a00');
    const lbl = live ? '<span style="color:#1d7a34">● live</span>' : '<span style="color:#5b6068">proj</span>';
    const side = (tot, w, right) =>
      `<span style="flex:1;min-width:0;white-space:nowrap;${right ? 'text-align:right' : ''}">` +
      `<b style="font-size:15px">${tot.toFixed(1)}</b> ${lbl}` +
      `<span style="color:#c8ccd4;margin:0 6px">|</span>` +
      `<b style="font-size:15px;color:${wCol(w)}">${w}%</b> <span style="color:#5b6068">win</span></span>`;
    const inner = side(proj[0].total, winL, false) +
      `<span style="flex:0 0 auto;color:#5b6068;font-size:10px;font-weight:800;letter-spacing:.5px;text-align:center">MFF ${live ? 'LIVE' : 'PROJ'} · WIN ODDS<br>WK ${state.seasonWeek}</span>` +
      side(proj[1].total, 100 - winL, true);
    const anchor = chanceToWinAnchor();
    if (existing && existing.dataset.mffSig === inner && existing.isConnected &&
        (anchor ? existing.previousElementSibling === anchor : existing.nextElementSibling === scr.firstTable)) return;
    if (existing) existing.remove();
    const strip = document.createElement('div');
    strip.id = 'mff-matchup-strip';
    strip.dataset.mffSig = inner;
    strip.title = tip;
    strip.style.cssText = 'display:flex;align-items:center;gap:10px;margin:6px 0 2px;padding:6px 12px;' +
      'background:#f4f6f8;border:1px solid #dfe3e8;border-radius:6px;text-align:left;' +
      "font:600 12px/1.3 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;color:#2a2c33;";
    strip.innerHTML = inner;
    if (anchor) anchor.insertAdjacentElement('afterend', strip);
    else scr.firstTable.parentNode.insertBefore(strip, scr.firstTable);
  }
  function decorateYahooRows() {
    if (!gateAllowed()) return;
    if (!state.leagueId || !state.players.length) return;
    const calc = state.roster.length && state.seasonSlots ? seasonLineupCalc() : null;
    const playersPage = onPlayersPage();
    // Matchup page: proj pill only, no boom/bust per Jack (v0.9.15) — the
    // mirrored rows + strip already crowd it. Other pages keep both.
    const matchupPage = onMatchupPage();
    let mine = null, base = null; // lazy — only when an FA delta is needed
    document.querySelectorAll('.ysf-player-name').forEach((box) => {
      if (box.closest('#mff-sidebar')) return;
      const row = box.closest('tr') || box;
      // Parse THIS box's own cell, not the whole row: matchup rows are
      // mirrored (left team | slot | right team) and a row-wide parse hands
      // the right-hand player the LEFT player's pills.
      const info = parsePlayerCell(box.closest('td') || row);
      const existing = box.querySelector(':scope > .mff-page-pills');
      if (!info || !info.p) { if (existing) existing.remove(); return; }
      const p = info.p;
      const pills = [];
      const isMine = state.myKeys.has(info.key);
      const verdict = isMine && calc ? calc.cls[keyOf(p)] : null;
      if (verdict === 'go') pills.push(pillHTML('▲ START', '#e2f3e6', '#1d7a34', 'Projects better than a current starter — put him in'));
      else if (verdict === 'sit') pills.push(pillHTML('▼ SIT', '#fbe7e7', '#b33636', 'A benched player projects better — take him out'));
      else if (verdict === 'close') pills.push(pillHTML('≈ TOSS-UP', '#fdf1dc', '#a06a00', 'Projections within ' + CLOSE_PPG + ' ppg — either is fine'));
      const g = wkOppInfo(p);
      if (g && !tintYahooGameLine(box, g)) {
        // no native game line in this cell (news modules etc.) — keep the pill;
        // wkOppInfo carries the sidebar's dark palette — remap to the light one
        const oc = g.cls === 'good' ? ['#e2f3e6', '#1d7a34'] : g.cls === 'bad' ? ['#fbe7e7', '#b33636'] : ['#f0f2f5', '#5b6068'];
        pills.push(pillHTML(g.txt, oc[0], oc[1], g.tip));
      }
      const lv = wkLive(p, info.key);
      const v = lv.proj;
      if (lv.st !== 'pre') {
        pills.push(livePillHTML(lv)); // in-game: scored + remaining (final = scored)
      } else if (v > 0 || p.pPg != null) {
        pills.push(pillHTML((Math.round(v * 10) / 10) + ' proj', '#f0f2f5', '#2a2c33',
          'Projected points this week (' + state.scoringLabel + ' · MFF blend of props + Clay + Jack)'));
        if (!matchupPage) {
          const sr = simWeekRowFor(p);
          if (sr && sr[3] != null && sr[4] != null) pills.push(simOddsPillHTML(sr));
        }
      }
      if (playersPage && !isMine && state.faSeen[info.key] && calc) {
        if (base == null) { mine = myPlayerObjs(); base = optimalLineup(mine).total; }
        const delta = Math.round((optimalLineup(mine.concat([p])).total - base) * 10) / 10;
        if (delta >= 0.5) pills.push(pillHTML('LINEUP +' + delta.toFixed(1), '#e2f3e6', '#1d7a34', 'Adding him upgrades your optimal lineup by ' + delta.toFixed(1) + ' ppg'));
        else if (delta > 0) pills.push(pillHTML('+' + delta.toFixed(1), '#e3f0f7', '#1c6e8c', 'Marginal lineup upgrade'));
      }
      const inner = pills.join('');
      if (existing && existing.dataset.mffSig === inner) return;
      if (existing) existing.remove();
      if (!inner) return;
      const span = document.createElement('span');
      span.className = 'mff-page-pills';
      span.dataset.mffSig = inner;
      span.innerHTML = inner;
      span.style.cssText = 'display:inline-flex;flex-wrap:nowrap;gap:3px;margin-left:6px;' +
        'vertical-align:middle;overflow:hidden;position:relative;z-index:5;';
      box.appendChild(span);
    });
  }

  // ---------- probe persistence (events from probe.js in MAIN world) ----------
  const probeUrls = [];
  document.addEventListener('mff-yahoo-probe', (e) => {
    try {
      const d = JSON.parse(e.detail);
      probeUrls.push({ t: Date.now(), kind: d.kind, url: d.url });
      state.probeCount = probeUrls.length;
      if (probeUrls.length <= 600) {
        store.set({ mff_yahoo_probe: { updatedAt: Date.now(), urls: probeUrls.slice(-600) } });
      }
    } catch (_) {}
  });

  // ---------- boot ----------
  function scrapeTick() {
    if (!state.leagueId) return;
    const scr = scrapeTeamPage();
    if (scr) {
      const sig = scr.entries.map((x) => x.key + ':' + x.slotLbl).join('|');
      if (sig !== state._rosterSig) {
        state._rosterSig = sig;
        applyScrapedRoster(scr);
        render();
      }
    }
    if (scrapePlayersPage() > 0) render();
    decorateYahooRows();
    matchupStripTick();
  }
  // Per-league fields back to their defaults before a league loads - switching
  // leagues in the same tab used to carry the last league's format (incl. a
  // hand-picked one), API slots and scoring into the next (2026-10-05).
  function resetLeagueState() {
    Object.assign(state, {
      teamName: '', seasonSlots: null, roster: [], rosterTs: 0, faSeen: {}, myKeys: new Set(),
      mode: 're_1qb', modeManual: false, modeDetected: null,
      scoringPrefs: { rec: 0.5, passTd: 4 }, scoringManual: false, apiSlots: null, apiScoring: false,
      playoffTeams: undefined, playoffStart: undefined, _rosterSig: null,
    });
    applyScoringPrefs();
  }
  async function initForLeague(leagueId) {
    resetLeagueState();
    state.leagueId = leagueId;
    buildPanel();
    render();
    const saved = await store.get(['yahooLeague_' + leagueId]);
    restoreLeagueState(saved['yahooLeague_' + leagueId]);
    fetchLeagueSettings(leagueId); // async — overwrites stale/scraped slots + scoring when it lands
    await ensureNflState();
    state.seasonStatus = state.players.length + ' players · wk ' + state.seasonWeek +
      (state.byesActive ? '' : ' (preseason)');
    await refreshScoreboard(false); // live game clocks (no-op preseason)
    scrapeTick();
    if (!state.scrapeTimer) state.scrapeTimer = setInterval(scrapeTick, SCRAPE_MS);
    if (!state.pollTimer) {
      state.pollTimer = setInterval(() => {
        fetchTrending();
        fetchSeasonStats();
        refreshScoreboard(false).then(() => { if (state.leagueId) render(); });
      }, SEASON_POLL_MS);
    }
    fetchInjuries();
    fetchTrending();
    fetchSeasonStats();
    render();
  }
  let lastHref = null;
  function onUrlChange() {
    const lid = detectLeagueId();
    if (lid) {
      if (lid !== state.leagueId) initForLeague(lid);
    } else if (state.leagueId) {
      state.leagueId = null;
      destroyPanel();
    }
  }
  async function main() {
    await loadPlayers();
    store.get(['mff_jacks_boards']).then((r) => applyBridgeJackBoards(r && r.mff_jacks_boards));
    refreshJackBoards();
    if (MOCK && MOCK.vegas) {
      applyLiveVegas(MOCK.vegas.gameTotals);
      buildSchedule(MOCK.vegas.gameTotals);
      state.wkPropsAll = MOCK.vegas.weeklyProps || null;
      if (MOCK.fpa) state.fpa = MOCK.fpa; // harness stand-in for fpa_2026.json (opp matchup grade)
      window.BETTING_2026 = MOCK.vegas; // season-sim engine reads gameTotals here
      if (MOCK.consensus) state.wkConsensus = MOCK.consensus;
      if (MOCK.simProj) { // harness stand-in for the sim_proj_2026.json fetch
        state.simProj = MOCK.simProj;
        state.simProjIdx = null;
      }
    } else {
      fetchJson('https://www.myfantasyfootball.co/data/betting_lines_2026.json?t=' + Date.now())
        .then((d) => {
          const n = applyLiveVegas(d.gameTotals);
          buildSchedule(d.gameTotals);
          state.wkPropsAll = d.weeklyProps || null;
          window.BETTING_2026 = d; // season-sim engine (SIMS tab) reads gameTotals here
          if (n) console.log('[MFF/Yahoo] live Vegas overlay: ' + n + ' SOS records refreshed');
          render();
        }).catch(() => {});
      // Fantasy points allowed per defense-week (site postgame importer, FINAL
      // games only) → schedule-adjusted opponent matchup grade (wkOppInfo).
      fetchJson('https://www.myfantasyfootball.co/data/fpa_2026.json?t=' + Date.now())
        .then((d) => {
          if (!d || !d.weeks) return;
          state.fpa = d;
          _oppGradeCache = null;
          render();
        }).catch(() => {});
      // Site consensus weekly projections (Sleeper h/p/s + ESPN/FP e/f arrays) —
      // reference row in the expanded player profile, never a scoring input.
      fetchJson('https://www.myfantasyfootball.co/data/weekly_projections.json?t=' + Date.now())
        .then((d) => {
          if (!d || !d.players) return;
          state.wkConsensus = d;
          state.wkConsensusIdx = null; // rebuilt lazily on first lookup
          if (state.appMode === 'season') render();
        }).catch(() => {});
      // Sim Lab export (site sim_proj_2026.json — same file the site's PROJ
      // columns read): rest-of-season seasonPpg + per-week rows, refreshed on
      // the site daily + ~30 min before kickoffs, frozen at kickoff. THE
      // projection source wherever a row exists (Jack 2026-08-26); the
      // Clay / props chain stays as the fallback.
      fetchJson('https://www.myfantasyfootball.co/data/sim_proj_2026.json?t=' + Date.now())
        .then((d) => {
          if (!d || !d.weeks) return;
          state.simProj = d;
          state.simProjIdx = null;
          if (state.players && state.players.length) applyScoringPrefs();
          console.log('[MFF/Yahoo] Sim Lab projections loaded (wk ' + d.currentWeek + ')');
          render();
        }).catch(() => {});
    }
    if (MOCK && MOCK.scoreboard) state.liveGames = parseScoreboard(MOCK.scoreboard); liveFeedBaseline(); // harness live games
    gateInit(() => { try { render(); } catch (_) {} });
    lastHref = location.href;
    onUrlChange();
    setInterval(() => {
      if (location.href === lastHref) return;
      lastHref = location.href;
      onUrlChange();
    }, URL_WATCH_MS);
  }

  window.__mffYahoo = { state, render, initForLeague, scrapeTeamPage, scrapePlayersPage,
    wkVal, wkLive, liveExitMult, liveBackupInherit, liveVarSd, liveCovar, parseScoreboard, refreshScoreboard, livePtsFromCell, sideProjOf,
    kickerProjFor, dstProjFor, optimalLineup, waiverRecs, seasonLineupCalc };
  main();
})();
